#!/usr/bin/env python3
"""
Termux Backend Pro - local-only API bridge
Fungsi:
- /health
- /api/endpoints
- /api/execute        : command executor aman berbasis allowlist
- /api/open-url       : buka URL di Android/Termux
- /api/browser-fetch  : fetch halaman web sederhana dengan SSRF guard
- /api/device         : info perangkat Termux
- /api/termux-tool    : battery/clipboard/notification aman
- /api/adb            : ADB aman berbasis allowlist
- /api/ports          : lihat port listening
- /api/schema         : skema keluaran terstruktur
- /api/quran          : pencarian data Quran lokal opsional
- /api/hadith         : pencarian data Haditz lokal opsional
- /api/dictionary     : kamus lokal opsional

Install:
  pkg update
  pkg install python termux-api
  pip install --upgrade certifi

Jalankan:
  export API_SERVER_TOKEN="$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
  python ~/termux_backend_pro.py

Catatan:
- GEMINI_API_KEY sengaja TIDAK dipakai di backend ini.
- Gemini dipanggil langsung dari HTML/Canvas.
"""

import http.server
import socketserver
import subprocess
import json
import os
import shlex
import time
import urllib.request
import urllib.error
import socket
import ipaddress
from pathlib import Path
from urllib.parse import urlparse

HOST = os.environ.get("API_HOST", "127.0.0.1")
PORT = int(os.environ.get("API_PORT", "8001"))
API_SERVER_TOKEN = os.environ.get("API_SERVER_TOKEN", "")
DEFAULT_TIMEOUT = int(os.environ.get("EXEC_TIMEOUT", "66"))
MAX_BODY_BYTES = int(os.environ.get("MAX_BODY_BYTES", str(256 * 1024)))
CORS_ORIGIN = os.environ.get("CORS_ORIGIN", "*")

DATA_DIR = Path(os.environ.get("DATA_DIR", str(Path.home() / "termux_assistant_data")))
DATA_DIR.mkdir(exist_ok=True)

SAFE_COMMANDS = {
    "pwd", "ls", "cat", "head", "tail", "wc", "grep", "find",
    "python", "python3", "pip", "pip3",
    "git", "pkg", "termux-info",
    "termux-battery-status", "termux-clipboard-get", "termux-clipboard-set",
    "termux-notification", "date", "uname", "whoami", "df", "du", "free",
    "ss", "netstat", "ip", "ping"
}

DANGEROUS_TOKENS = {
    "rm", "mkfs", "dd", "su", "sudo", "reboot", "shutdown",
    "pkill", "killall", "kill", ":(){", "chmod 777 /", "chown -R"
}

SAFE_ADB = {
    "devices",
    "version",
    "shell:getprop",
    "shell:wm size",
    "shell:wm density",
    "shell:dumpsys battery",
    "shell:settings get secure android_id",
}

def now_ms():
    return int(time.time() * 1000)

def dumps(obj):
    return json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8")

def public_error(message, code=400, detail=None):
    obj = {"ok": False, "error": message, "code": code}
    if detail:
        obj["detail"] = detail
    return obj

def run_cmd(argv, timeout=DEFAULT_TIMEOUT):
    started = now_ms()
    p = subprocess.run(
        argv,
        shell=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
    )
    return {
        "ok": p.returncode == 0,
        "argv": argv,
        "stdout": p.stdout,
        "stderr": p.stderr,
        "return_code": p.returncode,
        "elapsed_ms": now_ms() - started,
    }

def command_is_safe(command):
    low = command.lower()
    for token in DANGEROUS_TOKENS:
        if token in low:
            return False, f"Token berbahaya terdeteksi: {token}"
    try:
        argv = shlex.split(command)
    except Exception as e:
        return False, f"Command tidak valid: {e}"
    if not argv:
        return False, "Command kosong."
    base = os.path.basename(argv[0])
    if base not in SAFE_COMMANDS:
        return False, f"Command '{base}' tidak ada di allowlist."
    return True, argv

def is_public_http_url(url):
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        return False, "URL harus http/https."
    host = parsed.hostname
    try:
        infos = socket.getaddrinfo(host, None)
        for info in infos:
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved:
                return False, f"Host mengarah ke IP non-publik: {ip}"
    except Exception as e:
        return False, f"Gagal resolve host: {e}"
    return True, None

def load_json_file(name):
    path = DATA_DIR / name
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def search_local_json(name, query, limit=10):
    data = load_json_file(name)
    if data is None:
        return {
            "ok": False,
            "message": f"File data belum ada: {DATA_DIR / name}",
            "hint": "Buat file JSON lokal berisi array objek. Endpoint ini sengaja offline-friendly.",
            "items": [],
        }

    q = (query or "").lower().strip()
    results = []
    iterable = data if isinstance(data, list) else data.get("items", [])
    for item in iterable:
        text = json.dumps(item, ensure_ascii=False).lower()
        if not q or q in text:
            results.append(item)
        if len(results) >= limit:
            break
    return {"ok": True, "count": len(results), "items": results}

class Handler(http.server.SimpleHTTPRequestHandler):
    server_version = "TermuxBackendPro/1.0"

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", CORS_ORIGIN)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def send_json(self, data, code=200):
        raw = dumps(data)
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def read_body(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        if length > MAX_BODY_BYTES:
            raise ValueError(f"Body terlalu besar. Maksimal {MAX_BODY_BYTES} bytes.")
        return json.loads(self.rfile.read(length))

    def require_auth(self):
        if not API_SERVER_TOKEN:
            self.send_json(public_error("API_SERVER_TOKEN belum diset di environment.", 500), 500)
            return False
        auth = self.headers.get("Authorization", "")
        if auth != f"Bearer {API_SERVER_TOKEN}":
            self.send_json(public_error("Unauthorized. Pakai Authorization: Bearer <token>.", 401), 401)
            return False
        return True

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        if self.path == "/health":
            self.send_json({
                "ok": True,
                "service": "Termux Backend Pro",
                "host": HOST,
                "port": PORT,
                "token_set": bool(API_SERVER_TOKEN),
                "data_dir": str(DATA_DIR),
                "gemini_key_in_backend": False,
            })
            return

        if self.path == "/api/endpoints":
            self.send_json({
                "ok": True,
                "endpoints": [
                    "GET /health",
                    "GET /api/endpoints",
                    "GET /api/ports",
                    "GET /api/schema",
                    "POST /api/execute",
                    "POST /api/open-url",
                    "POST /api/browser-fetch",
                    "POST /api/device",
                    "POST /api/termux-tool",
                    "POST /api/adb",
                    "POST /api/quran",
                    "POST /api/hadith",
                    "POST /api/dictionary",
                ]
            })
            return

        if self.path == "/api/schema":
            self.send_json({
                "ok": True,
                "gemini_action_schema": {
                    "type": "object",
                    "properties": {
                        "action_type": {"type": "string", "enum": ["chat", "command", "backend"]},
                        "response": {"type": "string"},
                        "command": {"type": "string"},
                        "endpoint": {"type": "string"},
                        "payload": {"type": "object"},
                        "suggested_timeout": {"type": "integer"},
                    },
                    "required": ["action_type", "response"]
                }
            })
            return

        if self.path == "/api/ports":
            if not self.require_auth():
                return
            try:
                try:
                    res = run_cmd(["ss", "-tulpn"], timeout=10)
                except Exception:
                    res = run_cmd(["netstat", "-tulpn"], timeout=10)
                self.send_json(res)
            except Exception as e:
                self.send_json(public_error("Gagal membaca port.", 500, str(e)), 500)
            return

        self.send_json(public_error("Endpoint tidak ditemukan.", 404), 404)

    def do_POST(self):
        if not self.require_auth():
            return

        try:
            data = self.read_body()
        except Exception as e:
            self.send_json(public_error("Body JSON tidak valid.", 400, str(e)), 400)
            return

        try:
            if self.path == "/api/execute":
                command = str(data.get("command", "")).strip()
                timeout = int(data.get("timeout", DEFAULT_TIMEOUT))
                ok, parsed = command_is_safe(command)
                if not ok:
                    self.send_json(public_error(parsed, 403), 403)
                    return
                self.send_json(run_cmd(parsed, timeout=timeout))
                return

            if self.path == "/api/open-url":
                url = str(data.get("url", "")).strip()
                ok, msg = is_public_http_url(url)
                if not ok:
                    self.send_json(public_error(msg, 400), 400)
                    return
                opener = "termux-open-url"
                self.send_json(run_cmd([opener, url], timeout=10))
                return

            if self.path == "/api/browser-fetch":
                url = str(data.get("url", "")).strip()
                desktop = bool(data.get("desktop", True))
                ok, msg = is_public_http_url(url)
                if not ok:
                    self.send_json(public_error(msg, 400), 400)
                    return

                ua = (
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/125.0 Safari/537.36"
                    if desktop else
                    "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/125.0 Mobile Safari/537.36"
                )
                req = urllib.request.Request(url, headers={"User-Agent": ua})
                with urllib.request.urlopen(req, timeout=20) as r:
                    raw = r.read(200_000)
                    content_type = r.headers.get("content-type", "")
                text = raw.decode("utf-8", errors="replace")
                self.send_json({
                    "ok": True,
                    "url": url,
                    "content_type": content_type,
                    "text_preview": text[:20000],
                    "bytes_read": len(raw),
                })
                return

            if self.path == "/api/device":
                info = {}
                for name, argv in {
                    "termux_info": ["termux-info"],
                    "battery": ["termux-battery-status"],
                    "uname": ["uname", "-a"],
                    "disk": ["df", "-h"],
                }.items():
                    try:
                        info[name] = run_cmd(argv, timeout=15)
                    except Exception as e:
                        info[name] = {"ok": False, "error": str(e)}
                self.send_json({"ok": True, "device": info})
                return

            if self.path == "/api/termux-tool":
                action = str(data.get("action", "")).strip()
                if action == "battery":
                    self.send_json(run_cmd(["termux-battery-status"], timeout=10))
                    return
                if action == "clipboard_get":
                    self.send_json(run_cmd(["termux-clipboard-get"], timeout=10))
                    return
                if action == "clipboard_set":
                    text = str(data.get("text", ""))
                    p = subprocess.run(
                        ["termux-clipboard-set"],
                        input=text,
                        shell=False,
                        capture_output=True,
                        text=True,
                        timeout=10,
                    )
                    self.send_json({"ok": p.returncode == 0, "stdout": p.stdout, "stderr": p.stderr})
                    return
                if action == "notification":
                    title = str(data.get("title", "Termux Assistant"))[:80]
                    content = str(data.get("content", ""))[:500]
                    self.send_json(run_cmd(["termux-notification", "--title", title, "--content", content], timeout=10))
                    return
                self.send_json(public_error("Action termux-tool tidak dikenal.", 400), 400)
                return

            if self.path == "/api/adb":
                adb_action = str(data.get("action", "")).strip()
                if adb_action == "devices":
                    self.send_json(run_cmd(["adb", "devices"], timeout=15))
                    return

                shell_cmd = str(data.get("shell", "")).strip()
                full = f"shell:{shell_cmd}"
                if full not in SAFE_ADB:
                    self.send_json(public_error(
                        "ADB action tidak diizinkan.",
                        403,
                        f"Allowed shell: {[x for x in SAFE_ADB if x.startswith('shell:')]}"
                    ), 403)
                    return
                self.send_json(run_cmd(["adb", "shell"] + shlex.split(shell_cmd), timeout=20))
                return

            if self.path == "/api/quran":
                query = str(data.get("query", "")).strip()
                self.send_json(search_local_json("quran.json", query, int(data.get("limit", 10))))
                return

            if self.path == "/api/hadith":
                query = str(data.get("query", "")).strip()
                self.send_json(search_local_json("hadith.json", query, int(data.get("limit", 10))))
                return

            if self.path == "/api/dictionary":
                query = str(data.get("query", "")).strip()
                self.send_json(search_local_json("dictionary.json", query, int(data.get("limit", 10))))
                return

            self.send_json(public_error("Endpoint tidak ditemukan.", 404), 404)

        except subprocess.TimeoutExpired:
            self.send_json(public_error("Perintah timeout.", 504), 504)
        except Exception as e:
            self.send_json(public_error("Kesalahan internal backend.", 500, str(e)), 500)

class ThreadingServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

if __name__ == "__main__":
    if HOST not in ("127.0.0.1", "localhost"):
        print("PERINGATAN: HOST bukan localhost. Jangan expose backend ini ke internet.")
    if not API_SERVER_TOKEN:
        print("ERROR: set API_SERVER_TOKEN dulu.")
        print("export API_SERVER_TOKEN=\"$(python -c 'import secrets; print(secrets.token_urlsafe(32))')\"")
        raise SystemExit(2)

    with ThreadingServer((HOST, PORT), Handler) as httpd:
        print(f"Termux Backend Pro aktif: http://{HOST}:{PORT}")
        print(f"Data dir: {DATA_DIR}")
        httpd.serve_forever()

