echo 'Sourcing test successful'
