#!/data/data/com.termux/files/usr/bin/sh

HOME_DIR="/data/data/com.termux/files/home"
CONF_FILE="$HOME_DIR/backend-data/android-debug-switch.conf"
ADB_CONF_FILE="$HOME_DIR/backend-data/adb-autoconnect.conf"

if [ -f "$ADB_CONF_FILE" ]; then
  . "$ADB_CONF_FILE"
fi

ENV_ANDROID_DEBUG_MODE="${ANDROID_DEBUG_MODE:-}"
ENV_ANDROID_DEBUG_TCP_PORT="${ANDROID_DEBUG_TCP_PORT:-}"
ENV_ANDROID_DEBUG_RESTART_ADBD="${ANDROID_DEBUG_RESTART_ADBD:-}"
ENV_ADB_SERIAL="${ADB_SERIAL:-}"
ENV_RISH_PATH="${RISH_PATH:-}"
ENV_RISH_APPLICATION_ID="${RISH_APPLICATION_ID:-}"

if [ -f "$CONF_FILE" ]; then
  . "$CONF_FILE"
fi

[ -n "$ENV_ANDROID_DEBUG_MODE" ] && ANDROID_DEBUG_MODE="$ENV_ANDROID_DEBUG_MODE"
[ -n "$ENV_ANDROID_DEBUG_TCP_PORT" ] && ANDROID_DEBUG_TCP_PORT="$ENV_ANDROID_DEBUG_TCP_PORT"
[ -n "$ENV_ANDROID_DEBUG_RESTART_ADBD" ] && ANDROID_DEBUG_RESTART_ADBD="$ENV_ANDROID_DEBUG_RESTART_ADBD"
[ -n "$ENV_ADB_SERIAL" ] && ADB_SERIAL="$ENV_ADB_SERIAL"
[ -n "$ENV_RISH_PATH" ] && RISH_PATH="$ENV_RISH_PATH"
[ -n "$ENV_RISH_APPLICATION_ID" ] && RISH_APPLICATION_ID="$ENV_RISH_APPLICATION_ID"

ACTION="${1:-status}"
MODE="${ANDROID_DEBUG_MODE:-auto}"
TCP_PORT="${ANDROID_DEBUG_TCP_PORT:-5555}"
RESTART_ADBD="${ANDROID_DEBUG_RESTART_ADBD:-0}"
RISH_PATH="${RISH_PATH:-$HOME_DIR/rish}"
RISH_APPLICATION_ID="${RISH_APPLICATION_ID:-com.termux}"

shift 2>/dev/null || true

while [ "$#" -gt 0 ]; do
  case "$1" in
    --mode=*) MODE="${1#--mode=}" ;;
    --serial=*) ADB_SERIAL="${1#--serial=}" ;;
    --port=*) TCP_PORT="${1#--port=}" ;;
    --restart-adbd) RESTART_ADBD=1 ;;
    --no-restart-adbd) RESTART_ADBD=0 ;;
    --help|-h) ACTION=help ;;
    *) printf 'Unknown argument: %s\n' "$1" >&2; exit 2 ;;
  esac
  shift
done

adb_cmd() {
  if [ -n "${ADB_SERIAL:-}" ]; then
    adb -s "$ADB_SERIAL" "$@"
  else
    adb "$@"
  fi
}

adb_connected() {
  command -v adb >/dev/null 2>&1 || return 1
  adb_cmd get-state >/dev/null 2>&1
}

rish_available() {
  [ -x "$RISH_PATH" ] || return 1
  RISH_APPLICATION_ID="$RISH_APPLICATION_ID" "$RISH_PATH" -c id >/dev/null 2>&1
}

local_settings_available() {
  command -v settings >/dev/null 2>&1
}

quote_arg() {
  printf "'%s'" "$(printf '%s' "$1" | sed "s/'/'\\\\''/g")"
}

build_shell_command() {
  command_text=""
  for arg in "$@"; do
    quoted="$(quote_arg "$arg")"
    if [ -n "$command_text" ]; then
      command_text="$command_text $quoted"
    else
      command_text="$quoted"
    fi
  done
  printf '%s' "$command_text"
}

detect_transport() {
  case "$MODE" in
    adb) command -v adb >/dev/null 2>&1 && { printf 'adb\n'; return 0; } ;;
    rish) [ -x "$RISH_PATH" ] && { printf 'rish\n'; return 0; } ;;
    local) local_settings_available && { printf 'local\n'; return 0; } ;;
    auto)
      if adb_connected; then
        printf 'adb\n'
        return 0
      fi
      if rish_available; then
        printf 'rish\n'
        return 0
      fi
      if local_settings_available; then
        printf 'local\n'
        return 0
      fi
      ;;
    *) printf 'Invalid mode: %s\n' "$MODE" >&2; exit 2 ;;
  esac

  printf 'none\n'
}

TRANSPORT="$(detect_transport)"

run_device() {
  case "$TRANSPORT" in
    adb) adb_cmd shell "$@" ;;
    rish) RISH_APPLICATION_ID="$RISH_APPLICATION_ID" "$RISH_PATH" -c "$(build_shell_command "$@")" ;;
    local) "$@" ;;
    *) return 127 ;;
  esac
}

print_header() {
  printf 'action=%s\n' "$ACTION"
  printf 'requested_mode=%s\n' "$MODE"
  printf 'transport=%s\n' "$TRANSPORT"
  printf 'adb_serial=%s\n' "${ADB_SERIAL:-}"
  printf 'tcp_port=%s\n' "$TCP_PORT"
}

print_adb_host_state() {
  if command -v adb >/dev/null 2>&1; then
    printf '\n[adb-host]\n'
    adb version 2>&1 | sed 's/^/adb.version: /'
    adb devices -l 2>&1 | sed 's/^/adb.devices: /'
    adb mdns services 2>/dev/null | sed 's/^/adb.mdns: /'
  else
    printf '\n[adb-host]\nadb.binary=missing\n'
  fi
}

get_setting() {
  table="$1"
  key="$2"
  if [ "$TRANSPORT" = "none" ]; then
    printf '%s.%s=unavailable transport=none\n' "$table" "$key"
    return
  fi

  value="$(run_device settings get "$table" "$key" 2>&1)"
  rc=$?
  if printf '%s\n' "$value" | grep -q 'SecurityException'; then
    value="permission_denied"
  else
    value="$(printf '%s\n' "$value" | tr '\n' ' ' | sed 's/[[:space:]][[:space:]]*/ /g; s/^ //; s/ $//')"
  fi
  printf '%s.%s=%s rc=%s\n' "$table" "$key" "$value" "$rc"
}

get_prop() {
  key="$1"
  if [ "$TRANSPORT" = "none" ]; then
    printf 'prop.%s=unavailable transport=none\n' "$key"
    return
  fi

  value="$(run_device getprop "$key" 2>&1)"
  rc=$?
  printf 'prop.%s=%s rc=%s\n' "$key" "$value" "$rc"
}

put_setting() {
  table="$1"
  key="$2"
  value="$3"
  if [ "$TRANSPORT" = "none" ]; then
    printf 'put %s.%s=%s skipped transport=none\n' "$table" "$key" "$value"
    return 1
  fi

  output="$(run_device settings put "$table" "$key" "$value" 2>&1)"
  rc=$?
  if printf '%s\n' "$output" | grep -q 'SecurityException'; then
    output="permission_denied"
  else
    output="$(printf '%s\n' "$output" | tr '\n' ' ' | sed 's/[[:space:]][[:space:]]*/ /g; s/^ //; s/ $//')"
  fi
  printf 'put %s.%s=%s rc=%s %s\n' "$table" "$key" "$value" "$rc" "$output"
  return "$rc"
}

run_report() {
  label="$1"
  shift
  output="$(run_device "$@" 2>&1)"
  rc=$?
  output="$(printf '%s\n' "$output" | tr '\n' ' ' | sed 's/[[:space:]][[:space:]]*/ /g; s/^ //; s/ $//')"
  printf '%s rc=%s %s\n' "$label" "$rc" "$output"
  return "$rc"
}

status_action() {
  print_header
  printf '\n[switches]\n'
  get_setting global development_settings_enabled
  get_setting global adb_enabled
  get_setting global adb_wifi_enabled
  get_setting global adb_allowed_connection_time
  get_setting global adb_wifi_guided_dialog_shown
  get_setting global verifier_verify_adb_installs
  get_setting global stay_on_while_plugged_in
  get_setting secure mock_location

  printf '\n[properties]\n'
  get_prop init.svc.adbd
  get_prop service.adb.tcp.port
  get_prop persist.adb.tcp.port
  get_prop sys.usb.config
  get_prop persist.sys.usb.config
  get_prop ro.debuggable
  get_prop ro.secure
  get_prop ro.adb.secure

  print_adb_host_state
}

scan_action() {
  print_header
  print_adb_host_state

  if [ "$TRANSPORT" = "none" ]; then
    printf '\n[scan]\ntransport=none\n'
    return 0
  fi

  printf '\n[settings-global-debug]\n'
  run_device sh -c "settings list global 2>/dev/null | grep -Ei 'adb|debug|developer|wireless|tcp|usb' || true"

  printf '\n[settings-secure-debug]\n'
  run_device sh -c "settings list secure 2>/dev/null | grep -Ei 'adb|debug|developer|wireless|tcp|usb|mock' || true"

  printf '\n[properties-debug]\n'
  run_device sh -c "getprop 2>/dev/null | grep -Ei 'adb|debug|adbd|usb|tcp|wireless' || true"
}

enable_common() {
  print_header
  printf '\n[enable]\n'
  put_setting global development_settings_enabled 1
  put_setting global adb_enabled 1
}

enable_action() {
  enable_common
  status_action
}

enable_wireless_action() {
  enable_common
  put_setting global adb_wifi_enabled 1

  printf '\n[wireless]\n'
  if [ "$TRANSPORT" = "adb" ]; then
    adb_cmd tcpip "$TCP_PORT" 2>&1 | sed 's/^/adb.tcpip: /'
  else
    printf 'adb.tcpip=skipped transport=%s reason=requires connected adb transport\n' "$TRANSPORT"
  fi

  if [ "$RESTART_ADBD" = "1" ]; then
    if [ "$TRANSPORT" = "none" ]; then
      printf 'restart_adbd=skipped transport=none\n'
    else
      run_report "setprop.service.adb.tcp.port=$TCP_PORT" setprop service.adb.tcp.port "$TCP_PORT"
      run_report "setprop.persist.adb.tcp.port=$TCP_PORT" setprop persist.adb.tcp.port "$TCP_PORT"
      run_report "stop.adbd" stop adbd
      run_report "start.adbd" start adbd
    fi
  else
    printf 'restart_adbd=skipped set --restart-adbd to attempt privileged adbd restart\n'
  fi

  status_action
}

open_wireless_action() {
  print_header
  printf '\n[open-wireless]\n'
  if [ "$TRANSPORT" = "none" ]; then
    printf 'open_wireless=skipped transport=none\n'
    return 1
  fi

  run_report "open_wireless.primary" am start -a android.settings.WIRELESS_DEBUGGING_SETTINGS
  run_report "open_wireless.developer_options" am start -a android.settings.APPLICATION_DEVELOPMENT_SETTINGS
}

disable_action() {
  print_header
  printf '\n[disable]\n'
  put_setting global adb_wifi_enabled 0
  put_setting global adb_enabled 0
  status_action
}

help_action() {
  cat <<'EOF'
Usage:
  android-debug-switch.sh status [--mode=auto|adb|rish|local] [--serial=SERIAL]
  android-debug-switch.sh scan [--mode=auto|adb|rish|local]
  android-debug-switch.sh enable [--mode=adb|rish|local]
  android-debug-switch.sh enable-wireless [--mode=adb] [--port=5555] [--restart-adbd]
  android-debug-switch.sh open-wireless [--mode=adb|rish|local]
  android-debug-switch.sh disable [--mode=adb|rish|local]

Notes:
  - This does not bypass Android authorization, pairing, or OEM restrictions.
  - Writes usually require an authorized adb shell, Shizuku shell, root, or
    WRITE_SECURE_SETTINGS-level permission.
  - Wireless debugging pairing codes still must be approved by the device UI.
EOF
}

case "$ACTION" in
  status) status_action ;;
  scan) scan_action ;;
  enable) enable_action ;;
  enable-wireless) enable_wireless_action ;;
  open-wireless) open_wireless_action ;;
  disable) disable_action ;;
  help) help_action ;;
  *) printf 'Unknown action: %s\n\n' "$ACTION" >&2; help_action >&2; exit 2 ;;
esac
