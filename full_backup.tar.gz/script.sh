Mohon jelaskan jenis script apa yang Anda butuhkan, termasuk bahasa pemrograman dan fungsi spesifik yang diinginkan.

