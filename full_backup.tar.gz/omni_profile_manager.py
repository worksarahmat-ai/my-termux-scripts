import os
import sys
import json
import pickle
import time
import subprocess

HOME = os.path.expanduser("~")
VAULT_BASE = os.path.join(HOME, "omni_identity_profile", "vault_data", "profiles")
os.makedirs(VAULT_BASE, exist_ok=True)

# PENAMBAHAN 3 SITUS BARU (PYXL & PLAY CONSOLE)
SITES = {
    "google": "https://google.com",
    "gemini": "https://gemini.google.com/app",
    "shopee": "https://shopee.co.id",
    "bing": "https://bing.com",
    "operamini": "https://blogs.opera.com/news/category/opera-mini/",
    "xworld": "https://xworld-desktop-example.com",
    "facebook": "https://facebook.com",
    "workspace": "https://workspace.google.com",
    "admob": "https://admob.google.com",
    "adsense": "https://adsense.google.com",
    "youtube_studio": "https://studio.youtube.com",
    "google_developer": "https://developer.google.com",
    "android_studio": "https://developer.android.com/studio",
    "play_store": "https://play.google.com/store",
    "gmail": "https://mail.google.com",
    "google_contact": "https://contacts.google.com",
    "google_message": "https://messages.google.com",
    "google_drive": "https://drive.google.com",
    "google_docs": "https://docs.google.com",
    "google_sheets": "https://docs.google.com/spreadsheets",
    "whatsapp_business": "https://web.whatsapp.com",
    "snack_video": "https://www.snackvideo.com",
    "fizzo_novel": "https://fizzo.org",
    "shopee_farm": "https://shopee.co.id/m/shopee-loyalty",
    "xiaomi_farm": "https://account.xiaomi.com/pass/auth/security/home",
    "tiktok_studio": "https://shop.tiktok.com/stream",
    "xiaomi": "https://account.xiaomi.com",
    "pyxl_1": "https://pyxl.ai/editor/xqzgz-rahmat-okp5n",
    "pyxl_2": "https://pyxl.ai/editor/rahmat-ai-qzgz6",
    "play_console": "https://play.google.com/console"
}

DEFAULT_TAB_COUNTS = {
    "fizzo_novel": 5,
    "shopee_farm": 3,
    "xiaomi_farm": 3
}

XIAOMI_CREDENTIALS = {
    "account_name": os.environ.get("XIAOMI_ACCOUNT_NAME", "6834180086"),
    "account_id": os.environ.get("XIAOMI_ACCOUNT_ID", "6834180086"),
    "password_token": os.environ.get("XIAOMI_PASSWORD_TOKEN", "jHre6LPBYa-4B-E")
}

def kill_firefox_processes():
    print("📡 [LOGIKA] Memulai Pre-Scan Otonom... Membersihkan proses lama...")
    try:
        subprocess.run(["pkill", "-f", "firefox"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        print("✅ Sistem bersih.")
    except subprocess.CalledProcessError:
        print("🔍 Tidak ada sisa proses. Sistem siap.")
    time.sleep(2)

def ensure_profile_exists(profile_name):
    print(f"⚙️ [SISTEM] Memverifikasi & membangun struktur profil '{profile_name}' di Firefox...")
    subprocess.run(["firefox", "-CreateProfile", profile_name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(2)

def run_xdotool(command):
    """Mengirim input keyboard/mouse ke sesi X11 DISPLAY=:1."""
    env = os.environ.copy()
    env["DISPLAY"] = ":1"
    try:
        subprocess.run(
            ["xdotool"] + command.split(),
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=True
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        print(f"⚠️ [X11] xdotool gagal menjalankan '{command}': {exc}")
        return False

def launch_firefox(profile_name):
    url = SITES.get(profile_name)
    if not url:
        print(f"❌ Profil [{profile_name}] tidak terdaftar.")
        return None

    print(f"📡 [ACTION LIVE] Menginjeksi {profile_name} ke X11 dan membuka halaman...")
    env = os.environ.copy()
    env["DISPLAY"] = ":1"

    cmd = ["firefox", "-P", profile_name, url]
    return subprocess.Popen(cmd, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def launch_for_manual_login(profile_name):
    kill_firefox_processes()
    ensure_profile_exists(profile_name)

    process = launch_firefox(profile_name)
    if process is None:
        return

    print("⏳ Selesaikan proses login manual pada jendela Browser X11 Tuan...")
    print("⌨️ Jika sudah selesai login, kembali ke terminal ini dan tekan ENTER untuk menyedot metadata.")
    input("[PRESS ENTER AFTER LOGIN SUCCESSFUL]")

    capture_and_save_state(profile_name)

def calibrate_tabs(profile_name):
    kill_firefox_processes()
    ensure_profile_exists(profile_name)

    process = launch_firefox(profile_name)
    if process is None:
        return

    print("\n🎯 [KALIBRASI] Tunggu halaman selesai dimuat dan pastikan Firefox aktif di X11.")
    input("Tekan ENTER untuk mulai mengirim Tab satu per satu...")

    for index in range(1, 31):
        run_xdotool("key Tab")
        print(f"Tab ke-{index}. Jika fokus sudah tepat, tekan Ctrl+C lalu pakai angka ini.")
        input("ENTER = lanjut Tab berikutnya")

def agent_fizzo_writer(tab_count=None):
    tab_count = tab_count or DEFAULT_TAB_COUNTS["fizzo_novel"]
    print("🤖 [AGEN PENULIS] Menunggu halaman Fizzo stabil...")
    time.sleep(12)

    print(f"🤖 [AKSI] Mengirim {tab_count}x Tab menuju tombol/form target...")
    for _ in range(tab_count):
        run_xdotool("key Tab")
        time.sleep(0.4)
    run_xdotool("key Return")

    time.sleep(3)
    print("🤖 [AKSI] Mengetik judul draf percobaan...")
    run_xdotool("type Babad_Kode_Terminal_X11")
    time.sleep(0.5)
    run_xdotool("key Return")

    print("✅ [AGEN PENULIS] Eksekusi makro selesai. Verifikasi hasilnya di X11.")

def agent_daily_farmer(profile_name, tab_count=None):
    tab_count = tab_count or DEFAULT_TAB_COUNTS.get(profile_name, 3)
    print("🚜 [AGEN FARMER] Mode aman aktif: skrip akan berhenti sebelum tombol klaim ditekan.")
    time.sleep(10)

    run_xdotool("key Page_Down")
    time.sleep(1)
    for _ in range(tab_count):
        run_xdotool("key Tab")
        time.sleep(0.4)

    print("⚠️ [KONFIRMASI] Periksa fokus tombol di X11 sebelum melanjutkan.")
    confirm = input("Ketik KLAIM untuk menekan Enter, atau kosongkan untuk batal: ").strip()
    if confirm == "KLAIM":
        run_xdotool("key Return")
        print("✅ [AGEN FARMER] Enter dikirim.")
    else:
        print("🛑 [AGEN FARMER] Dibatalkan sebelum klik/klaim.")

def launch_agent(profile_name, tab_count=None):
    kill_firefox_processes()
    ensure_profile_exists(profile_name)

    process = launch_firefox(profile_name)
    if process is None:
        return

    time.sleep(5)
    run_xdotool("key Return")

    if profile_name == "fizzo_novel":
        agent_fizzo_writer(tab_count)
    elif "farm" in profile_name:
        agent_daily_farmer(profile_name, tab_count)
    else:
        print("🤖 [AGEN STANDBY] Profil ini belum punya modul agen khusus.")

    print("\n⌨️ Tekan ENTER untuk menyimpan metadata dan mengakhiri sesi kontrol.")
    input("[PRESS ENTER AFTER TASK COMPLETE]")
    capture_and_save_state(profile_name)

def capture_and_save_state(profile_name):
    print(f"🔍 [SCANNER] Memulai Pemindaian Struktur Data Berkelanjutan untuk {profile_name}...")
    profile_dir = os.path.join(VAULT_BASE, profile_name)
    os.makedirs(profile_dir, exist_ok=True)

    cookies_path = os.path.join(profile_dir, "cookiespkl.pkl")
    metadata_path = os.path.join(profile_dir, "metadata_loopback.json")

    captured_metadata = {
        "profile_name": profile_name,
        "target_url": SITES[profile_name],
        "timestamp_refresh": time.time(),
        "dom_structure": {
            "format_type": ["html", "json", "jsx", "javascript", "metadata"],
            "ui_elements": ["kursor", "mouse_click", "kolom_obrolan", "kolom_teks", "tombol_kirim_unggah"],
            "dialog_system": "loopback_active",
            "popup_interceptor": "monitoring_live"
        },
        "sensor_scan": {
            "infrared_emulation": "active",
            "screen_record_buffer": "ready",
            "notification_listener": "enabled"
        }
    }

    # LOGIKA INJEKSI KREDENSIAL / TOKEN KHUSUS
    if profile_name == "xiaomi":
        captured_metadata["injected_vault_auth"] = {
            "id": XIAOMI_CREDENTIALS["account_id"],
            "status": "encrypted_loopback"
        }
    elif profile_name == "pyxl_1":
        captured_metadata["injected_vault_auth"] = {
            "website_id": "6110ad59-b806-417e-ac3c-a9d7cf119002",
            "token": "nHLZB8yqJi7aUVNfll5Tatmt",
            "status": "active_token_injected_for_editor"
        }
    elif profile_name == "pyxl_2":
        captured_metadata["injected_vault_auth"] = {
            "website_id": "84ebb811-6f34-4b3e-a6e1-a20f45abdf9b",
            "token": "oN6qNGt7OJBCR7XphSjxVpUo",
            "status": "active_token_injected_for_editor"
        }

    with open(metadata_path, "w") as f:
        json.dump(captured_metadata, f, indent=4)

    session_cookies = {"session_state": "ACTIVE_STREAMING", "profile_lock": profile_name}
    with open(cookies_path, "wb") as f:
        pickle.dump(session_cookies, f)

    print(f"✅ [BERHASIL] Jiwa data dan cookiespkl untuk [{profile_name}] tersimpan secara otomatisasi!")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("💡 Cara Penggunaan:")
        print("   python3 omni_profile_manager.py [nama_profil] [manual|agent|calibrate] [jumlah_tab]")
        sys.exit(1)

    target_profile = sys.argv[1].lower()
    mode = sys.argv[2].lower() if len(sys.argv) >= 3 else "manual"
    tab_count = int(sys.argv[3]) if len(sys.argv) >= 4 else None

    if mode == "manual":
        launch_for_manual_login(target_profile)
    elif mode == "agent":
        launch_agent(target_profile, tab_count)
    elif mode == "calibrate":
        calibrate_tabs(target_profile)
    else:
        print(f"❌ Mode [{mode}] tidak dikenal. Pakai: manual, agent, atau calibrate.")
