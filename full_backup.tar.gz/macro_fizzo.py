import time


class FizzoKeyboardMacro:
    def __init__(self, config, checkpoint, xdotool, scanner):
        self.config = config
        self.checkpoint = checkpoint
        self.xdotool = xdotool
        self.scanner = scanner

    def guard(self, text):
        lowered = (text or "").lower()
        hits = [word for word in self.config["guardrails"]["stopWords"] if word.lower() in lowered]
        if hits:
            self.checkpoint.save_state("STOP_RISK", source="macro_ocr", hits=hits)
            return False
        return True

    def run_writer_calibration(self):
        mode = self.config["mode"].upper()
        if mode == "AUTO_RUN":
            self.checkpoint.save_state("STOP_MACRO_AUTO_RUN", reason="Keyboard macro tidak diizinkan untuk submit otomatis.")
            return {
                "status": "STOP_MACRO_AUTO_RUN",
                "reason": "Keyboard macro hanya untuk DRY_RUN/SAFE_RUN.",
            }

        initial_text = self.scanner.scan_text()
        if not self.guard(initial_text):
            return {"status": "STOP_RISK"}

        tab_count = int(self.config.get("macro", {}).get("newStoryTabs", 5))
        title = self.config.get("macro", {}).get("draftTitle", "Babad Kode Terminal X11")
        pause = float(self.config["timeouts"].get("step_pause_seconds", 1.0))

        self.checkpoint.save_state(
            "MACRO_CALIBRATION_START",
            tab_count=tab_count,
            mode=mode,
            title_preview=title,
        )

        for index in range(tab_count):
            self.xdotool.key("Tab")
            self.checkpoint.log("macro_tab", index=index + 1, total=tab_count)
            time.sleep(0.45)

        self.scanner.screenshot()

        if mode == "DRY_RUN":
            self.checkpoint.save_state("STOP_BEFORE_ENTER", reason="DRY_RUN hanya kalibrasi posisi fokus.")
            return {
                "status": "STOP_BEFORE_ENTER",
                "tab_count": tab_count,
                "note": "Lihat screenshot artifact untuk memastikan fokus sudah di tombol yang benar.",
            }

        self.xdotool.key("Return")
        time.sleep(max(2.0, pause * 2))

        after_enter_text = self.scanner.scan_text()
        if not self.guard(after_enter_text):
            return {"status": "STOP_RISK"}

        self.xdotool.type_text(title)
        self.checkpoint.log("macro_type_title", length=len(title))
        self.scanner.screenshot()

        self.checkpoint.save_state("STOP_BEFORE_SUBMIT", reason="SAFE_RUN selesai mengetik draft, tidak submit.")
        return {
            "status": "STOP_BEFORE_SUBMIT",
            "tab_count": tab_count,
            "typed_title": True,
        }

    def run_writer_button_click(self):
        mode = self.config["mode"].upper()
        point = self.config.get("macro", {}).get("writerButton", {})
        x = int(point.get("x", 225))
        y = int(point.get("y", 505))

        initial_text = self.scanner.scan_text()
        if not self.guard(initial_text):
            return {"status": "STOP_RISK"}

        self.checkpoint.save_state("WRITER_BUTTON_TARGET", x=x, y=y, mode=mode)
        self.scanner.screenshot()

        if mode == "DRY_RUN":
            self.checkpoint.save_state(
                "STOP_BEFORE_CLICK",
                reason="DRY_RUN hanya menandai koordinat tombol.",
                x=x,
                y=y,
            )
            return {
                "status": "STOP_BEFORE_CLICK",
                "x": x,
                "y": y,
                "note": "Jika koordinat tepat, jalankan SAFE_RUN.",
            }

        if mode != "SAFE_RUN":
            self.checkpoint.save_state("STOP_UNSAFE_MODE", reason="Klik koordinat hanya diizinkan pada SAFE_RUN.")
            return {"status": "STOP_UNSAFE_MODE"}

        self.xdotool.click(x, y)
        time.sleep(4)
        after_text = self.scanner.scan_text()
        if not self.guard(after_text):
            return {"status": "STOP_RISK"}

        self.checkpoint.save_state(
            "STOP_AFTER_WRITER_BUTTON_CLICK",
            preview=after_text[:1000],
            x=x,
            y=y,
        )
        return {
            "status": "STOP_AFTER_WRITER_BUTTON_CLICK",
            "x": x,
            "y": y,
            "preview": after_text[:500],
        }
