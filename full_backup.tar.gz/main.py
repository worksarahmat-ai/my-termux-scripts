from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.routes import terminal, system, brain, terminal_ws, file_manager, database
from backend.models.database import init_db

app = FastAPI(title="AIBashira Advanced Backend", version="9.0")

# Initialize DB
init_db()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(terminal.router, prefix="/api", tags=["Terminal"])
app.include_router(system.router, prefix="/api/system", tags=["System"])
app.include_router(brain.router, prefix="/api/brain", tags=["Brain"])
app.include_router(terminal_ws.router, tags=["WebSocket"])
app.include_router(file_manager.router, prefix="/api/files", tags=["File Manager"])
app.include_router(database.router, prefix="/api/db", tags=["Database"])

@app.get("/")
async def root():
    return {"message": "AIBashira Advanced Backend Online"}
