import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { request as httpsRequest } from 'node:https';
import { WebSocketServer } from 'ws';

// --- KONFIGURASI ---
const PORT = 8080;
const AI_ENDPOINT = "https://omniscient-ai-assistant--rahmatautomatio.replit.app/api/chat";
const API_VERSION = '5.0';
const AUTH_TOKEN = process.env.NOVA_BRIDGE_TOKEN || process.env.BRIDGE_AUTH_TOKEN || '';
const DEFAULT_TIMEOUT_MS = 10_000;
const MAX_TIMEOUT_MS = 10 * 60 * 1000;
const DEFAULT_MAX_OUTPUT_BYTES = 256 * 1024;
const MAX_OUTPUT_BYTES = 1024 * 1024;
const MAX_BODY_BYTES = 1024 * 1024;
const MAX_STORED_JOBS = 100;
const jobs = new Map();
const DASHBOARD_FILE = new URL('./nova-bridge-dashboard.html', import.meta.url);
const DOCS_FILE = new URL('./NOVA_BRIDGE_API.md', import.meta.url);

function sendJson(res, statusCode, payload) {
    if (res.writableEnded) return;
    res.writeHead(statusCode, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(payload));
}

async function sendFile(res, fileUrl, contentType) {
    const content = await readFile(fileUrl, 'utf8');
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(content);
}

function isPlainObject(value) {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function isAuthEnabled() {
    return AUTH_TOKEN.length > 0;
}

function extractRequestToken(req, parsedUrl, options = {}) {
    const allowQueryToken = options.allowQueryToken === true;
    const authHeader = req.headers.authorization || '';
    if (authHeader.startsWith('Bearer ')) {
        return authHeader.slice(7).trim();
    }

    const apiTokenHeader = req.headers['x-api-token'];
    if (typeof apiTokenHeader === 'string' && apiTokenHeader.trim()) {
        return apiTokenHeader.trim();
    }

    if (allowQueryToken && parsedUrl?.searchParams?.has('token')) {
        const queryToken = parsedUrl.searchParams.get('token') || '';
        if (queryToken.trim()) {
            return queryToken.trim();
        }
    }

    return '';
}

function isAuthorized(req, parsedUrl, options = {}) {
    if (!isAuthEnabled()) return true;
    return extractRequestToken(req, parsedUrl, options) === AUTH_TOKEN;
}

function authMeta(req, parsedUrl) {
    return {
        required: isAuthEnabled(),
        authorized: isAuthorized(req, parsedUrl),
        envVars: ['NOVA_BRIDGE_TOKEN', 'BRIDGE_AUTH_TOKEN'],
        accepted: [
            'Authorization: Bearer <token>',
            'x-api-token: <token>',
            'query ?token=<token> untuk WebSocket'
        ]
    };
}

function requireAuth(req, res, parsedUrl) {
    if (isAuthorized(req, parsedUrl)) {
        return true;
    }

    res.setHeader('WWW-Authenticate', 'Bearer realm="NovaBridge"');
    sendJson(res, 401, {
        error: 'Unauthorized',
        message: 'Token tidak valid atau belum dikirim',
        auth: authMeta(req, parsedUrl)
    });
    return false;
}

function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}

function appendOutput(current, chunkText, maxBytes) {
    const currentBytes = Buffer.byteLength(current, 'utf8');
    const remainingBytes = maxBytes - currentBytes;
    if (remainingBytes <= 0) {
        return { value: current, truncated: true };
    }

    const chunkBuffer = Buffer.from(chunkText);
    if (chunkBuffer.byteLength <= remainingBytes) {
        return { value: current + chunkText, truncated: false };
    }

    return {
        value: current + chunkBuffer.subarray(0, remainingBytes).toString('utf8'),
        truncated: true
    };
}

function buildEnv(customEnv) {
    const env = { ...process.env };
    if (!isPlainObject(customEnv)) return env;

    for (const [key, value] of Object.entries(customEnv)) {
        if (['string', 'number', 'boolean'].includes(typeof value)) {
            env[key] = String(value);
        }
    }

    return env;
}

async function readJsonBody(req) {
    return await new Promise((resolve, reject) => {
        let body = '';
        let totalBytes = 0;

        req.on('data', (chunk) => {
            totalBytes += chunk.length;
            if (totalBytes > MAX_BODY_BYTES) {
                const error = new Error('Request body terlalu besar');
                error.statusCode = 413;
                reject(error);
                req.destroy();
                return;
            }
            body += chunk.toString();
        });

        req.on('end', () => {
            if (!body.trim()) {
                resolve({});
                return;
            }

            try {
                resolve(JSON.parse(body));
            } catch {
                const error = new Error('Body JSON tidak valid');
                error.statusCode = 400;
                reject(error);
            }
        });

        req.on('error', reject);
    });
}

function createExecutionOptions(payload = {}) {
    const command = typeof payload.command === 'string' ? payload.command.trim() : '';
    if (!command) {
        const error = new Error('Field "command" wajib diisi');
        error.statusCode = 400;
        throw error;
    }

    const requestedTimeout = Number(payload.timeout);
    const timeoutMs = Number.isFinite(requestedTimeout)
        ? clamp(Math.floor(requestedTimeout), 1, MAX_TIMEOUT_MS)
        : DEFAULT_TIMEOUT_MS;

    const requestedMaxOutput = Number(payload.maxOutputBytes);
    const maxOutputBytes = Number.isFinite(requestedMaxOutput)
        ? clamp(Math.floor(requestedMaxOutput), 1_024, MAX_OUTPUT_BYTES)
        : DEFAULT_MAX_OUTPUT_BYTES;

    return {
        name: typeof payload.name === 'string' && payload.name.trim() ? payload.name.trim() : null,
        command,
        cwd: typeof payload.cwd === 'string' && payload.cwd.trim() ? payload.cwd.trim() : process.cwd(),
        shell: typeof payload.shell === 'string' && payload.shell.trim() ? payload.shell.trim() : (process.env.SHELL || 'sh'),
        timeoutMs,
        maxOutputBytes,
        env: buildEnv(payload.env)
    };
}

function formatExecutionResponse(options, result) {
    const output = result.stdout || result.stderr;
    return {
        ok: result.exitCode === 0 && !result.timedOut && !result.error,
        name: options.name,
        command: options.command,
        cwd: options.cwd,
        shell: options.shell,
        pid: result.pid,
        exitCode: result.exitCode,
        signal: result.signal,
        timedOut: result.timedOut,
        durationMs: result.durationMs,
        outputTruncated: result.outputTruncated,
        output,
        stdout: result.stdout,
        stderr: result.stderr,
        error: result.error
    };
}

function serializeJob(job, includeOutput = true) {
    const payload = {
        id: job.id,
        name: job.name,
        command: job.command,
        cwd: job.cwd,
        shell: job.shell,
        timeoutMs: job.timeoutMs,
        pid: job.pid,
        status: job.status,
        createdAt: job.createdAt,
        updatedAt: job.updatedAt,
        finishedAt: job.finishedAt,
        exitCode: job.exitCode,
        signal: job.signal,
        timedOut: job.timedOut,
        durationMs: job.durationMs,
        outputTruncated: job.outputTruncated,
        error: job.error
    };

    if (includeOutput) {
        payload.output = job.stdout || job.stderr;
        payload.stdout = job.stdout;
        payload.stderr = job.stderr;
    }

    return payload;
}

function pruneJobs() {
    if (jobs.size <= MAX_STORED_JOBS) return;

    const removable = [...jobs.values()]
        .filter((job) => job.status !== 'running' && job.status !== 'cancelling')
        .sort((a, b) => new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime());

    while (jobs.size > MAX_STORED_JOBS && removable.length > 0) {
        jobs.delete(removable.shift().id);
    }
}

function killCommandProcess(child, signal = 'SIGTERM') {
    if (!child) return false;

    try {
        if (child.pid) {
            process.kill(-child.pid, signal);
            return true;
        }
    } catch {}

    try {
        return child.kill(signal);
    } catch {
        return false;
    }
}

function executeCommand(options, hooks = {}) {
    const startedAt = Date.now();
    const child = spawn(options.shell, ['-lc', options.command], {
        cwd: options.cwd,
        env: options.env,
        detached: true,
        stdio: ['ignore', 'pipe', 'pipe']
    });

    let stdout = '';
    let stderr = '';
    let outputTruncated = false;
    let timedOut = false;
    let spawnError = null;
    let forceKillTimer = null;

    const killTimer = setTimeout(() => {
        timedOut = true;
        killCommandProcess(child, 'SIGTERM');
        forceKillTimer = setTimeout(() => killCommandProcess(child, 'SIGKILL'), 1000);
    }, options.timeoutMs);

    const onData = (streamName, chunk) => {
        const text = chunk.toString();
        if (streamName === 'stdout') {
            const appended = appendOutput(stdout, text, options.maxOutputBytes);
            stdout = appended.value;
            outputTruncated = outputTruncated || appended.truncated;
        } else {
            const appended = appendOutput(stderr, text, options.maxOutputBytes);
            stderr = appended.value;
            outputTruncated = outputTruncated || appended.truncated;
        }

        if (hooks.onOutput) {
            hooks.onOutput(streamName, text);
        }
    };

    child.stdout.on('data', (chunk) => onData('stdout', chunk));
    child.stderr.on('data', (chunk) => onData('stderr', chunk));
    child.on('error', (error) => {
        spawnError = error;
        if (hooks.onError) hooks.onError(error);
    });

    const completion = new Promise((resolve) => {
        child.on('close', (exitCode, signal) => {
            clearTimeout(killTimer);
            clearTimeout(forceKillTimer);
            resolve({
                pid: child.pid ?? null,
                exitCode,
                signal,
                timedOut,
                durationMs: Date.now() - startedAt,
                outputTruncated,
                stdout,
                stderr,
                error: spawnError ? spawnError.message : null
            });
        });
    });

    return { child, completion };
}

async function runCommandOnce(options) {
    const { completion } = executeCommand(options);
    return await completion;
}

function createJob(options) {
    const now = new Date().toISOString();
    const job = {
        id: randomUUID(),
        name: options.name,
        command: options.command,
        cwd: options.cwd,
        shell: options.shell,
        timeoutMs: options.timeoutMs,
        pid: null,
        status: 'running',
        createdAt: now,
        updatedAt: now,
        finishedAt: null,
        exitCode: null,
        signal: null,
        timedOut: false,
        durationMs: null,
        outputTruncated: false,
        stdout: '',
        stderr: '',
        error: null,
        child: null
    };

    jobs.set(job.id, job);
    pruneJobs();

    const { child, completion } = executeCommand(options, {
        onOutput(streamName, text) {
            if (streamName === 'stdout') {
                const appended = appendOutput(job.stdout, text, options.maxOutputBytes);
                job.stdout = appended.value;
                job.outputTruncated = job.outputTruncated || appended.truncated;
            } else {
                const appended = appendOutput(job.stderr, text, options.maxOutputBytes);
                job.stderr = appended.value;
                job.outputTruncated = job.outputTruncated || appended.truncated;
            }
            job.updatedAt = new Date().toISOString();
        },
        onError(error) {
            job.error = error.message;
            job.updatedAt = new Date().toISOString();
        }
    });

    job.pid = child.pid ?? null;
    job.child = child;

    completion.then((result) => {
        job.exitCode = result.exitCode;
        job.signal = result.signal;
        job.timedOut = result.timedOut;
        job.durationMs = result.durationMs;
        job.outputTruncated = job.outputTruncated || result.outputTruncated;
        job.stdout = result.stdout;
        job.stderr = result.stderr;
        job.error = result.error;
        job.status = result.timedOut ? 'timeout' : (result.exitCode === 0 ? 'completed' : 'failed');
        job.finishedAt = new Date().toISOString();
        job.updatedAt = job.finishedAt;
        job.child = null;
    });

    return job;
}

function cancelJob(job) {
    if (!job || !job.child || (job.status !== 'running' && job.status !== 'cancelling')) {
        return false;
    }

    job.status = 'cancelling';
    job.updatedAt = new Date().toISOString();
    const killed = killCommandProcess(job.child, 'SIGTERM');
    setTimeout(() => {
        if (job.child) {
            killCommandProcess(job.child, 'SIGKILL');
        }
    }, 1000);
    return killed;
}

function sendSse(res, event, payload) {
    res.write(`event: ${event}\n`);
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
}

async function handleExecuteStream(req, res) {
    const payload = await readJsonBody(req);
    const options = createExecutionOptions(payload);

    console.log(`[API EXEC STREAM] ${options.command}`);

    res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache, no-transform',
        'Connection': 'keep-alive'
    });

    const { child, completion } = executeCommand(options, {
        onOutput(streamName, text) {
            sendSse(res, streamName, { chunk: text });
        },
        onError(error) {
            sendSse(res, 'spawn_error', { message: error.message });
        }
    });

    const stopChild = () => killCommandProcess(child, 'SIGTERM');
    req.on('close', stopChild);

    sendSse(res, 'start', {
        name: options.name,
        command: options.command,
        cwd: options.cwd,
        shell: options.shell,
        timeoutMs: options.timeoutMs,
        pid: child.pid ?? null
    });

    const result = await completion;
    sendSse(res, 'end', formatExecutionResponse(options, result));
    res.end();
}

async function routeRequest(req, res, parsedUrl) {
    const { pathname, searchParams } = parsedUrl;

    if ((pathname === '/' || pathname === '/dashboard') && req.method === 'GET') {
        await sendFile(res, DASHBOARD_FILE, 'text/html; charset=utf-8');
        return;
    }

    if (pathname === '/docs' && req.method === 'GET') {
        await sendFile(res, DOCS_FILE, 'text/markdown; charset=utf-8');
        return;
    }

    if (pathname === '/api/status' && req.method === 'GET') {
        const allJobs = [...jobs.values()];
        sendJson(res, 200, {
            status: 'online',
            role: 'nova_bridge',
            version: API_VERSION,
            auth: authMeta(req, parsedUrl),
            jobs: {
                total: allJobs.length,
                running: allJobs.filter((job) => job.status === 'running' || job.status === 'cancelling').length,
                completed: allJobs.filter((job) => job.status === 'completed').length,
                failed: allJobs.filter((job) => job.status === 'failed' || job.status === 'timeout').length
            },
            execute: {
                supportsAsync: true,
                supportsStreaming: true,
                supportsCancel: true,
                defaultTimeoutMs: DEFAULT_TIMEOUT_MS,
                maxTimeoutMs: MAX_TIMEOUT_MS
            }
        });
        return;
    }

    if (pathname === '/api/capabilities' && req.method === 'GET') {
        sendJson(res, 200, {
            version: API_VERSION,
            auth: {
                required: isAuthEnabled(),
                envVars: ['NOVA_BRIDGE_TOKEN', 'BRIDGE_AUTH_TOKEN']
            },
            endpoints: [
                { method: 'GET', path: '/', description: 'Buka dashboard web bawaan' },
                { method: 'GET', path: '/dashboard', description: 'Dashboard kontrol Nova Bridge' },
                { method: 'GET', path: '/docs', description: 'Dokumentasi Markdown bawaan' },
                { method: 'GET', path: '/api/status', description: 'Status server dan ringkasan job' },
                { method: 'GET', path: '/api/capabilities', description: 'Daftar kemampuan API' },
                { method: 'GET', path: '/api/auth/check', description: 'Validasi token aktif' },
                { method: 'POST', path: '/api/execute', description: 'Eksekusi sinkron atau async jika body.async=true' },
                { method: 'POST', path: '/api/execute/async', description: 'Eksekusi background dan kembalikan jobId' },
                { method: 'POST', path: '/api/execute/stream', description: 'Streaming stdout/stderr via SSE' },
                { method: 'GET', path: '/api/jobs', description: 'Daftar job tersimpan' },
                { method: 'GET', path: '/api/jobs/:id', description: 'Detail job' },
                { method: 'POST', path: '/api/jobs/:id/cancel', description: 'Hentikan job yang sedang berjalan' },
                { method: 'DELETE', path: '/api/jobs/:id', description: 'Hapus job dari memori' }
            ],
            executePayload: {
                command: 'string',
                cwd: 'string (opsional)',
                shell: 'string (opsional)',
                timeout: 'number ms (opsional)',
                env: 'object key/value (opsional)',
                maxOutputBytes: 'number (opsional)',
                async: 'boolean (opsional untuk /api/execute)'
            }
        });
        return;
    }

    if (pathname === '/api/auth/check' && req.method === 'GET') {
        if (!requireAuth(req, res, parsedUrl)) {
            return;
        }

        sendJson(res, 200, {
            ok: true,
            authenticated: true,
            version: API_VERSION
        });
        return;
    }

    if (pathname === '/api/execute' && req.method === 'POST') {
        if (!requireAuth(req, res, parsedUrl)) {
            return;
        }

        const payload = await readJsonBody(req);
        const options = createExecutionOptions(payload);

        console.log(`[API EXEC] ${options.command}`);

        if (payload.async === true) {
            const job = createJob(options);
            sendJson(res, 202, {
                accepted: true,
                jobId: job.id,
                job: serializeJob(job, false),
                endpoints: {
                    status: `/api/jobs/${job.id}`,
                    cancel: `/api/jobs/${job.id}/cancel`
                }
            });
            return;
        }

        const result = await runCommandOnce(options);
        sendJson(res, 200, formatExecutionResponse(options, result));
        return;
    }

    if (pathname === '/api/execute/async' && req.method === 'POST') {
        if (!requireAuth(req, res, parsedUrl)) {
            return;
        }

        const payload = await readJsonBody(req);
        const options = createExecutionOptions(payload);

        console.log(`[API EXEC ASYNC] ${options.command}`);

        const job = createJob(options);
        sendJson(res, 202, {
            accepted: true,
            jobId: job.id,
            job: serializeJob(job, false),
            endpoints: {
                status: `/api/jobs/${job.id}`,
                cancel: `/api/jobs/${job.id}/cancel`
            }
        });
        return;
    }

    if (pathname === '/api/execute/stream' && req.method === 'POST') {
        if (!requireAuth(req, res, parsedUrl)) {
            return;
        }

        await handleExecuteStream(req, res);
        return;
    }

    if (pathname === '/api/jobs' && req.method === 'GET') {
        if (!requireAuth(req, res, parsedUrl)) {
            return;
        }

        const includeOutput = searchParams.get('output') === '1';
        sendJson(res, 200, {
            total: jobs.size,
            jobs: [...jobs.values()].map((job) => serializeJob(job, includeOutput))
        });
        return;
    }

    const cancelMatch = pathname.match(/^\/api\/jobs\/([^/]+)\/cancel$/);
    if (cancelMatch && req.method === 'POST') {
        if (!requireAuth(req, res, parsedUrl)) {
            return;
        }

        const jobId = decodeURIComponent(cancelMatch[1]);
        const job = jobs.get(jobId);
        if (!job) {
            sendJson(res, 404, { error: 'Job tidak ditemukan' });
            return;
        }

        if (!cancelJob(job)) {
            sendJson(res, 409, { error: 'Job tidak sedang berjalan', job: serializeJob(job, false) });
            return;
        }

        sendJson(res, 202, { cancelled: true, job: serializeJob(job, false) });
        return;
    }

    const jobMatch = pathname.match(/^\/api\/jobs\/([^/]+)$/);
    if (jobMatch && req.method === 'GET') {
        if (!requireAuth(req, res, parsedUrl)) {
            return;
        }

        const jobId = decodeURIComponent(jobMatch[1]);
        const job = jobs.get(jobId);
        if (!job) {
            sendJson(res, 404, { error: 'Job tidak ditemukan' });
            return;
        }

        sendJson(res, 200, serializeJob(job, true));
        return;
    }

    if (jobMatch && req.method === 'DELETE') {
        if (!requireAuth(req, res, parsedUrl)) {
            return;
        }

        const jobId = decodeURIComponent(jobMatch[1]);
        const job = jobs.get(jobId);
        if (!job) {
            sendJson(res, 404, { error: 'Job tidak ditemukan' });
            return;
        }

        if (job.status === 'running' || job.status === 'cancelling') {
            sendJson(res, 409, { error: 'Job masih berjalan dan tidak bisa dihapus' });
            return;
        }

        jobs.delete(jobId);
        sendJson(res, 200, { deleted: true, jobId });
        return;
    }

    sendJson(res, 404, { error: 'Not Found' });
}

// --- HTTP SERVER (API EXECUTE & STATUS) ---
const server = createServer((req, res) => {
    const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    // Setup CORS (Agar bisa diakses dari file HTML manapun)
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, GET, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Token');

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    routeRequest(req, res, parsedUrl).catch((error) => {
        const statusCode = error.statusCode || 500;
        sendJson(res, statusCode, { error: error.message || 'Internal Server Error' });
    });
});

// --- WEBSOCKET SERVER (Realtime Terminal) ---
const wss = new WebSocketServer({ server });

console.log(`\n=========================================`);
console.log(`   NOVA HYPER-BRIDGE V${API_VERSION} (API+WS)`);
console.log(`=========================================`);
console.log(`[NET] WebSocket: ws://localhost:${PORT}`);
console.log(`[NET] API Exec : http://localhost:${PORT}/api/execute`);
console.log(`[AUTH] ${isAuthEnabled() ? 'ENABLED via NOVA_BRIDGE_TOKEN/BRIDGE_AUTH_TOKEN' : 'DISABLED'}`);

wss.on('connection', (ws, request) => {
    const requestUrl = new URL(request.url, `http://${request.headers.host || 'localhost'}`);
    if (!isAuthorized(request, requestUrl, { allowQueryToken: true })) {
        ws.close(4401, 'Unauthorized');
        return;
    }

    console.log('[CONN] Web Client Terhubung.');

    // Spawn Bash Shell Persisten
    const shell = spawn(process.env.SHELL || 'bash', ['-i'], {
        env: { ...process.env, TERM: 'xterm-256color' }
    });

    // Kirim Output Terminal ke Web
    const sendTerm = (data) => ws.send(`::TERM::${data.toString()}`);
    shell.stdout.on('data', sendTerm);
    shell.stderr.on('data', sendTerm);

    // Terima Pesan dari Web
    ws.on('message', (message) => {
        const msgStr = message.toString();

        if (msgStr.startsWith('::AI::')) {
            const prompt = msgStr.replace('::AI::', '');
            handleAiProxy(prompt, ws);
        } else {
            shell.stdin.write(msgStr + '\n');
        }
    });

    ws.on('close', () => shell.kill());
});

// --- AI PROXY (Bypass CORS) ---
function handleAiProxy(prompt, ws) {
    const req = httpsRequest(AI_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    }, (res) => {
        res.on('data', (chunk) => {
            const lines = chunk.toString().split('\n');
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const jsonStr = line.replace('data: ', '').trim();
                    if (jsonStr === '[DONE]') return;
                    try {
                        const parsed = JSON.parse(jsonStr);
                        if (parsed.content) ws.send(`::AI-RES::${parsed.content}`);
                    } catch (e) {}
                }
            }
        });
    });
    req.write(JSON.stringify({ messages: [{ role: "user", content: prompt }] }));
    req.end();
}

server.listen(PORT);
