import json
import pathlib
import time


class Checkpoint:
    def __init__(self, root):
        self.root = pathlib.Path(root)
        self.logs_dir = self.root / "logs"
        self.checkpoints_dir = self.root / "checkpoints"
        self.artifacts_dir = self.root / "artifacts"
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoints_dir.mkdir(parents=True, exist_ok=True)
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = self.logs_dir / "basmalah.jsonl"
        self.state_path = self.checkpoints_dir / "last_state.json"

    def stamp(self):
        return time.strftime("%Y%m%d-%H%M%S")

    def log(self, event, **data):
        record = {
            "ts": time.time(),
            "event": event,
            **data,
        }
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        return record

    def save_state(self, state, **data):
        payload = {
            "ts": time.time(),
            "state": state,
            **data,
        }
        self.state_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        self.log("state", **payload)
        return payload

    def artifact_path(self, prefix, suffix):
        return self.artifacts_dir / f"{prefix}-{self.stamp()}.{suffix}"
