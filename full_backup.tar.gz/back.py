import http.server
import socketserver
import subprocess
import json
import threading
import os
import time
import random
import re
from urllib.parse import unquote

# --- SELENIUM DEPENDENCIES ---
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# ==========================================
# NEXUS V24 CONFIGURATION
# ==========================================
PORT_API = 8081
WORKING_DIR = "/root/Project_Palestine"
PROFILE_PATH = os.path.expanduser("~/.mozilla/firefox/worker") 

GEMINI_WEB_URL = "https://gemini.google.com/app"
BING_URL = "https://www.bing.com"
KEYWORDS = ["berita hari ini", "harga emas", "tutorial python", "info cuaca", "resep makanan"]
SOVEREIGN_PIN = "7788"

class NexusBrain:
    def __init__(self):
        self.driver = None
        self.public_url = "Connecting..."
        self.total_searches = 0
        self.is_chatting = False 
        
        if not os.path.exists(WORKING_DIR): os.makedirs(WORKING_DIR)

        threading.Thread(target=self.init_browser, daemon=True).start()
        threading.Thread(target=self.start_tunnel, daemon=True).start()

    def init_browser(self):
        print(f"🔄 [SYSTEM] Loading Profile: {PROFILE_PATH}")
        os.system(f"rm -f {PROFILE_PATH}/lock {PROFILE_PATH}/.parentlock")
        
        options = Options()
        options.add_argument("-profile")
        options.add_argument(PROFILE_PATH)
        options.add_argument("--headless") 
        options.add_argument("--width=1200")
        options.add_argument("--height=1000")
        
        gecko_path = "/data/data/com.termux/files/usr/bin/geckodriver"
        if not os.path.exists(gecko_path): gecko_path = "/usr/bin/geckodriver"

        try:
            self.driver = webdriver.Firefox(service=Service(gecko_path), options=options)
            print("✅ [SYSTEM] Browser Online.")
            threading.Thread(target=self.farming_loop, daemon=True).start()
        except Exception as e:
            print(f"❌ [ERROR] Browser failed: {e}")

    def chat_with_gemini_web(self, user_prompt):
        if not self.driver: return "Browser not ready."
        self.is_chatting = True
        try:
            self.driver.get(GEMINI_WEB_URL)
            time.sleep(4)
            input_box = WebDriverWait(self.driver, 15).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "div[contenteditable='true']"))
            )
            input_box.clear()
            full_prompt = f"Jawab singkat. Jika perintah linux, awali 'CMD:'. Prompt: {user_prompt}"
            input_box.send_keys(full_prompt)
            input_box.send_keys(Keys.RETURN)

            time.sleep(10) 
            responses = self.driver.find_elements(By.CSS_SELECTOR, ".model-response-text")
            return responses[-1].text if responses else "No response detected."
        except Exception as e:
            return f"Web Error: {str(e)}"
        finally:
            self.is_chatting = False

    def farming_loop(self):
        while True:
            if self.is_chatting: 
                time.sleep(5)
                continue
            try:
                query = random.choice(KEYWORDS)
                self.driver.get(BING_URL)
                time.sleep(2)
                box = self.driver.find_element(By.NAME, "q")
                box.send_keys(query + Keys.RETURN)
                self.total_searches += 1
                time.sleep(random.randint(60, 180))
            except:
                time.sleep(10)

    def start_tunnel(self):
        log = os.path.join(WORKING_DIR, "tunnel.log")
        os.system("pkill cloudflared")
        os.system(f"cloudflared tunnel --url http://127.0.0.1:{PORT_API} --logfile {log} > /dev/null 2>&1 &")
        time.sleep(8)
        try:
            with open(log, 'r') as f:
                content = f.read()
                match = re.search(r'https://[a-zA-Z0-9-]+\.trycloudflare\.com', content)
                if match: self.public_url = match.group(0)
        except: pass

brain = NexusBrain()

class APIHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ['/', '/index.html']:
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            with open(os.path.join(WORKING_DIR, 'index.html'), 'rb') as f:
                self.wfile.write(f.read())

    def do_POST(self):
        length = int(self.headers['Content-Length'])
        data = json.loads(self.rfile.read(length))
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()

        if self.path == '/api/chat':
            res = brain.chat_with_gemini_web(data.get('prompt', ''))
            self.wfile.write(json.dumps({"response": res}).encode())
        elif self.path == '/api/execute':
            cmd = data.get('command')
            res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            self.wfile.write(json.dumps({"return_code": res.returncode, "output": res.stdout+res.stderr}).encode())
        elif self.path == '/api/status':
            self.wfile.write(json.dumps({"balance": brain.total_searches*10, "public_url": brain.public_url}).encode())
        elif self.path == '/api/login':
            status = "success" if data.get('pin') == SOVEREIGN_PIN else "fail"
            self.wfile.write(json.dumps({"status": status}).encode())

if __name__ == "__main__":
    server = socketserver.TCPServer(("0.0.0.0", PORT_API), APIHandler)
    server.serve_forever()

