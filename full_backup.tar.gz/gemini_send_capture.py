#!/data/data/com.termux/files/usr/bin/python3
import argparse
import json
import os
import sys
import time
from pathlib import Path

from selenium import webdriver
from selenium.common.exceptions import JavascriptException, StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


HOME = Path.home()
DEFAULT_PROFILE = HOME / ".config/mozilla/firefox/xwdib0et.default-default"
DEFAULT_OUTPUT = HOME / "omni_identity_profile/vault_data/profiles/gemini.google.com/message_test"
DEFAULT_PROMPT = "Balas tepat dengan kalimat: Tes Gemini berhasil diterima."
GEMINI_URL = "https://gemini.google.com/app"


FIND_INPUT_JS = """
const candidates = Array.from(document.querySelectorAll(
  'textarea, [contenteditable="true"], div[role="textbox"], rich-textarea textarea'
));
function isVisible(el) {
  const r = el.getBoundingClientRect();
  const s = getComputedStyle(el);
  return r.width > 20 && r.height > 10 && s.visibility !== 'hidden' && s.display !== 'none';
}
return candidates.find(isVisible) || null;
"""

FIND_SEND_BUTTON_JS = """
const input = (() => {
  const candidates = Array.from(document.querySelectorAll(
    'textarea, [contenteditable="true"], div[role="textbox"], rich-textarea textarea'
  ));
  return candidates.find(el => {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 20 && r.height > 10 && s.visibility !== 'hidden' && s.display !== 'none';
  });
})();
const inputRect = input ? input.getBoundingClientRect() : null;
const buttons = Array.from(document.querySelectorAll('button'));
function isVisible(el) {
  const r = el.getBoundingClientRect();
  const s = getComputedStyle(el);
  return r.width > 10 && r.height > 10 && s.visibility !== 'hidden' && s.display !== 'none';
}
function label(el) {
  return [
    el.getAttribute('aria-label') || '',
    el.getAttribute('title') || '',
    el.innerText || '',
    el.textContent || ''
  ].join(' ').toLowerCase();
}
let matches = buttons.filter(btn => {
  if (!isVisible(btn) || btn.disabled || btn.getAttribute('aria-disabled') === 'true') return false;
  const l = label(btn);
  if (l.includes('pro') || l.includes('flash') || l.includes('upgrade')) return false;
  if (l.includes('send') || l.includes('kirim') || l.includes('submit') || l.includes('arrow_upward')) return true;
  if (inputRect) {
    const r = btn.getBoundingClientRect();
    return r.left > inputRect.right - 70
      && r.width <= 60
      && r.top > inputRect.top - 20
      && r.bottom < inputRect.bottom + 20;
  }
  return false;
});
matches.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
return matches[matches.length - 1] || null;
"""

CLICK_SEND_BY_POSITION_JS = """
const editable = (() => {
  const candidates = Array.from(document.querySelectorAll(
    'textarea, [contenteditable="true"], div[role="textbox"], rich-textarea textarea'
  ));
  return candidates.find(el => {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 20 && r.height > 10 && s.visibility !== 'hidden' && s.display !== 'none';
  });
})();
if (!editable) return false;
let box = editable;
while (box.parentElement) {
  const r = box.getBoundingClientRect();
  if (r.width > 500 && r.height >= 40) break;
  box = box.parentElement;
}
const r = box.getBoundingClientRect();
const x = r.right - 32;
const y = r.top + r.height / 2;
let target = document.elementFromPoint(x, y);
if (!target) return false;
const button = target.closest('button') || target;
button.click();
return true;
"""


EXTRACT_TEXT_JS = """
const selectors = [
  'message-content',
  'model-response',
  '.model-response-text',
  '.markdown',
  '[data-message-author-role="model"]',
  '[data-response-index]'
];
const seen = new Set();
const parts = [];
for (const sel of selectors) {
  for (const el of document.querySelectorAll(sel)) {
    const text = (el.innerText || el.textContent || '').trim();
    if (text && text.length > 10 && !seen.has(text)) {
      seen.add(text);
      parts.push({selector: sel, text});
    }
  }
}
return parts;
"""


def make_driver(profile_dir, headless):
    options = Options()
    options.add_argument("-profile")
    options.add_argument(str(profile_dir))
    options.add_argument("--width=1366")
    options.add_argument("--height=900")
    if headless:
      options.add_argument("-headless")
    service = Service(executable_path="/data/data/com.termux/files/usr/bin/geckodriver")
    return webdriver.Firefox(service=service, options=options)


def wait_for_input(driver, timeout):
    wait = WebDriverWait(driver, timeout)

    def locate(_driver):
        try:
            return _driver.execute_script(FIND_INPUT_JS)
        except JavascriptException:
            return None

    return wait.until(locate)


def wait_for_response_text(driver, prompt, timeout):
    deadline = time.time() + timeout
    last_parts = []
    prompt_norm = prompt.strip()
    expected_exact = "Tes Gemini berhasil diterima"

    while time.time() < deadline:
        parts = driver.execute_script(EXTRACT_TEXT_JS)
        last_parts = parts
        body_text = driver.execute_script("return document.body.innerText || '';")

        if expected_exact in prompt_norm and body_text.count(expected_exact) >= 2:
            return expected_exact, parts

        response_candidates = []
        for part in parts:
            text = part["text"].strip()
            if not text or text == prompt_norm or "Minta Gemini" in text:
                continue
            if expected_exact in text and text != prompt_norm and prompt_norm not in text:
                response_candidates.append(text)

        if response_candidates:
            return response_candidates[-1], parts

        time.sleep(2)

    return "", last_parts


def send_prompt(driver, prompt, timeout):
    deadline = time.time() + timeout
    last_error = None

    while time.time() < deadline:
        try:
            input_el = wait_for_input(driver, 10)
            input_el.click()
            time.sleep(0.3)
            input_el.send_keys(prompt)
            send_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((
                    By.CSS_SELECTOR,
                    'button[aria-label="Kirim pesan"], button[aria-label="Send message"]',
                ))
            )
            driver.execute_script("arguments[0].scrollIntoView({block:'center', inline:'center'});", send_button)
            time.sleep(0.2)
            send_button.click()
            time.sleep(1)
            return True
        except StaleElementReferenceException as exc:
            last_error = exc
            time.sleep(1)

    if last_error:
        raise last_error
    raise TimeoutException("Gemini input was not available.")


def main():
    parser = argparse.ArgumentParser(description="Send a prompt to Gemini and capture the response.")
    parser.add_argument("--profile", default=str(DEFAULT_PROFILE), help="Firefox profile directory")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT), help="Output directory")
    parser.add_argument("--prompt", default=DEFAULT_PROMPT, help="Prompt to send")
    parser.add_argument("--timeout", type=int, default=90, help="Timeout in seconds")
    parser.add_argument("--headless", action="store_true", help="Run Firefox headless")
    args = parser.parse_args()

    profile_dir = Path(args.profile).expanduser()
    out_dir = Path(args.output).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    screenshot_path = out_dir / "gemini_message_result.png"
    report_path = out_dir / "gemini_message_result.json"

    driver = None
    report = {
        "url": GEMINI_URL,
        "profile_dir": str(profile_dir),
        "prompt": args.prompt,
        "sent": False,
        "response_text": "",
        "response_detected": False,
        "screenshot_path": str(screenshot_path),
        "captured_at_epoch": time.time(),
    }

    try:
        driver = make_driver(profile_dir, args.headless)
        driver.set_page_load_timeout(args.timeout)
        driver.get(GEMINI_URL)

        send_prompt(driver, args.prompt, args.timeout)
        report["sent"] = True

        response_text, extracted_parts = wait_for_response_text(driver, args.prompt, args.timeout)
        report["response_text"] = response_text
        report["response_detected"] = bool(response_text)
        report["extracted_parts"] = extracted_parts[-5:]

        driver.save_screenshot(str(screenshot_path))

    except TimeoutException as exc:
        report["error"] = f"timeout: {exc}"
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        if driver is not None:
            try:
                driver.quit()
            except Exception:
                pass

        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"report={report_path}")
    print(f"screenshot={screenshot_path}")
    print(f"sent={report['sent']}")
    print(f"response_detected={report['response_detected']}")
    if report.get("response_text"):
        print("response_text=" + report["response_text"])
    if report.get("error"):
        print("error=" + report["error"], file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
