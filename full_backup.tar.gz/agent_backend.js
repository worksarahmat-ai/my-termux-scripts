import { GoogleGenAI } from '@google/genai';
import os from 'os';

// Mendeteksi API Key secara fleksibel dari lingkungan global
const apiKey = process.env['GEMINI_API_KEY'];

if (!apiKey) {
    console.warn("[⚠️ PERINGATAN] GEMINI_API_KEY tidak terdeteksi di lingkungan lokal.");
    console.warn("Memulai modul dengan mode fallback lingkungan otomatis platform...");
}

// Inisialisasi SDK (Jika kosong, SDK versi terbaru 2026 akan mencoba membaca fallback internal platform)
const ai = apiKey ? new GoogleGenAI({ apiKey: apiKey }) : new GoogleGenAI({});

// Konfigurasi Alat Tambahan untuk Agen
const agentTools = [
    { type: 'code_execution' },
    { type: 'google_search' },
    { type: 'url_context' }
];

/**
 * Mengambil metrik kesehatan perangkat secara real-time
 * Dioptimalkan secara penuh dengan fallback aman untuk Android Sandbox
 */
function getSystemMetrics() {
    // Fallback array kosong jika os.cpus() mengembalikan nilai undefined atau kosong di Android
    const cpus = os.cpus() || [];
    const totalMem = os.totalmem() || 1;
    const freeMem = os.freemem() || 0;
    const usedMem = totalMem - freeMem;
    const load = os.loadavg() || [0, 0, 0];

    // Mengamankan pembacaan properti objek index ke-0 agar tidak memicu TypeError
    const cpuModelName = (cpus.length > 0 && cpus[0] && cpus[0].model) ? cpus[0].model : "Android Environment (Termux)";
    const cpuLoad5 = (load && load[1] !== undefined) ? load[1].toFixed(2) : "0.00";

    return {
        cpuModel: cpuModelName,
        cpuLoad5Min: cpuLoad5,
        memoryUsagePercent: ((usedMem / totalMem) * 100).toFixed(2),
        freeMemoryGB: (freeMem / (1024 ** 3)).toFixed(2),
        uptimeHours: (os.uptime() / 3600).toFixed(2)
    };
}

/**
 * Siklus Utama Siklus Kerja Otomatis Agen Gemini
 */
async function runAutonomousAgentCycle() {
    console.log(`[${new Date().toISOString()}] Memulai siklus analisis agen...`);
    const metrics = getSystemMetrics();

    // Proteksi Beban Kerja Berlebih (Thermal Throttling Guard)
    if (parseFloat(metrics.cpuLoad5Min) > 4.0 || parseFloat(metrics.memoryUsagePercent) > 90) {
        console.warn(`[⚠️ OVERLOAD] Penundaan siklus demi stabilitas termal (CPU: ${metrics.cpuLoad5Min}, RAM: ${metrics.memoryUsagePercent}%).`);
        return;
    }

    try {
        // Pemanggilan Interaksi Agen Tingkat Lanjut (Deep Research Preview 2026)
        const interaction = await ai.interactions.create({
            agent: 'deep-research-preview-04-2026',
            input: `Lakukan analisis berkala pasar global, tren kripto (Solana/EVM), dan berita kemaslahatan umat. Metrik sistem saat ini: Perangkat: ${metrics.cpuModel}, CPU Load 5m: ${metrics.cpuLoad5Min}, Memori: ${metrics.memoryUsagePercent}%.`,
            background: true,
            tools: agentTools,
            agent_config: {
                type: 'deep-research',
                thinking_summaries: 'auto',
                visualization: 'auto',
                collaborative_planning: false,
            },
        });

        console.log(`[🚀 Agen Aktif] ID Interaksi: ${interaction.id}`);

        // Polling hasil berkala (60 detik pemantauan)
        let completed = false;
        let attempts = 0;

        while (!completed && attempts < 6) {
            await new Promise(resolve => setTimeout(resolve, 10000)); // Delay 10 detik per interval
            const statusCheck = await ai.interactions.get(interaction.id);

            if (statusCheck.status === 'completed') {
                console.log(`[✅ Siklus Berhasil] Output:`, statusCheck.output_text || "Tugas latar belakang selesai.");
                completed = true;
            } else if (statusCheck.status === 'failed') {
                console.error(`[❌ Siklus Gagal] Agen melaporkan kegagalan eksekusi internal.`);
                completed = true;
            }
            attempts++;
        }

    } catch (error) {
        console.error("[🔴 Error pada Siklus Agen]:", error.message);
    }
}

// Trigger Otomatisasi Terjadwal: Berjalan di latar belakang setiap 5 menit
const SIKLUS_INTERVAL = 5 * 60 * 1000;
setInterval(runAutonomousAgentCycle, SIKLUS_INTERVAL);

// Jalankan langsung secara asinkron saat pertama kali dieksekusi
runAutonomousAgentCycle();

