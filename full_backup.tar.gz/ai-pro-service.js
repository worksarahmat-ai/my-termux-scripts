import syncFs from "node:fs";
import fs from "node:fs/promises";
import { spawn } from "node:child_process";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { GoogleGenAI, FunctionCallingConfigMode, createPartFromUri } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const GEMINI_API_KEY = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";
const OPENAI_BASE_URL = String(process.env.OPENAI_BASE_URL || "").trim();
const AI_PRO_DISABLE_OPENAI_FALLBACK = process.env.AI_PRO_DISABLE_OPENAI_FALLBACK === "1";
const AI_PRO_DISABLE_G4F_FALLBACK = process.env.AI_PRO_DISABLE_G4F_FALLBACK === "1";
const PYTHON_CANDIDATES = process.env.PYTHON_BIN ? [process.env.PYTHON_BIN] : ["python", "python3"];
const G4F_FALLBACK_SCRIPT = resolveLocalPath(
  process.env.G4F_FALLBACK_SCRIPT,
  path.join("g4f-agent", "g4f_fallback.py")
);

const GEMINI_MODEL_PRESETS = {
  spark: "gemini-2.5-flash",
  reasoning: "gemini-2.5-pro",
  grounded: "gemini-3.5-flash",
  vision: "gemini-2.5-flash",
  image: "gemini-3.1-flash-image-preview",
  liveAudio: "gemini-2.5-flash-native-audio-preview-12-2025"
};

const OPENAI_MODEL_PRESETS = {
  spark: process.env.OPENAI_SPARK_MODEL || process.env.OPENAI_MODEL || "gpt-5.4-pro",
  reasoning: process.env.OPENAI_REASONING_MODEL || "gpt-5.5-pro",
  grounded: process.env.OPENAI_GROUNDED_MODEL || process.env.OPENAI_MODEL || "gpt-5.4-pro",
  vision: process.env.OPENAI_VISION_MODEL || process.env.OPENAI_MODEL || "gpt-5.4-pro",
  image: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2"
};

const G4F_MODEL_PRESETS = {
  spark: process.env.G4F_SPARK_MODEL || "gpt-4o-mini",
  reasoning: process.env.G4F_REASONING_MODEL || "gpt-4",
  grounded: process.env.G4F_GROUNDED_MODEL || "gpt-4",
  vision: process.env.G4F_VISION_MODEL || "gpt-4",
  image: null
};

const IMAGE_MIME_TYPES = new Set([
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/heic",
  "image/heif",
  "image/gif",
  "image/bmp"
]);

const VIDEO_MIME_TYPES = new Set([
  "video/mp4",
  "video/mpeg",
  "video/mov",
  "video/avi",
  "video/x-flv",
  "video/mpg",
  "video/webm",
  "video/wmv",
  "video/3gpp"
]);

let cachedGeminiClient = null;

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function hasValue(value) {
  return value !== undefined && value !== null && String(value).trim() !== "";
}

function isObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function dedupeMessages(list = []) {
  return [...new Set(list.filter(Boolean).map((item) => String(item).trim()).filter(Boolean))];
}

function aiProError(message, status = 400, extras = {}) {
  return Object.assign(new Error(message), { status, retryable: false, ...extras });
}

function providerError(message, status = 502, extras = {}) {
  return Object.assign(new Error(message), { status, retryable: true, ...extras });
}

function resolveLocalPath(value, fallback) {
  const raw = String(value || fallback || "").trim();
  if (!raw) return "";
  return path.isAbsolute(raw) ? raw : path.join(__dirname, raw);
}

function isGeminiConfigured() {
  return Boolean(GEMINI_API_KEY);
}

function getOpenAiBaseUrl() {
  return (OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, "");
}

function isOpenAiConfigured() {
  if (AI_PRO_DISABLE_OPENAI_FALLBACK) return false;
  return Boolean(OPENAI_API_KEY || OPENAI_BASE_URL);
}

function isG4fConfigured() {
  if (AI_PRO_DISABLE_G4F_FALLBACK) return false;
  return syncFs.existsSync(G4F_FALLBACK_SCRIPT);
}

function getProviderState() {
  const providers = {
    gemini: {
      key: "google-genai",
      available: isGeminiConfigured(),
      envVars: ["GEMINI_API_KEY", "GOOGLE_API_KEY"],
      models: GEMINI_MODEL_PRESETS
    },
    openaiCompatible: {
      key: "openai-compatible",
      available: isOpenAiConfigured(),
      envVars: ["OPENAI_API_KEY", "OPENAI_BASE_URL", "OPENAI_MODEL"],
      baseUrl: isOpenAiConfigured() ? getOpenAiBaseUrl() : null,
      models: OPENAI_MODEL_PRESETS
    },
    g4f: {
      key: "g4f",
      available: isG4fConfigured(),
      envVars: ["G4F_FALLBACK_SCRIPT", "PYTHON_BIN"],
      scriptPath: isG4fConfigured() ? G4F_FALLBACK_SCRIPT : null,
      pythonCandidates: PYTHON_CANDIDATES,
      models: G4F_MODEL_PRESETS
    }
  };

  const providerChain = [
    providers.gemini.available ? providers.gemini.key : null,
    providers.openaiCompatible.available ? providers.openaiCompatible.key : null,
    providers.g4f.available ? providers.g4f.key : null
  ].filter(Boolean);

  const provider = providerChain[0] || "none";
  const activeModels =
    provider === "google-genai"
      ? GEMINI_MODEL_PRESETS
      : provider === "openai-compatible"
        ? OPENAI_MODEL_PRESETS
        : provider === "g4f"
          ? G4F_MODEL_PRESETS
          : {};

  return {
    configured: providerChain.length > 0,
    provider,
    providerChain,
    models: activeModels,
    providers
  };
}

function getGeminiClient() {
  if (!isGeminiConfigured()) {
    throw providerError("Gemini belum dikonfigurasi di environment server.", 503, {
      provider: "google-genai"
    });
  }

  if (!cachedGeminiClient) {
    cachedGeminiClient = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
  }

  return cachedGeminiClient;
}

export function isAiProConfigured() {
  return getProviderState().configured;
}

export function getAiProCapabilities() {
  const providerState = getProviderState();

  return {
    ok: true,
    configured: providerState.configured,
    provider: providerState.provider,
    providerChain: providerState.providerChain,
    envVars: [
      "GEMINI_API_KEY",
      "GOOGLE_API_KEY",
      "OPENAI_API_KEY",
      "OPENAI_BASE_URL",
      "OPENAI_MODEL",
      "G4F_FALLBACK_SCRIPT",
      "PYTHON_BIN"
    ],
    models: providerState.models,
    providerModels: {
      gemini: GEMINI_MODEL_PRESETS,
      openaiCompatible: OPENAI_MODEL_PRESETS,
      g4f: G4F_MODEL_PRESETS
    },
    providers: providerState.providers,
    features: {
      contextualChat: true,
      modeSpark: true,
      autoModelSelection: true,
      deepReasoning: true,
      codeExecution: true,
      functionCalling: true,
      structuredOutput: true,
      googleSearchGrounding: true,
      urlContext: true,
      googleMapsGrounding: true,
      imageGeneration: true,
      imageAspectRatioControl: true,
      image4k: true,
      imageAnalysis: true,
      videoAnalysis: true,
      browserVoiceChat: true,
      liveAudioModelAvailable: true,
      fallbackProviders: true,
      termuxBlock: true,
      termuxContinuousExecution: true
    },
    limitations: [
      "Rantai provider: Gemini -> OpenAI-compatible -> g4f.",
      "Google Search grounding, URL Context native, Google Maps grounding, dan code execution native terbaik saat provider utama Gemini aktif.",
      "Fallback OpenAI-compatible menurunkan beberapa fitur grounding Gemini ke mode konteks teks lokal.",
      "Fallback g4f fokus pada chat teks/JSON. Image generation tidak tersedia lewat g4f di backend ini.",
      "Termux Block hanya menjalankan command yang ada di allowlist backend dan menolak pola shell destruktif atau chaining.",
      "Voice chat di halaman web memakai speech recognition dan speech synthesis browser. Native audio Live API belum diproxy langsung oleh backend ini."
    ],
    docs: [
      "https://ai.google.dev/gemini-api/docs/google-search",
      "https://ai.google.dev/gemini-api/docs/url-context",
      "https://ai.google.dev/gemini-api/docs/maps-grounding",
      "https://ai.google.dev/gemini-api/docs/code-execution",
      "https://ai.google.dev/gemini-api/docs/function-calling",
      "https://ai.google.dev/gemini-api/docs/structured-output",
      "https://ai.google.dev/gemini-api/docs/image-generation",
      "https://ai.google.dev/gemini-api/docs/video-understanding",
      "https://ai.google.dev/gemini-api/docs/live-guide",
      "https://developers.openai.com/api/docs/models/gpt-5.5-pro",
      "https://developers.openai.com/api/docs/models/gpt-5.4-pro",
      "https://developers.openai.com/api/docs/models/gpt-5.4-mini",
      "https://developers.openai.com/api/docs/models/gpt-image-2"
    ]
  };
}

function safeText(value, maxLength = 12000) {
  return String(value || "").trim().slice(0, maxLength);
}

function normalizeList(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  return [value];
}

function dataUrlParts(data) {
  const match = /^data:([^;,]+)?;base64,(.*)$/i.exec(String(data || ""));
  if (!match) return null;
  return { mimeType: match[1] || "", base64: match[2] || "" };
}

function normalizeMimeType(item) {
  if (item?.mimeType) return String(item.mimeType).trim().toLowerCase();
  if (item?.type && String(item.type).includes("/")) return String(item.type).trim().toLowerCase();
  return "";
}

function guessMimeTypeFromUrl(url) {
  const value = String(url || "").toLowerCase();
  if (/\.(png)$/.test(value)) return "image/png";
  if (/\.(jpe?g)$/.test(value)) return "image/jpeg";
  if (/\.(webp)$/.test(value)) return "image/webp";
  if (/\.(gif)$/.test(value)) return "image/gif";
  if (/\.(bmp)$/.test(value)) return "image/bmp";
  if (/\.(mp4)$/.test(value)) return "video/mp4";
  if (/\.(mov)$/.test(value)) return "video/mov";
  if (/\.(avi)$/.test(value)) return "video/avi";
  if (/\.(webm)$/.test(value)) return "video/webm";
  if (/\.(pdf)$/.test(value)) return "application/pdf";
  return "";
}

function fileExtensionForMime(mimeType) {
  const table = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "image/bmp": ".bmp",
    "video/mp4": ".mp4",
    "video/mpeg": ".mpeg",
    "video/mov": ".mov",
    "video/avi": ".avi",
    "video/webm": ".webm",
    "video/wmv": ".wmv",
    "video/3gpp": ".3gp",
    "application/pdf": ".pdf",
    "text/plain": ".txt",
    "text/csv": ".csv"
  };
  return table[mimeType] || ".bin";
}

function normalizeContextUrls(value) {
  const urls = normalizeList(value)
    .flatMap((entry) => String(entry || "").split(/\r?\n/))
    .map((entry) => entry.trim())
    .filter(Boolean)
    .slice(0, 20);

  for (const entry of urls) {
    let parsed;
    try {
      parsed = new URL(entry);
    } catch {
      throw aiProError(`URL konteks tidak valid: ${entry}`);
    }
    if (!["http:", "https:"].includes(parsed.protocol)) {
      throw aiProError(`URL konteks harus http/https: ${entry}`);
    }
  }

  return urls;
}

function buildPromptText(payload, task) {
  const prompt = safeText(payload.prompt || payload.message, 16000);
  const urls = normalizeContextUrls(payload.contextUrls || payload.urls || []);
  const systemHints = [];

  if (task === "media" && !prompt) {
    systemHints.push("Jelaskan isi media, rangkum informasi penting, dan sorot detail teknis yang relevan.");
  }

  if (urls.length > 0 && payload.useUrlContext) {
    systemHints.push(`Gunakan URL berikut sebagai konteks utama:\n${urls.join("\n")}`);
  }

  if (payload.useGoogleMaps && isObject(payload.mapContext)) {
    const latitude = Number(payload.mapContext.latitude);
    const longitude = Number(payload.mapContext.longitude);
    if (Number.isFinite(latitude) && Number.isFinite(longitude)) {
      systemHints.push(`Koordinat pengguna: ${latitude}, ${longitude}`);
    }
  }

  const combined = [prompt, ...systemHints].filter(Boolean).join("\n\n");
  return combined.trim();
}

function normalizeHistoryItem(entry) {
  if (!isObject(entry)) return null;
  const role = entry.role === "model" || entry.role === "assistant" ? "model" : "user";

  if (Array.isArray(entry.parts) && entry.parts.length > 0) {
    return { role, parts: entry.parts };
  }

  const content = safeText(entry.content || entry.text || "", 10000);
  if (!content) return null;
  return { role, parts: [{ text: content }] };
}

function normalizeHistory(history) {
  return normalizeList(history).map(normalizeHistoryItem).filter(Boolean).slice(-24);
}

function normalizeOpenAiHistory(history) {
  return normalizeList(history)
    .map((entry) => {
      if (!isObject(entry)) return null;

      const roleRaw = String(entry.role || "user").toLowerCase();
      const role =
        roleRaw === "assistant" || roleRaw === "model"
          ? "assistant"
          : roleRaw === "system"
            ? "system"
            : "user";

      if (Array.isArray(entry.content) && entry.content.length > 0) {
        return { role, content: entry.content };
      }

      if (Array.isArray(entry.parts) && entry.parts.length > 0) {
        const text = entry.parts
          .map((part) => {
            if (part?.text) return String(part.text);
            if (part?.fileData?.fileUri) return `[media] ${part.fileData.fileUri}`;
            if (part?.inlineData?.mimeType) return `[inline ${part.inlineData.mimeType}]`;
            return "";
          })
          .filter(Boolean)
          .join("\n\n")
          .trim();
        if (!text) return null;
        return { role, content: text };
      }

      const content = safeText(entry.content || entry.text || "", 10000);
      if (!content) return null;
      return { role, content };
    })
    .filter(Boolean)
    .slice(-24);
}

async function uploadLargeMedia(client, mimeType, buffer) {
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "ai-pro-upload-"));
  const tempFile = path.join(tempDir, `upload${fileExtensionForMime(mimeType)}`);
  await fs.writeFile(tempFile, buffer);

  try {
    const uploaded = await client.files.upload({
      file: tempFile,
      config: { mimeType }
    });
    return createPartFromUri(uploaded.uri, uploaded.mimeType || mimeType);
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true });
  }
}

async function mediaItemToPart(client, item) {
  if (typeof item === "string") {
    const url = item.trim();
    if (!url) return null;
    return { fileData: { fileUri: url, mimeType: guessMimeTypeFromUrl(url) || undefined } };
  }

  if (!isObject(item)) return null;

  if (hasValue(item.text)) {
    return { text: safeText(item.text, 8000) };
  }

  if (hasValue(item.url)) {
    const fileUri = String(item.url).trim();
    return {
      fileData: {
        fileUri,
        mimeType: normalizeMimeType(item) || guessMimeTypeFromUrl(fileUri) || undefined
      }
    };
  }

  const parsedDataUrl = dataUrlParts(item.data || item.base64 || "");
  const mimeType = normalizeMimeType(item) || parsedDataUrl?.mimeType || "";
  const base64 = parsedDataUrl?.base64 || String(item.data || item.base64 || "").trim();

  if (!mimeType || !base64) {
    return null;
  }

  const buffer = Buffer.from(base64, "base64");
  const shouldUpload =
    buffer.byteLength > 7 * 1024 * 1024 ||
    VIDEO_MIME_TYPES.has(mimeType) ||
    mimeType === "application/pdf";

  if (shouldUpload) {
    return await uploadLargeMedia(client, mimeType, buffer);
  }

  return {
    inlineData: {
      mimeType,
      data: buffer.toString("base64")
    }
  };
}

async function buildContents(client, payload, task = "chat") {
  const contents = normalizeHistory(payload.history || payload.messages);
  const prompt = buildPromptText(payload, task);
  const parts = [];

  if (prompt) {
    parts.push({ text: prompt });
  }

  for (const mediaItem of normalizeList(payload.media || payload.attachments || payload.files)) {
    const part = await mediaItemToPart(client, mediaItem);
    if (part) parts.push(part);
  }

  if (parts.length === 0) {
    throw aiProError("prompt atau media wajib diisi");
  }

  contents.push({ role: "user", parts });
  return contents;
}

function chooseGeminiModel(payload = {}, task = "chat") {
  if (hasValue(payload.model)) {
    return String(payload.model).trim();
  }

  const mode = String(payload.mode || "auto").trim().toLowerCase();

  if (task === "image") return GEMINI_MODEL_PRESETS.image;
  if (task === "media") return GEMINI_MODEL_PRESETS.vision;
  if (mode === "spark") return GEMINI_MODEL_PRESETS.spark;
  if (mode === "reasoning" || payload.deepReasoning) return GEMINI_MODEL_PRESETS.reasoning;
  if (payload.useGoogleSearch || payload.useUrlContext || payload.useGoogleMaps || payload.useFunctionTools) {
    return GEMINI_MODEL_PRESETS.grounded;
  }
  return GEMINI_MODEL_PRESETS.spark;
}

function chooseOpenAiModel(payload = {}, task = "chat") {
  if (hasValue(payload.model)) {
    return String(payload.model).trim();
  }

  const mode = String(payload.mode || "auto").trim().toLowerCase();

  if (task === "image") return OPENAI_MODEL_PRESETS.image;
  if (task === "media") return OPENAI_MODEL_PRESETS.vision;
  if (mode === "spark") return OPENAI_MODEL_PRESETS.spark;
  if (mode === "reasoning" || payload.deepReasoning) return OPENAI_MODEL_PRESETS.reasoning;
  return OPENAI_MODEL_PRESETS.spark;
}

function chooseG4fModels(payload = {}, task = "chat") {
  const preferred = hasValue(payload.model) ? [String(payload.model).trim()] : [];
  const mode = String(payload.mode || "auto").trim().toLowerCase();
  const base =
    task === "media"
      ? [G4F_MODEL_PRESETS.vision, G4F_MODEL_PRESETS.reasoning, G4F_MODEL_PRESETS.spark]
      : mode === "spark"
        ? [G4F_MODEL_PRESETS.spark, G4F_MODEL_PRESETS.reasoning, "gpt-3.5-turbo"]
        : [G4F_MODEL_PRESETS.reasoning, G4F_MODEL_PRESETS.spark, "gpt-3.5-turbo"];

  return dedupeMessages([...preferred, ...base, "gpt-4o-mini", "gpt-4", "gpt-3.5-turbo"]);
}

function buildFunctionDeclarations() {
  return [
    {
      name: "run_safe_command",
      description: "Menjalankan command lokal yang aman dan termasuk allowlist backend.",
      parametersJsonSchema: {
        type: "object",
        properties: {
          command: {
            type: "string",
            description: "Command aman seperti pwd, ls, date, uname, df, free, uptime, termux-info."
          },
          timeout: {
            type: "integer",
            minimum: 1000,
            maximum: 180000,
            description: "Batas waktu command dalam milidetik."
          }
        },
        required: ["command"]
      }
    },
    {
      name: "fetch_url_context",
      description: "Mengambil konten URL publik untuk dipahami AI secara lebih detail.",
      parametersJsonSchema: {
        type: "object",
        properties: {
          url: {
            type: "string",
            description: "URL http/https publik."
          }
        },
        required: ["url"]
      }
    },
    {
      name: "get_device_profile",
      description: "Mengambil ringkasan perangkat, memori, CPU, dan lingkungan server saat ini.",
      parametersJsonSchema: {
        type: "object",
        properties: {}
      }
    }
  ];
}

async function invokeLocalFunction(name, args, helpers = {}) {
  if (name === "run_safe_command") {
    if (typeof helpers.runAllowedCommand !== "function") {
      throw aiProError("Helper runAllowedCommand tidak tersedia.");
    }
    return await helpers.runAllowedCommand(String(args?.command || ""), args?.timeout || 60000);
  }

  if (name === "fetch_url_context") {
    if (typeof helpers.scrapeUrl !== "function") {
      throw aiProError("Helper scrapeUrl tidak tersedia.");
    }
    return await helpers.scrapeUrl(String(args?.url || ""));
  }

  if (name === "get_device_profile") {
    if (typeof helpers.getDeviceInfo !== "function") {
      throw aiProError("Helper getDeviceInfo tidak tersedia.");
    }
    return helpers.getDeviceInfo();
  }

  throw aiProError(`Function tool tidak dikenali: ${name}`);
}

function buildGeminiToolBundle(payload, allowFunctions = true) {
  const warnings = [];
  const tools = [];

  if (payload.useGoogleSearch) tools.push({ googleSearch: {} });
  if (payload.useUrlContext) tools.push({ urlContext: {} });
  if (payload.useGoogleMaps) {
    tools.push({ googleMaps: { enableWidget: Boolean(payload.enableMapWidget ?? true) } });
  }
  if (payload.useCodeExecution) tools.push({ codeExecution: {} });

  const allowFunctionTools =
    Boolean(payload.useFunctionTools) &&
    allowFunctions &&
    !payload.useUrlContext &&
    !payload.useGoogleMaps;

  if (Boolean(payload.useFunctionTools) && !allowFunctionTools) {
    warnings.push("Function tools dinonaktifkan karena kombinasi dengan URL Context atau Google Maps belum stabil.");
  }

  if (allowFunctionTools) {
    tools.push({ functionDeclarations: buildFunctionDeclarations() });
  }

  const toolConfig = {};
  if (allowFunctionTools) {
    toolConfig.functionCallingConfig = {
      mode: tools.some((tool) => tool.googleSearch || tool.codeExecution)
        ? FunctionCallingConfigMode.VALIDATED
        : FunctionCallingConfigMode.AUTO,
      allowedFunctionNames: buildFunctionDeclarations().map((item) => item.name)
    };
  }

  if (payload.useGoogleMaps && isObject(payload.mapContext)) {
    const latitude = Number(payload.mapContext.latitude);
    const longitude = Number(payload.mapContext.longitude);
    if (Number.isFinite(latitude) && Number.isFinite(longitude)) {
      toolConfig.retrievalConfig = {
        latLng: {
          latitude,
          longitude
        }
      };
    } else {
      warnings.push("Google Maps aktif tanpa latitude/longitude valid. Query tetap dikirim, tetapi grounding lokasi mungkin kurang akurat.");
    }
  }

  return { tools, toolConfig, allowFunctionTools, warnings };
}

function buildGenerationConfig(payload, options = {}) {
  const config = {};
  const temperature = Number(payload.temperature);
  if (Number.isFinite(temperature)) {
    config.temperature = clamp(temperature, 0, 2);
  }

  const topP = Number(payload.topP);
  if (Number.isFinite(topP)) {
    config.topP = clamp(topP, 0, 1);
  }

  const maxOutputTokens = Number(payload.maxOutputTokens);
  if (Number.isFinite(maxOutputTokens) && maxOutputTokens > 0) {
    config.maxOutputTokens = Math.floor(Math.min(maxOutputTokens, 8192));
  }

  if (hasValue(payload.systemInstruction)) {
    config.systemInstruction = safeText(payload.systemInstruction, 4000);
  }

  if (payload.deepReasoning || hasValue(payload.thinkingBudget)) {
    const thinkingBudget = Number(payload.thinkingBudget);
    config.thinkingConfig = {
      thinkingBudget: Number.isFinite(thinkingBudget) ? Math.floor(thinkingBudget) : 1024,
      includeThoughts: Boolean(payload.includeThoughts)
    };
  }

  if (options.tools?.length) {
    config.tools = options.tools;
  }

  if (isObject(options.toolConfig) && Object.keys(options.toolConfig).length > 0) {
    config.toolConfig = options.toolConfig;
  }

  if (options.responseJsonSchema) {
    config.responseMimeType = "application/json";
    config.responseJsonSchema = options.responseJsonSchema;
  }

  if (options.imageGeneration) {
    config.responseModalities = ["TEXT", "IMAGE"];
    config.imageConfig = {
      aspectRatio: hasValue(payload.aspectRatio) ? String(payload.aspectRatio).trim() : "1:1",
      imageSize: hasValue(payload.imageSize) ? String(payload.imageSize).trim().toUpperCase() : "2K"
    };
  }

  return config;
}

function extractImages(response) {
  const parts = response?.candidates?.[0]?.content?.parts || [];
  return parts
    .filter((part) => part.inlineData?.data)
    .map((part, index) => ({
      index,
      mimeType: part.inlineData.mimeType || "image/png",
      base64: part.inlineData.data,
      dataUrl: `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`
    }));
}

function extractFunctionCalls(response) {
  return (response.functionCalls || []).map((call) => ({
    id: call.id,
    name: call.name,
    args: call.args || {}
  }));
}

function responseSummary(response, extra = {}) {
  return {
    ok: true,
    provider: extra.provider || "google-genai",
    model: response?.modelVersion || extra.model,
    responseId: response?.responseId || null,
    text: response?.text || "",
    functionCalls: extractFunctionCalls(response),
    generatedCode: response?.executableCode || null,
    codeExecutionResult: response?.codeExecutionResult || null,
    groundingMetadata: response?.candidates?.[0]?.groundingMetadata || null,
    urlContextMetadata: response?.candidates?.[0]?.urlContextMetadata || null,
    usage: response?.usageMetadata || null,
    images: extractImages(response),
    warnings: extra.warnings || []
  };
}

async function runFunctionLoop(client, model, contents, config, helpers, maxCalls = 4) {
  const localToolResults = [];
  let response = await client.models.generateContent({ model, contents, config });
  let iterations = 0;

  while (iterations < maxCalls) {
    const functionCalls = response.functionCalls || [];
    if (functionCalls.length === 0) {
      break;
    }

    iterations += 1;
    const responseParts = [];
    for (const call of functionCalls) {
      const result = await invokeLocalFunction(call.name, call.args || {}, helpers);
      localToolResults.push({ name: call.name, args: call.args || {}, result });
      responseParts.push({
        functionResponse: {
          id: call.id,
          name: call.name,
          response: result
        }
      });
    }

    contents = [
      ...contents,
      response.candidates?.[0]?.content || { role: "model", parts: [{ text: response.text || "" }] },
      { role: "user", parts: responseParts }
    ];

    response = await client.models.generateContent({ model, contents, config });
  }

  return { response, localToolResults };
}

function parseJsonSchema(schema) {
  if (isObject(schema)) return schema;
  if (!hasValue(schema)) throw aiProError("schema wajib diisi untuk structured output");
  try {
    const parsed = JSON.parse(String(schema));
    if (!isObject(parsed)) {
      throw new Error("schema harus object JSON");
    }
    return parsed;
  } catch (error) {
    throw aiProError(`schema tidak valid: ${error.message}`);
  }
}

async function buildFallbackContextNotes(payload, helpers = {}) {
  const warnings = [];
  const sections = [];
  const urls = normalizeContextUrls(payload.contextUrls || payload.urls || []);

  if (payload.useUrlContext && urls.length > 0) {
    if (typeof helpers.scrapeUrl !== "function") {
      warnings.push("URL Context fallback lokal tidak aktif karena helper scrapeUrl tidak tersedia.");
    } else {
      for (const url of urls.slice(0, 4)) {
        try {
          const scraped = await helpers.scrapeUrl(url);
          sections.push([
            "Konteks URL lokal:",
            `URL: ${scraped.url}`,
            `Judul: ${scraped.title || "-"}`,
            scraped.description ? `Deskripsi: ${safeText(scraped.description, 400)}` : "",
            `Isi ringkas: ${safeText(scraped.text, 2500)}`
          ].filter(Boolean).join("\n"));
        } catch (error) {
          warnings.push(`Gagal mengambil konteks URL ${url}: ${error.message}`);
        }
      }
    }
  }

  if (payload.useGoogleSearch) {
    warnings.push("Google Search grounding native hanya tersedia saat provider Gemini aktif.");
  }

  if (payload.useGoogleMaps) {
    warnings.push("Google Maps grounding native hanya tersedia saat provider Gemini aktif. Fallback memakai koordinat sebagai konteks teks.");
  }

  if (payload.useCodeExecution && !payload.useFunctionTools) {
    warnings.push("Code execution native hanya tersedia saat provider Gemini aktif. Aktifkan function tools untuk emulasi tool lokal yang aman.");
  }

  return {
    text: sections.join("\n\n").trim(),
    warnings
  };
}

function fallbackMediaText(item, warnings) {
  if (typeof item === "string") {
    const value = item.trim();
    if (!value) return "";
    const mimeType = guessMimeTypeFromUrl(value);
    if (VIDEO_MIME_TYPES.has(mimeType)) {
      warnings.push("Media video di fallback non-Gemini diperlakukan sebagai URL teks, bukan analisis video native.");
    } else if (mimeType === "application/pdf") {
      warnings.push("Dokumen PDF di fallback non-Gemini diperlakukan sebagai URL teks.");
    }
    return `Media URL: ${value}`;
  }

  if (!isObject(item)) return "";
  if (hasValue(item.text)) return safeText(item.text, 4000);
  if (hasValue(item.url)) return `Media URL: ${String(item.url).trim()}`;

  const parsed = dataUrlParts(item.data || item.base64 || "");
  const mimeType = normalizeMimeType(item) || parsed?.mimeType || "";
  if (mimeType) {
    warnings.push(`Media inline ${mimeType} tidak didukung penuh oleh fallback teks. Hanya deskripsi prompt yang dipakai.`);
  }
  return "";
}

function mediaItemToOpenAiPart(item, warnings) {
  if (typeof item === "string") {
    const value = item.trim();
    if (!value) return { part: null, textNote: "" };

    const parsed = dataUrlParts(value);
    const mimeType = parsed?.mimeType || guessMimeTypeFromUrl(value);
    if (IMAGE_MIME_TYPES.has(mimeType)) {
      return { part: { type: "image_url", image_url: { url: value } }, textNote: "" };
    }
    return { part: null, textNote: fallbackMediaText(value, warnings) };
  }

  if (!isObject(item)) return { part: null, textNote: "" };

  if (hasValue(item.text)) {
    return { part: null, textNote: safeText(item.text, 4000) };
  }

  if (hasValue(item.url)) {
    const url = String(item.url).trim();
    const mimeType = normalizeMimeType(item) || guessMimeTypeFromUrl(url);
    if (IMAGE_MIME_TYPES.has(mimeType)) {
      return { part: { type: "image_url", image_url: { url } }, textNote: "" };
    }
    return { part: null, textNote: fallbackMediaText({ url }, warnings) };
  }

  const parsed = dataUrlParts(item.data || item.base64 || "");
  const mimeType = normalizeMimeType(item) || parsed?.mimeType || "";
  if (IMAGE_MIME_TYPES.has(mimeType) && parsed?.base64) {
    return {
      part: {
        type: "image_url",
        image_url: { url: `data:${mimeType};base64,${parsed.base64}` }
      },
      textNote: ""
    };
  }

  return { part: null, textNote: fallbackMediaText(item, warnings) };
}

async function buildOpenAiMessages(payload, task, helpers = {}, options = {}) {
  const history = normalizeOpenAiHistory(payload.history || payload.messages);
  const prompt = buildPromptText(payload, task);
  const fallbackContext = await buildFallbackContextNotes(payload, helpers);
  const warnings = [...fallbackContext.warnings];
  const mediaNotes = [];
  const contentParts = [];

  if (hasValue(options.systemInstruction)) {
    history.unshift({ role: "system", content: safeText(options.systemInstruction, 6000) });
  } else if (hasValue(payload.systemInstruction)) {
    history.unshift({ role: "system", content: safeText(payload.systemInstruction, 6000) });
  }

  for (const mediaItem of normalizeList(payload.media || payload.attachments || payload.files)) {
    const { part, textNote } = mediaItemToOpenAiPart(mediaItem, warnings);
    if (!options.textOnly && part) {
      contentParts.push(part);
    }
    if (textNote) {
      mediaNotes.push(textNote);
    }
  }

  const textSections = [prompt, fallbackContext.text, ...mediaNotes, options.appendText]
    .filter(Boolean)
    .join("\n\n")
    .trim();

  if (textSections) {
    contentParts.unshift({ type: "text", text: textSections });
  }

  if (contentParts.length === 0) {
    throw aiProError("prompt atau media wajib diisi");
  }

  history.push({
    role: "user",
    content:
      options.textOnly || (contentParts.length === 1 && contentParts[0].type === "text")
        ? contentParts.map((part) => part.type === "text" ? part.text : "[media]").join("\n\n")
        : contentParts
  });

  return { messages: history, warnings };
}

function buildOpenAiToolBundle(payload) {
  const warnings = [];

  if (payload.useGoogleSearch) {
    warnings.push("Google Search grounding native tidak dipetakan ke OpenAI-compatible fallback ini.");
  }
  if (payload.useGoogleMaps) {
    warnings.push("Google Maps grounding native tidak dipetakan ke OpenAI-compatible fallback ini.");
  }

  const allowFunctionTools =
    Boolean(payload.useFunctionTools) &&
    !payload.useUrlContext &&
    !payload.useGoogleMaps;

  if (Boolean(payload.useFunctionTools) && !allowFunctionTools) {
    warnings.push("Function tools dinonaktifkan pada fallback karena kombinasi dengan URL Context atau Google Maps.");
  }

  if (payload.useCodeExecution && allowFunctionTools) {
    warnings.push("Code execution fallback memakai function tool lokal backend, bukan sandbox native provider.");
  }

  return {
    allowFunctionTools,
    warnings,
    tools: allowFunctionTools
      ? buildFunctionDeclarations().map((item) => ({
          type: "function",
          function: {
            name: item.name,
            description: item.description,
            parameters: item.parametersJsonSchema
          }
        }))
      : []
  };
}

function buildOpenAiChatBody(payload, model, messages, extra = {}) {
  const body = {
    model,
    messages
  };

  const temperature = Number(payload.temperature);
  if (Number.isFinite(temperature)) {
    body.temperature = clamp(temperature, 0, 2);
  }

  const topP = Number(payload.topP);
  if (Number.isFinite(topP)) {
    body.top_p = clamp(topP, 0, 1);
  }

  const maxOutputTokens = Number(payload.maxOutputTokens);
  if (Number.isFinite(maxOutputTokens) && maxOutputTokens > 0) {
    body.max_tokens = Math.floor(Math.min(maxOutputTokens, 8192));
  }

  if (extra.tools?.length) {
    body.tools = extra.tools;
    body.tool_choice = "auto";
  }

  if (extra.responseFormat) {
    body.response_format = extra.responseFormat;
  }

  return body;
}

async function callOpenAiJson(pathname, body) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 90000);
  const headers = {
    "content-type": "application/json"
  };

  if (OPENAI_API_KEY) {
    headers.authorization = `Bearer ${OPENAI_API_KEY}`;
  }

  try {
    const response = await fetch(`${getOpenAiBaseUrl()}${pathname}`, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      signal: controller.signal
    });
    const text = await response.text();
    let data = null;

    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = { raw: text };
    }

    if (!response.ok) {
      const message =
        data?.error?.message ||
        data?.message ||
        data?.raw ||
        `HTTP ${response.status}`;
      throw providerError(`OpenAI-compatible gagal (${response.status}): ${message}`, response.status, {
        provider: "openai-compatible"
      });
    }

    return data;
  } catch (error) {
    if (error.name === "AbortError") {
      throw providerError("OpenAI-compatible timeout.", 504, {
        provider: "openai-compatible"
      });
    }
    if (error.retryable !== undefined) {
      throw error;
    }
    throw providerError(`OpenAI-compatible request gagal: ${error.message}`, 502, {
      provider: "openai-compatible"
    });
  } finally {
    clearTimeout(timeout);
  }
}

function parseOpenAiToolArgs(rawArgs) {
  if (!hasValue(rawArgs)) return {};
  try {
    const parsed = JSON.parse(String(rawArgs));
    return isObject(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function extractOpenAiText(message) {
  if (typeof message?.content === "string") return message.content;
  if (Array.isArray(message?.content)) {
    return message.content
      .map((item) => {
        if (typeof item === "string") return item;
        if (item?.type === "text") return item.text || "";
        return "";
      })
      .filter(Boolean)
      .join("\n");
  }
  return "";
}

function extractOpenAiFunctionCalls(message) {
  return normalizeList(message?.tool_calls).map((call) => ({
    id: call.id || null,
    name: call.function?.name || "",
    args: parseOpenAiToolArgs(call.function?.arguments || "{}")
  }));
}

function openAiResponseSummary(response, extra = {}) {
  const message = response?.choices?.[0]?.message || {};
  return {
    ok: true,
    provider: "openai-compatible",
    model: response?.model || extra.model,
    responseId: response?.id || null,
    text: extractOpenAiText(message),
    functionCalls: extractOpenAiFunctionCalls(message),
    generatedCode: null,
    codeExecutionResult: null,
    groundingMetadata: null,
    urlContextMetadata: null,
    usage: response?.usage || null,
    images: extra.images || [],
    warnings: extra.warnings || []
  };
}

async function runOpenAiConversation(payload, task, helpers = {}, options = {}) {
  if (!isOpenAiConfigured()) {
    throw providerError("OpenAI-compatible fallback belum dikonfigurasi.", 503, {
      provider: "openai-compatible"
    });
  }

  const model = chooseOpenAiModel(payload, task);
  const schema = options.schema ? parseJsonSchema(options.schema) : null;
  const systemInstruction = schema
    ? [
        payload.systemInstruction ? safeText(payload.systemInstruction, 3000) : "",
        "Balas hanya JSON valid yang cocok dengan schema yang diminta."
      ].filter(Boolean).join("\n\n")
    : payload.systemInstruction;

  const { messages, warnings } = await buildOpenAiMessages(payload, task, helpers, {
    systemInstruction,
    textOnly: Boolean(options.textOnly),
    appendText: schema ? `Schema JSON target:\n${JSON.stringify(schema)}` : ""
  });
  const toolBundle = buildOpenAiToolBundle(payload);
  warnings.push(...toolBundle.warnings);

  const responseFormat = schema
    ? {
        type: "json_schema",
        json_schema: {
          name: "ai_pro_output",
          strict: false,
          schema
        }
      }
    : null;

  const localToolResults = [];
  const workingMessages = [...messages];
  let response = null;
  const maxCalls = clamp(Number(payload.maxFunctionCalls) || 3, 1, 6);
  let iterations = 0;

  while (true) {
    response = await callOpenAiJson(
      "/chat/completions",
      buildOpenAiChatBody(payload, model, workingMessages, {
        tools: toolBundle.tools,
        responseFormat
      })
    );

    const message = response?.choices?.[0]?.message || {};
    const toolCalls = normalizeList(message.tool_calls);
    if (!toolBundle.allowFunctionTools || toolCalls.length === 0 || iterations >= maxCalls) {
      break;
    }

    iterations += 1;
    workingMessages.push({
      role: "assistant",
      content: message.content || "",
      tool_calls: toolCalls.map((call) => ({
        id: call.id,
        type: call.type || "function",
        function: {
          name: call.function?.name || "",
          arguments: call.function?.arguments || "{}"
        }
      }))
    });

    for (const toolCall of toolCalls) {
      const args = parseOpenAiToolArgs(toolCall.function?.arguments || "{}");
      const result = await invokeLocalFunction(toolCall.function?.name || "", args, helpers);
      localToolResults.push({
        name: toolCall.function?.name || "",
        args,
        result
      });
      workingMessages.push({
        role: "tool",
        tool_call_id: toolCall.id,
        content: JSON.stringify(result)
      });
    }
  }

  const summary = openAiResponseSummary(response, { model, warnings });
  if (schema) {
    let data = null;
    try {
      data = summary.text ? JSON.parse(summary.text) : null;
    } catch (error) {
      summary.warnings = dedupeMessages([
        ...summary.warnings,
        `JSON dari OpenAI-compatible tidak bisa diparse otomatis: ${error.message}`
      ]);
    }
    return {
      ...summary,
      localToolResults,
      data
    };
  }

  return {
    ...summary,
    localToolResults
  };
}

function flattenG4fMessageContent(content) {
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content
    .map((part) => {
      if (typeof part === "string") return part;
      if (part?.type === "text") return part.text || "";
      if (part?.type === "image_url") return `[image] ${part.image_url?.url || ""}`;
      return "";
    })
    .filter(Boolean)
    .join("\n\n");
}

async function buildG4fMessages(payload, task, helpers = {}, options = {}) {
  const schema = options.schema ? parseJsonSchema(options.schema) : null;
  const systemInstruction = schema
    ? [
        payload.systemInstruction ? safeText(payload.systemInstruction, 3000) : "",
        "Balas hanya JSON valid yang sesuai schema."
      ].filter(Boolean).join("\n\n")
    : payload.systemInstruction;

  const { messages, warnings } = await buildOpenAiMessages(payload, task, helpers, {
    systemInstruction,
    textOnly: true,
    appendText: schema ? `Schema JSON target:\n${JSON.stringify(schema)}` : ""
  });

  return {
    messages: messages.map((entry) => ({
      role: entry.role,
      content: flattenG4fMessageContent(entry.content)
    })),
    warnings
  };
}

function runG4fScriptWithPython(pythonBin, payload) {
  return new Promise((resolve, reject) => {
    const child = spawn(pythonBin, [G4F_FALLBACK_SCRIPT], {
      cwd: __dirname,
      stdio: ["pipe", "pipe", "pipe"]
    });
    let stdout = "";
    let stderr = "";
    let settled = false;

    child.stdout.on("data", (chunk) => {
      stdout += String(chunk);
    });
    child.stderr.on("data", (chunk) => {
      stderr += String(chunk);
    });
    child.on("error", (error) => {
      if (settled) return;
      settled = true;
      reject(error);
    });
    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      if (code === 0) {
        resolve(stdout.trim());
        return;
      }
      reject(providerError(`g4f fallback gagal (${code}): ${stderr.trim() || stdout.trim() || "tanpa output"}`, 502, {
        provider: "g4f"
      }));
    });

    child.stdin.write(JSON.stringify(payload));
    child.stdin.end();
  });
}

async function callG4f(payload) {
  if (!isG4fConfigured()) {
    throw providerError("g4f fallback belum dikonfigurasi.", 503, {
      provider: "g4f"
    });
  }

  let lastError = null;
  for (const pythonBin of PYTHON_CANDIDATES) {
    try {
      return await runG4fScriptWithPython(pythonBin, payload);
    } catch (error) {
      lastError = error;
      if (error?.code && error.code !== "ENOENT") {
        break;
      }
    }
  }

  if (lastError?.retryable !== undefined) {
    throw lastError;
  }

  throw providerError(`g4f fallback tidak bisa dijalankan: ${lastError?.message || "python tidak ditemukan"}`, 502, {
    provider: "g4f"
  });
}

function g4fResponseSummary(text, extra = {}) {
  return {
    ok: true,
    provider: "g4f",
    model: extra.model || null,
    responseId: null,
    text,
    functionCalls: [],
    generatedCode: null,
    codeExecutionResult: null,
    groundingMetadata: null,
    urlContextMetadata: null,
    usage: null,
    images: [],
    warnings: extra.warnings || []
  };
}

async function runG4fConversation(payload, task, helpers = {}, options = {}) {
  const { messages, warnings } = await buildG4fMessages(payload, task, helpers, options);

  if (payload.useFunctionTools) {
    warnings.push("Function calling tidak tersedia pada fallback g4f.");
  }
  if (payload.useGoogleSearch || payload.useUrlContext || payload.useGoogleMaps) {
    warnings.push("Grounding pada g4f fallback dikurangi ke konteks teks yang dirakit backend.");
  }

  const models = chooseG4fModels(payload, task);
  const text = await callG4f({ messages, models });
  const summary = g4fResponseSummary(text, {
    model: models[0] || null,
    warnings
  });

  if (options.schema) {
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch (error) {
      summary.warnings = dedupeMessages([
        ...summary.warnings,
        `JSON dari g4f tidak bisa diparse otomatis: ${error.message}`
      ]);
    }
    return { ...summary, data };
  }

  return { ...summary, localToolResults: [] };
}

function openAiImageSize(aspectRatio = "1:1") {
  const value = String(aspectRatio || "1:1").trim();
  if (["16:9", "4:3", "3:2"].includes(value)) return "1536x1024";
  if (["9:16", "3:4", "2:3"].includes(value)) return "1024x1536";
  return "1024x1024";
}

function openAiImageQuality(imageSize = "2K") {
  const value = String(imageSize || "2K").trim().toUpperCase();
  if (value === "4K") return "high";
  if (value === "1K") return "low";
  return "medium";
}

async function runOpenAiImageGeneration(payload, helpers = {}) {
  if (!isOpenAiConfigured()) {
    throw providerError("OpenAI-compatible image fallback belum dikonfigurasi.", 503, {
      provider: "openai-compatible"
    });
  }

  const prompt = buildPromptText(payload, "image");
  if (!prompt) {
    throw aiProError("prompt wajib diisi untuk image generation");
  }

  const fallbackContext = await buildFallbackContextNotes(payload, helpers);
  const warnings = [...fallbackContext.warnings];
  if (normalizeList(payload.media || payload.attachments || payload.files).length > 0) {
    warnings.push("Fallback OpenAI-compatible di backend ini hanya mengaktifkan generasi gambar dari prompt, bukan edit gambar berbasis attachment.");
  }

  const model = chooseOpenAiModel(payload, "image");
  const response = await callOpenAiJson("/images/generations", {
    model,
    prompt: [prompt, fallbackContext.text].filter(Boolean).join("\n\n"),
    size: openAiImageSize(payload.aspectRatio),
    quality: openAiImageQuality(payload.imageSize),
    n: 1
  });

  const images = normalizeList(response?.data).map((item, index) => ({
    index,
    mimeType: "image/png",
    base64: item?.b64_json || null,
    url: item?.url || null,
    dataUrl: item?.b64_json ? `data:image/png;base64,${item.b64_json}` : null
  }));

  return {
    ok: true,
    provider: "openai-compatible",
    model,
    responseId: response?.created ? String(response.created) : null,
    text: "Gambar berhasil dibuat melalui OpenAI-compatible fallback.",
    functionCalls: [],
    generatedCode: null,
    codeExecutionResult: null,
    groundingMetadata: null,
    urlContextMetadata: null,
    usage: response?.usage || null,
    images,
    warnings,
    imageConfig: {
      aspectRatio: hasValue(payload.aspectRatio) ? String(payload.aspectRatio).trim() : "1:1",
      imageSize: hasValue(payload.imageSize) ? String(payload.imageSize).trim().toUpperCase() : "2K",
      fallbackSize: openAiImageSize(payload.aspectRatio),
      fallbackQuality: openAiImageQuality(payload.imageSize)
    }
  };
}

async function runGeminiChat(payload, helpers = {}) {
  const client = getGeminiClient();
  const model = chooseGeminiModel(payload, "chat");
  const contents = await buildContents(client, payload, "chat");
  const { tools, toolConfig, allowFunctionTools, warnings } = buildGeminiToolBundle(payload, true);
  const config = buildGenerationConfig(payload, { tools, toolConfig });

  const result = allowFunctionTools
    ? await runFunctionLoop(
        client,
        model,
        contents,
        config,
        helpers,
        clamp(Number(payload.maxFunctionCalls) || 3, 1, 6)
      )
    : { response: await client.models.generateContent({ model, contents, config }), localToolResults: [] };

  return {
    ...responseSummary(result.response, { model, warnings, provider: "google-genai" }),
    localToolResults: result.localToolResults,
    mode: payload.mode || "auto"
  };
}

async function runGeminiStructured(payload) {
  const client = getGeminiClient();
  const model = chooseGeminiModel(payload, "structured");
  const contents = await buildContents(client, payload, "chat");
  const { tools, toolConfig, warnings } = buildGeminiToolBundle(payload, false);
  const config = buildGenerationConfig(payload, {
    tools,
    toolConfig,
    responseJsonSchema: parseJsonSchema(payload.schema)
  });
  const response = await client.models.generateContent({ model, contents, config });
  let data = null;
  try {
    data = response.text ? JSON.parse(response.text) : null;
  } catch (error) {
    warnings.push(`Model mengembalikan JSON yang tidak bisa diparse otomatis: ${error.message}`);
  }

  return {
    ...responseSummary(response, { model, warnings, provider: "google-genai" }),
    data
  };
}

async function runGeminiMediaAnalysis(payload) {
  const client = getGeminiClient();
  const model = chooseGeminiModel(payload, "media");
  const contents = await buildContents(client, payload, "media");
  const { tools, toolConfig, warnings } = buildGeminiToolBundle(payload, false);
  const config = buildGenerationConfig(payload, { tools, toolConfig });
  const response = await client.models.generateContent({ model, contents, config });

  return {
    ...responseSummary(response, { model, warnings, provider: "google-genai" }),
    mediaSummary: {
      attachments: normalizeList(payload.media || payload.attachments || payload.files).length
    }
  };
}

async function runGeminiImageGeneration(payload) {
  const client = getGeminiClient();
  const model = chooseGeminiModel(payload, "image");
  const contents = await buildContents(client, payload, "image");
  const { warnings } = buildGeminiToolBundle(payload, false);
  const config = buildGenerationConfig(payload, { imageGeneration: true });
  const response = await client.models.generateContent({ model, contents, config });

  return {
    ...responseSummary(response, { model, warnings, provider: "google-genai" }),
    imageConfig: config.imageConfig
  };
}

function getTaskOrder(task) {
  const providerState = getProviderState();
  const order = [];

  if (providerState.providers.gemini.available) {
    order.push("google-genai");
  }
  if (providerState.providers.openaiCompatible.available) {
    order.push("openai-compatible");
  }
  if (providerState.providers.g4f.available && task !== "image") {
    order.push("g4f");
  }

  return { providerState, order };
}

function noProviderConfiguredMessage(task, providerState) {
  if (providerState.configured && task === "image" && providerState.providers.g4f.available) {
    return aiProError(
      "Image generation memerlukan Gemini atau OpenAI-compatible. g4f fallback tidak mendukung keluaran gambar di backend ini.",
      501
    );
  }

  return aiProError(
    "AI Pro belum dikonfigurasi. Atur GEMINI_API_KEY/GOOGLE_API_KEY, atau OPENAI_API_KEY/OPENAI_BASE_URL, atau siapkan g4f fallback.",
    503
  );
}

async function runTaskOnProvider(provider, task, payload, helpers = {}) {
  if (provider === "google-genai") {
    if (task === "structured") return runGeminiStructured(payload);
    if (task === "media") return runGeminiMediaAnalysis(payload);
    if (task === "image") return runGeminiImageGeneration(payload);
    return runGeminiChat(payload, helpers);
  }

  if (provider === "openai-compatible") {
    if (task === "structured") return runOpenAiConversation(payload, task, helpers, { schema: payload.schema });
    if (task === "media") return runOpenAiConversation(payload, task, helpers);
    if (task === "image") return runOpenAiImageGeneration(payload, helpers);
    return runOpenAiConversation(payload, task, helpers);
  }

  if (provider === "g4f") {
    if (task === "structured") return runG4fConversation(payload, task, helpers, { schema: payload.schema });
    if (task === "media") return runG4fConversation(payload, task, helpers);
    if (task === "image") {
      throw aiProError("g4f fallback tidak mendukung image generation.", 501);
    }
    return runG4fConversation(payload, task, helpers);
  }

  throw aiProError(`Provider AI Pro tidak dikenali: ${provider}`, 500);
}

function mergeProviderWarnings(result, chainWarnings) {
  return dedupeMessages([...(result.warnings || []), ...chainWarnings]);
}

async function runWithFallback(task, payload, helpers = {}) {
  const { providerState, order } = getTaskOrder(task);
  if (order.length === 0) {
    throw noProviderConfiguredMessage(task, providerState);
  }

  const failures = [];
  const chainWarnings = [];

  for (let index = 0; index < order.length; index += 1) {
    const provider = order[index];
    try {
      const result = await runTaskOnProvider(provider, task, payload, helpers);
      return {
        ...result,
        provider,
        providerChain: order,
        fallbackUsed: index > 0,
        previousFailures: failures,
        warnings: mergeProviderWarnings(result, chainWarnings)
      };
    } catch (error) {
      if (!error?.retryable || index === order.length - 1) {
        if (failures.length > 0) {
          error.message = `${error.message} | Provider sebelumnya: ${failures.map((entry) => `${entry.provider}: ${entry.message}`).join("; ")}`;
        }
        throw error;
      }

      failures.push({ provider, message: error.message });
      chainWarnings.push(`Provider ${provider} gagal. Mencoba fallback berikutnya.`);
    }
  }

  throw aiProError("Semua provider AI Pro gagal.", 502);
}

export async function runAiProChat(payload, helpers = {}) {
  return runWithFallback("chat", payload, helpers);
}

export async function runAiProStructured(payload, helpers = {}) {
  return runWithFallback("structured", payload, helpers);
}

export async function runAiProMediaAnalysis(payload, helpers = {}) {
  return runWithFallback("media", payload, helpers);
}

export async function runAiProImageGeneration(payload, helpers = {}) {
  return runWithFallback("image", payload, helpers);
}
