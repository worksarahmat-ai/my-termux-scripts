import express from "express";
import { exec } from "child_process";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import { z } from "zod";

const app = express();
const PORT = 3000;

app.use(express.json());

const transports = {};

function runCommand(command) {
  return new Promise((resolve) => {
    const blocked = [
      "rm -rf",
      "mkfs",
      "dd ",
      ":(){",
      "reboot",
      "shutdown",
      "su ",
      "chmod 777 /",
      "chown -R /",
      "curl | sh",
      "wget | sh"
    ];

    if (blocked.some((bad) => command.includes(bad))) {
      resolve("Command diblokir demi keamanan.");
      return;
    }

    exec(command, {
      cwd: process.env.HOME,
      timeout: 20000,
      maxBuffer: 1024 * 1024
    }, (error, stdout, stderr) => {
      const output = [
        stdout ? `STDOUT:\n${stdout}` : "",
        stderr ? `STDERR:\n${stderr}` : "",
        error ? `ERROR:\n${error.message}` : ""
      ].filter(Boolean).join("\n");

      resolve(output || "(tidak ada output)");
    });
  });
}

function createMcpServer() {
  const server = new McpServer({
    name: "termux-mcp",
    version: "1.0.0"
  });

  server.tool(
    "termux_info",
    "Menampilkan informasi dasar Termux.",
    {},
    async () => {
      const output = await runCommand(
        "pwd && whoami && uname -a && node -v && npm -v && python --version 2>&1"
      );

      return {
        content: [{ type: "text", text: output }]
      };
    }
  );

  server.tool(
    "termux_exec",
    "Menjalankan command shell terbatas di Termux.",
    {
      command: z.string().describe("Command shell yang akan dijalankan")
    },
    async ({ command }) => {
      const output = await runCommand(command);

      return {
        content: [{ type: "text", text: output }]
      };
    }
  );

  return server;
}

app.get("/health", (req, res) => {
  res.json({
    ok: true,
    name: "termux-mcp",
    transport: "sse"
  });
});

app.get("/sse", async (req, res) => {
  const transport = new SSEServerTransport("/messages", res);
  transports[transport.sessionId] = transport;

  res.on("close", () => {
    delete transports[transport.sessionId];
  });

  const server = createMcpServer();
  await server.connect(transport);
});

app.post("/messages", async (req, res) => {
  const sessionId = req.query.sessionId;
  const transport = transports[sessionId];

  if (!transport) {
    res.status(400).send("No transport found for sessionId");
    return;
  }

  await transport.handlePostMessage(req, res, req.body);
});

app.listen(PORT, () => {
  console.log(`MCP Termux server running on http://localhost:${PORT}`);
  console.log(`SSE endpoint: http://localhost:${PORT}/sse`);
  console.log(`Health check: http://localhost:${PORT}/health`);
});
