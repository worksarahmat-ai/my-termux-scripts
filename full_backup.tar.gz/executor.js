import express from "express";
import cors from "cors";
import { execFile } from "child_process";
import fs from "fs";
import https from "https";
import os from "os";
import path from "path";
import vm from "vm";
import axios from "axios";
import * as cheerio from "cheerio";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT || 8001); // Disesuaikan dengan port fetch di Frontend
const dataDir = path.join(__dirname, "backend-data");

fs.mkdirSync(dataDir, { recursive: true });

app.use(cors());
app.use(express.json({ limit: "80mb" }));

// Allowlist perintah aman yang bisa dieksekusi oleh Agen Gemini
const commandAllowlist = new Map([
  ["pwd", { bin: "pwd", maxArgs: 0 }],
  ["ls", { bin: "ls", maxArgs: 5 }],
  ["whoami", { bin: "whoami", maxArgs: 0 }],
  ["date", { bin: "date", maxArgs: 3 }],
  ["uname", { bin: "uname", maxArgs: 3 }],
  ["df", { bin: "df", maxArgs: 5 }],
  ["free", { bin: "free", maxArgs: 5 }],
  ["node", { bin: "node", maxArgs: 4 }],
  ["npm", { bin: "npm", maxArgs: 6 }],
  ["git", { bin: "git", maxArgs: 8 }],
  ["gcloud", { bin: "gcloud", maxArgs: 12 }],
  ["curl", { bin: "curl", maxArgs: 8 }],
  ["ping", { bin: "ping", maxArgs: 4 }]
]);

const blockedArgs = ["&&", "||", ";", "|", ">", ">>", "<", "`", "$(", "${"];
const blockedCommands = ["rm", "shutdown", "reboot", "mkfs", "su", "sudo", "dd"];

function splitCommand(input) {
  const matches = String(input || "").match(/"[^"]*"|'[^']*'|\S+/g) || [];
  return matches.map((part) => part.replace(/^["']|["']$/g, ""));
}

function hasBlockedArg(args) {
  const joinedArgs = args.join(" ");
  if (blockedArgs.some((blocked) => joinedArgs.includes(blocked))) return true;
  return args.some((arg) => blockedCommands.includes(String(arg).trim()));
}

// Handler Shell/Bash (Terminal)
function runAllowedCommand(command, timeout = 60000) {
  const parts = splitCommand(command);
  const name = parts[0];
  const args = parts.slice(1);
  const rule = commandAllowlist.get(name);

  if (!rule) throw Object.assign(new Error(`Command tidak diizinkan. Allowlist: ${[...commandAllowlist.keys()].join(", ")}`), { status: 403 });
  if (args.length > rule.maxArgs) throw Object.assign(new Error(`Maksimal ${rule.maxArgs} argumen.`), { status: 400 });
  if (hasBlockedArg(args)) throw Object.assign(new Error("Argumen berbahaya diblokir."), { status: 403 });

  return new Promise((resolve) => {
    execFile(rule.bin, args, { cwd: __dirname, timeout: Math.min(Number(timeout) || 60000, 180000) }, (error, stdout, stderr) => {
      resolve({
        status: "success",
        command: name,
        output: stdout || "",
        error: stderr || (error ? error.message : ""),
        return_code: error ? (error.code ?? 1) : 0
      });
    });
  });
}

// Handler Node.js/Javascript aman (Sandboxed VM)
function runJavaScript(code, input = {}, timeout = 5000) {
  const logs = [];
  const sandbox = {
    input, result: undefined,
    console: { log: (...args) => logs.push(args.join(" ")), error: (...args) => logs.push(args.join(" ")) },
    Math, Date, JSON, Number, String, Boolean, Array, Object, RegExp
  };
  const context = vm.createContext(sandbox);
  const script = new vm.Script(`"use strict";\n${String(code || "")}`);
  
  try {
    const value = script.runInContext(context, { timeout: Math.min(Number(timeout) || 5000, 10000) });
    return { status: "success", result: sandbox.result ?? value ?? null, logs };
  } catch (err) {
    return { status: "failed", error: err.message, logs };
  }
}

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

// Endpoints
app.get("/api/health", (req, res) => { res.json({ ok: true, time: new Date().toISOString() }); });

// Endpoint Eksekusi Shell (Diakses otomatis oleh AI/Frontend)
app.post("/api/execute", asyncHandler(async (req, res) => {
  const { command, timeout } = req.body || {};
  if (!command) return res.status(400).json({ error: "command wajib diisi" });
  res.json(await runAllowedCommand(command, timeout));
}));

// Endpoint Eksekusi JS (Diakses otomatis oleh AI/Frontend)
app.post("/api/code/javascript", (req, res) => {
  const { code, input, timeout } = req.body || {};
  if (!code) return res.status(400).json({ error: "code wajib diisi" });
  res.json(runJavaScript(code, input, timeout));
});

// Middleware Error
app.use((error, req, res, next) => {
  res.status(error.status || 500).json({ error: error.message || "Internal server error", status: error.status || 500 });
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Bismillaahirrahmaanirrahiim`);
  console.log(`Agentic Backend Executor listening on http://localhost:${port}`);
  console.log(`Menunggu perintah dari Gemini AI CLI...`);
});

