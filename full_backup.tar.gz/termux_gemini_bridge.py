#!/usr/bin/env python3
import http.server
import socketserver
import json
import os
import time
from urllib.parse import urlparse

from google import genai
from google.genai import types

HOST = "127.0.0.1"
PORT = 8001
MAX_BODY_BYTES = 256 * 1024

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
API_SERVER_TOKEN = os.environ.get("API_SERVER_TOKEN", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash-preview-09-2025")


def now_ms():
    return int(time.time() * 1000)


def send_json(handler, data, code=200):
    raw = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(raw)))
    handler.send_header("Access-Control-Allow-Origin", "http://127.0.0.1")
    handler.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    handler.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
    handler.end_headers()
    handler.wfile.write(raw)


def read_json(handler):
    length = int(handler.headers.get("Content-Length", "0"))
    if length <= 0:
        raise ValueError("Body JSON kosong.")
    if length > MAX_BODY_BYTES:
        raise ValueError("Body terlalu besar.")
    return json.loads(handler.rfile.read(length))


def require_auth(handler):
    if not API_SERVER_TOKEN:
        send_json(handler, {
            "ok": False,
            "error": "API_SERVER_TOKEN belum diset."
        }, 500)
        return False

    auth = handler.headers.get("Authorization", "")
    if auth != f"Bearer {API_SERVER_TOKEN}":
        send_json(handler, {
            "ok": False,
            "error": "Unauthorized. Pakai: Authorization: Bearer $API_SERVER_TOKEN"
        }, 401)
        return False

    return True


def extract_sources(response):
    sources = []
    web_search_queries = []
    maps_widget_context_token = None

    if not response.candidates:
        return {
            "web_search_queries": [],
            "sources": [],
            "maps_widget_context_token": None
        }

    cand = response.candidates[0]
    grounding = getattr(cand, "grounding_metadata", None)

    if grounding:
        queries = getattr(grounding, "web_search_queries", None)
        if queries:
            web_search_queries = list(queries)

        token = getattr(grounding, "google_maps_widget_context_token", None)
        if token:
            maps_widget_context_token = token

        chunks = getattr(grounding, "grounding_chunks", None) or []
        seen = set()

        for chunk in chunks:
            web = getattr(chunk, "web", None)
            maps = getattr(chunk, "maps", None)

            if web:
                title = getattr(web, "title", None)
                uri = getattr(web, "uri", None)
                key = ("web", title, uri)
                if uri and key not in seen:
                    seen.add(key)
                    sources.append({
                        "type": "web",
                        "title": title,
                        "uri": uri
                    })

            if maps:
                title = getattr(maps, "title", None)
                uri = getattr(maps, "uri", None)
                place_id = getattr(maps, "place_id", None)
                key = ("maps", title, uri, place_id)
                if key not in seen:
                    seen.add(key)
                    sources.append({
                        "type": "maps",
                        "title": title,
                        "uri": uri,
                        "place_id": place_id
                    })

    return {
        "web_search_queries": web_search_queries,
        "sources": sources,
        "maps_widget_context_token": maps_widget_context_token
    }


def extract_url_context(response):
    if not response.candidates:
        return []

    cand = response.candidates[0]
    meta = getattr(cand, "url_context_metadata", None)
    if not meta:
        return []

    items = []
    for item in getattr(meta, "url_metadata", []) or []:
        items.append({
            "retrieved_url": getattr(item, "retrieved_url", None),
            "url_retrieval_status": str(getattr(item, "url_retrieval_status", None))
        })
    return items


def build_config(data):
    tools = []
    requested = data.get("tools") or []
    requested = [str(x).lower() for x in requested]

    if data.get("use_search") or "search" in requested or "google_search" in requested:
        tools.append({"google_search": {}})

    if data.get("urls") or "url" in requested or "url_context" in requested:
        tools.append({"url_context": {}})

    if data.get("use_maps") or "maps" in requested or "google_maps" in requested:
        tools.append(
            types.Tool(
                google_maps=types.GoogleMaps(
                    enable_widget=bool(data.get("enable_maps_widget", False))
                )
            )
        )

    cfg = {
        "temperature": float(data.get("temperature", 0.25))
    }

    if tools:
        cfg["tools"] = tools

    if data.get("schema"):
        cfg["response_format"] = {
            "text": {
                "mime_type": "application/json",
                "schema": data["schema"]
            }
        }

    lat = data.get("lat", data.get("latitude"))
    lng = data.get("lng", data.get("longitude"))
    if lat is not None and lng is not None:
        cfg["tool_config"] = types.ToolConfig(
            retrieval_config=types.RetrievalConfig(
                lat_lng=types.LatLng(
                    latitude=float(lat),
                    longitude=float(lng)
                )
            )
        )

    return cfg


def build_prompt(data):
    prompt = str(data.get("prompt") or "").strip()
    if not prompt:
        raise ValueError("Field 'prompt' wajib diisi.")

    urls = data.get("urls") or []
    if urls:
        valid_urls = []
        for u in urls:
            parsed = urlparse(str(u))
            if parsed.scheme not in ("http", "https") or not parsed.netloc:
                raise ValueError(f"URL tidak valid: {u}")
            valid_urls.append(str(u))

        prompt += "\n\nGunakan konteks dari URL berikut bila relevan:\n"
        prompt += "\n".join(f"- {u}" for u in valid_urls)

    language = data.get("language")
    if language:
        prompt += f"\n\nJawab dalam bahasa: {language}."

    return prompt


def call_gemini(data):
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY belum diset.")

    client = genai.Client(api_key=GEMINI_API_KEY)
    model = data.get("model") or GEMINI_MODEL
    prompt = build_prompt(data)
    config = build_config(data)

    started = now_ms()
    response = client.models.generate_content(
        model=model,
        contents=prompt,
        config=config
    )
    elapsed = now_ms() - started

    text = response.text or ""
    structured = None

    if data.get("schema"):
        try:
            structured = json.loads(text)
        except Exception:
            structured = None

    return {
        "ok": True,
        "model": model,
        "elapsed_ms": elapsed,
        "text": text,
        "structured": structured,
        "grounding": extract_sources(response),
        "url_context": extract_url_context(response),
        "notice": "Jika tools maps aktif, tampilkan bahwa jawaban memakai data Google Maps."
    }


class Handler(http.server.SimpleHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def do_GET(self):
        if self.path == "/health":
            send_json(self, {
                "ok": True,
                "service": "Termux Gemini Bridge",
                "gemini_key_set": bool(GEMINI_API_KEY),
                "api_token_set": bool(API_SERVER_TOKEN),
                "model": GEMINI_MODEL
            })
            return

        send_json(self, {
            "ok": False,
            "error": "Endpoint tidak ditemukan."
        }, 404)

    def do_POST(self):
        if self.path != "/api/gemini":
            send_json(self, {
                "ok": False,
                "error": "Endpoint tidak ditemukan."
            }, 404)
            return

        if not require_auth(self):
            return

        try:
            data = read_json(self)
            result = call_gemini(data)
            send_json(self, result, 200)
        except Exception as e:
            send_json(self, {
                "ok": False,
                "error": str(e)
            }, 500)


class ThreadingServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True


if __name__ == "__main__":
    if not API_SERVER_TOKEN:
        print("ERROR: API_SERVER_TOKEN belum diset.")
        raise SystemExit(2)

    print(f"Server aktif: http://{HOST}:{PORT}")
    print(f"Model default: {GEMINI_MODEL}")
    with ThreadingServer((HOST, PORT), Handler) as httpd:
        httpd.serve_forever()
