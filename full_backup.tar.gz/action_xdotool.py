import os
import shutil
import subprocess


class XDoTool:
    def __init__(self, display, checkpoint):
        self.display = display
        self.checkpoint = checkpoint

    def available(self):
        return shutil.which("xdotool") is not None

    def _env(self):
        env = os.environ.copy()
        env["DISPLAY"] = self.display
        return env

    def key(self, key_name):
        if not self.available():
            raise RuntimeError("xdotool tidak tersedia.")
        subprocess.run(["xdotool", "key", key_name], env=self._env(), check=False)
        self.checkpoint.log("xdotool_key", key=key_name)

    def click(self, x, y):
        if not self.available():
            raise RuntimeError("xdotool tidak tersedia.")
        subprocess.run(["xdotool", "mousemove", str(x), str(y), "click", "1"], env=self._env(), check=False)
        self.checkpoint.log("xdotool_click", x=x, y=y)

    def type_text(self, text):
        if not self.available():
            raise RuntimeError("xdotool tidak tersedia.")
        subprocess.run(["xdotool", "type", "--delay", "20", text], env=self._env(), check=False)
        self.checkpoint.log("xdotool_type", length=len(text))
