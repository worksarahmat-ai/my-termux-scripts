#!/data/data/com.termux/files/usr/bin/python3
import argparse
import json
import os
import sqlite3
import subprocess
import sys
import time
from pathlib import Path


HOME = Path.home()
DEFAULT_PROFILE = HOME / ".config/mozilla/firefox/xwdib0et.default-default"
DEFAULT_OUTPUT = HOME / "omni_identity_profile/vault_data/profiles/google/page_capture"
DEFAULT_URL = "https://myaccount.google.com/"


def read_google_cookie_summary(profile_dir):
    db_path = profile_dir / "cookies.sqlite"
    if not db_path.exists():
        return {
            "cookies_sqlite": str(db_path),
            "exists": False,
            "google_cookie_count": 0,
            "login_cookie_names": [],
        }

    login_names = {
        "SID",
        "LSID",
        "SSID",
        "HSID",
        "APISID",
        "SAPISID",
        "ACCOUNT_CHOOSER",
        "__Host-1PLSID",
        "__Host-3PLSID",
        "__Host-GAPS",
        "__Secure-1PSID",
        "__Secure-3PSID",
    }

    con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        rows = con.execute(
            """
            select host, name, isSecure, isHttpOnly
            from moz_cookies
            where host like '%google%'
            order by host, name
            """
        ).fetchall()
    finally:
        con.close()

    found_login_names = sorted({name for _host, name, _secure, _http_only in rows if name in login_names})
    hosts = sorted({host for host, _name, _secure, _http_only in rows})

    return {
        "cookies_sqlite": str(db_path),
        "exists": True,
        "google_cookie_count": len(rows),
        "google_cookie_hosts": hosts,
        "login_cookie_names": found_login_names,
        "has_google_login_cookie_signal": bool(found_login_names),
        "note": "Cookie values are intentionally not exported.",
    }


def run_firefox_screenshot(profile_dir, output_png, url, width, height, timeout):
    output_png.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "firefox",
        "--headless",
        "--profile",
        str(profile_dir),
        "--window-size",
        f"{width},{height}",
        "--screenshot",
        str(output_png),
        url,
    ]

    started = time.time()
    proc = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=timeout,
    )

    return {
        "command": " ".join(cmd[:1] + ["--headless", "--profile", str(profile_dir), "--screenshot", str(output_png), url]),
        "returncode": proc.returncode,
        "elapsed_seconds": round(time.time() - started, 2),
        "stdout": proc.stdout.strip(),
        "stderr": proc.stderr.strip(),
        "screenshot_exists": output_png.exists(),
        "screenshot_path": str(output_png),
        "screenshot_size_bytes": output_png.stat().st_size if output_png.exists() else 0,
    }


def build_report(args):
    profile_dir = Path(args.profile).expanduser()
    out_dir = Path(args.output).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    screenshot_path = out_dir / "google_account_page.png"
    report_path = out_dir / "google_account_report.json"

    cookie_summary = read_google_cookie_summary(profile_dir)
    screenshot_result = run_firefox_screenshot(
        profile_dir=profile_dir,
        output_png=screenshot_path,
        url=args.url,
        width=args.width,
        height=args.height,
        timeout=args.timeout,
    )

    login_likely = (
        screenshot_result["returncode"] == 0
        and screenshot_result["screenshot_exists"]
        and screenshot_result["screenshot_size_bytes"] > 10_000
        and cookie_summary.get("has_google_login_cookie_signal", False)
    )

    report = {
        "target_url": args.url,
        "profile_dir": str(profile_dir),
        "captured_at_epoch": time.time(),
        "login_likely": login_likely,
        "expected_account": args.expected_account,
        "cookie_summary": cookie_summary,
        "screenshot": screenshot_result,
        "review_note": (
            "Open the screenshot to confirm the visible account name/email. "
            "This script does not export cookie values or passwords."
        ),
    }

    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    return report_path, screenshot_path, report


def main():
    parser = argparse.ArgumentParser(
        description="Capture Google Account page from an existing Firefox profile."
    )
    parser.add_argument("--profile", default=str(DEFAULT_PROFILE), help="Firefox profile directory")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT), help="Output directory")
    parser.add_argument("--url", default=DEFAULT_URL, help="Google page to capture")
    parser.add_argument("--expected-account", default="", help="Account email/name expected in screenshot")
    parser.add_argument("--width", type=int, default=1366, help="Screenshot width")
    parser.add_argument("--height", type=int, default=780, help="Screenshot height")
    parser.add_argument("--timeout", type=int, default=60, help="Firefox timeout in seconds")
    args = parser.parse_args()

    report_path, screenshot_path, report = build_report(args)

    print(f"report={report_path}")
    print(f"screenshot={screenshot_path}")
    print(f"login_likely={report['login_likely']}")
    print(f"google_cookie_count={report['cookie_summary'].get('google_cookie_count', 0)}")
    if report["cookie_summary"].get("login_cookie_names"):
        print("login_cookie_names=" + ",".join(report["cookie_summary"]["login_cookie_names"]))
    if args.expected_account:
        print(f"expected_account={args.expected_account}")
        print("account_text_check=manual_screenshot_review_required")


if __name__ == "__main__":
    try:
        main()
    except subprocess.TimeoutExpired:
        print("ERROR: Firefox screenshot timed out.", file=sys.stderr)
        sys.exit(2)
