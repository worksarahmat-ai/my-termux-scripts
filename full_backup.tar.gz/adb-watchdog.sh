#!/data/data/com.termux/files/usr/bin/sh

HOME_DIR="/data/data/com.termux/files/home"
CONF_FILE="$HOME_DIR/backend-data/adb-autoconnect.conf"

if [ -f "$CONF_FILE" ]; then
  . "$CONF_FILE"
fi

ADB_WATCHDOG_INTERVAL="${ADB_WATCHDOG_INTERVAL:-60}"

while :; do
  ADB_CONNECT_RETRIES="${ADB_WATCHDOG_RETRIES:-1}" \
  ADB_CONNECT_INTERVAL="${ADB_WATCHDOG_RETRY_INTERVAL:-1}" \
    "$HOME_DIR/bin/adb-autoconnect.sh" once
  sleep "$ADB_WATCHDOG_INTERVAL"
done
