from g4f.client import Client
import g4f.Provider as Provider
import time

TESTS = [
    ("Qwen", "qwen3.6-plus"),
    ("Qwen_Qwen_3", "qwen-3-235b"),
    ("GeminiPro", "gemini-2.5-flash"),
    ("PollinationsAI", "gpt-4.1-nano"),
    ("DeepInfra", None),
    ("Groq", None),
    ("Nvidia", None),
    ("Copilot", "gpt-4o"),
    ("Perplexity", "gpt-5"),
    ("MetaAI", None),
    ("OperaAria", "aria"),
    ("ItalyGPT", "gpt-4o"),
]

prompt = "Jawab singkat: 2+2 berapa? Jangan panjang."

client = Client()

for provider_name, model in TESTS:
    if not hasattr(Provider, provider_name):
        continue

    provider = getattr(Provider, provider_name)
    print(f"\n=== TEST {provider_name} | model={model or 'default'} ===")

    try:
        start = time.time()

        kwargs = {
            "messages": [{"role": "user", "content": prompt}],
            "provider": provider,
            "stream": False,
        }

        if model:
            kwargs["model"] = model
        else:
            kwargs["model"] = getattr(provider, "default_model", "gpt-4o")

        response = client.chat.completions.create(**kwargs)

        elapsed = time.time() - start
        text = response.choices[0].message.content

        print("OK")
        print("time:", round(elapsed, 2), "s")
        print("response:", text[:500])

    except Exception as e:
        print("FAILED")
        print(type(e).__name__ + ":", str(e)[:700])
