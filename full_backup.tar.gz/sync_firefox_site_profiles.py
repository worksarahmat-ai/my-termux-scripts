#!/usr/bin/env python3
import ast
import pathlib
import re
import shutil
import time

HOME = pathlib.Path.home()
FIREFOX_ROOT = HOME / ".config" / "mozilla" / "firefox"
PROFILES_INI = FIREFOX_ROOT / "profiles.ini"
VAULT_ROOT = HOME / "omni_identity_profile" / "vault_data" / "profiles"
MANAGER = HOME / "omni_profile_manager.py"
REAL_PROFILE_PATH = "xwdib0et.default-default"
NAME_RE = re.compile(r"^[A-Za-z0-9_]+$")


def load_site_names():
    names = set()

    if MANAGER.exists():
        tree = ast.parse(MANAGER.read_text(errors="replace"))
        for node in tree.body:
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "SITES":
                        data = ast.literal_eval(node.value)
                        names.update(data.keys())

    if VAULT_ROOT.exists():
        for child in VAULT_ROOT.iterdir():
            if child.is_dir() and NAME_RE.match(child.name):
                names.add(child.name)

    return sorted(names)


def split_sections(text):
    sections = []
    current_name = None
    current_lines = []

    for line in text.splitlines():
        if line.startswith("[") and line.endswith("]"):
            if current_name is not None:
                sections.append((current_name, current_lines))
            current_name = line[1:-1]
            current_lines = [line]
        elif current_name is not None:
            current_lines.append(line)

    if current_name is not None:
        sections.append((current_name, current_lines))

    return sections


def section_value(lines, key):
    prefix = f"{key}="
    for line in lines:
        if line.startswith(prefix):
            return line[len(prefix):]
    return None


def main():
    if not PROFILES_INI.exists():
        raise SystemExit(f"profiles.ini tidak ditemukan: {PROFILES_INI}")

    backup = PROFILES_INI.with_name(f"profiles.ini.bak-site-profiles-{time.strftime('%Y%m%d-%H%M%S')}")
    shutil.copy2(PROFILES_INI, backup)

    text = PROFILES_INI.read_text(errors="replace")
    sections = split_sections(text)
    profile_sections = []
    other_sections = []
    existing_names = set()
    max_profile_index = -1

    for section_name, lines in sections:
        if section_name.startswith("Profile") and section_name[7:].isdigit():
            profile_sections.append((section_name, lines))
            max_profile_index = max(max_profile_index, int(section_name[7:]))
            name = section_value(lines, "Name")
            if name:
                existing_names.add(name)
        else:
            other_sections.append((section_name, lines))

    added = []
    for site_name in load_site_names():
        if site_name in existing_names:
            continue
        max_profile_index += 1
        profile_sections.append((
            f"Profile{max_profile_index}",
            [
                f"[Profile{max_profile_index}]",
                f"Name={site_name}",
                "IsRelative=1",
                f"Path={REAL_PROFILE_PATH}",
            ],
        ))
        existing_names.add(site_name)
        added.append(site_name)

    output_sections = []
    output_sections.extend(profile_sections)
    output_sections.extend(other_sections)

    PROFILES_INI.write_text(
        "\n\n".join("\n".join(lines) for _, lines in output_sections) + "\n",
        encoding="utf-8",
    )

    print(f"backup={backup}")
    print(f"real_profile_path={FIREFOX_ROOT / REAL_PROFILE_PATH}")
    print(f"added_count={len(added)}")
    if added:
        print("added=" + ",".join(added))


if __name__ == "__main__":
    main()
