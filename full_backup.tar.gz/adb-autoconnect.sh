#!/data/data/com.termux/files/usr/bin/sh

HOME_DIR="/data/data/com.termux/files/home"
CONF_FILE="$HOME_DIR/backend-data/adb-autoconnect.conf"
LOG_FILE="$HOME_DIR/backend-data/adb-autoconnect.log"

mkdir -p "$HOME_DIR/backend-data"

ENV_ADB_AUTO_CONNECT="${ADB_AUTO_CONNECT:-}"
ENV_ADB_CONNECT_RETRIES="${ADB_CONNECT_RETRIES:-}"
ENV_ADB_CONNECT_INTERVAL="${ADB_CONNECT_INTERVAL:-}"
ENV_ADB_HOST="${ADB_HOST:-}"
ENV_ADB_PORT="${ADB_PORT:-}"
ENV_ADB_SERIAL="${ADB_SERIAL:-}"
ENV_ADB_CONNECT_TARGETS="${ADB_CONNECT_TARGETS:-}"
ENV_ADB_MDNS_DISCOVERY="${ADB_MDNS_DISCOVERY:-}"
ENV_ADB_LOCAL_PORT_DISCOVERY="${ADB_LOCAL_PORT_DISCOVERY:-}"
ENV_ADB_LOCAL_PORT_MIN="${ADB_LOCAL_PORT_MIN:-}"
ENV_ADB_LOCAL_PORT_MAX="${ADB_LOCAL_PORT_MAX:-}"
ENV_ADB_SERVER_SOCKET="${ADB_SERVER_SOCKET:-}"
ENV_RISH_PATH="${RISH_PATH:-}"
ENV_RISH_APPLICATION_ID="${RISH_APPLICATION_ID:-}"

if [ -f "$CONF_FILE" ]; then
  . "$CONF_FILE"
fi

[ -n "$ENV_ADB_AUTO_CONNECT" ] && ADB_AUTO_CONNECT="$ENV_ADB_AUTO_CONNECT"
[ -n "$ENV_ADB_CONNECT_RETRIES" ] && ADB_CONNECT_RETRIES="$ENV_ADB_CONNECT_RETRIES"
[ -n "$ENV_ADB_CONNECT_INTERVAL" ] && ADB_CONNECT_INTERVAL="$ENV_ADB_CONNECT_INTERVAL"
[ -n "$ENV_ADB_HOST" ] && ADB_HOST="$ENV_ADB_HOST"
[ -n "$ENV_ADB_PORT" ] && ADB_PORT="$ENV_ADB_PORT"
[ -n "$ENV_ADB_SERIAL" ] && ADB_SERIAL="$ENV_ADB_SERIAL"
[ -n "$ENV_ADB_CONNECT_TARGETS" ] && ADB_CONNECT_TARGETS="$ENV_ADB_CONNECT_TARGETS"
[ -n "$ENV_ADB_MDNS_DISCOVERY" ] && ADB_MDNS_DISCOVERY="$ENV_ADB_MDNS_DISCOVERY"
[ -n "$ENV_ADB_LOCAL_PORT_DISCOVERY" ] && ADB_LOCAL_PORT_DISCOVERY="$ENV_ADB_LOCAL_PORT_DISCOVERY"
[ -n "$ENV_ADB_LOCAL_PORT_MIN" ] && ADB_LOCAL_PORT_MIN="$ENV_ADB_LOCAL_PORT_MIN"
[ -n "$ENV_ADB_LOCAL_PORT_MAX" ] && ADB_LOCAL_PORT_MAX="$ENV_ADB_LOCAL_PORT_MAX"
[ -n "$ENV_ADB_SERVER_SOCKET" ] && ADB_SERVER_SOCKET="$ENV_ADB_SERVER_SOCKET"
[ -n "$ENV_RISH_PATH" ] && RISH_PATH="$ENV_RISH_PATH"
[ -n "$ENV_RISH_APPLICATION_ID" ] && RISH_APPLICATION_ID="$ENV_RISH_APPLICATION_ID"

ADB_AUTO_CONNECT="${ADB_AUTO_CONNECT:-1}"
ADB_CONNECT_RETRIES="${ADB_CONNECT_RETRIES:-30}"
ADB_CONNECT_INTERVAL="${ADB_CONNECT_INTERVAL:-5}"
ADB_HOST="${ADB_HOST:-127.0.0.1}"
ADB_PORT="${ADB_PORT:-5555}"
ADB_MDNS_DISCOVERY="${ADB_MDNS_DISCOVERY:-1}"
ADB_LOCAL_PORT_DISCOVERY="${ADB_LOCAL_PORT_DISCOVERY:-1}"
ADB_LOCAL_PORT_MIN="${ADB_LOCAL_PORT_MIN:-30000}"
ADB_LOCAL_PORT_MAX="${ADB_LOCAL_PORT_MAX:-65535}"
RISH_PATH="${RISH_PATH:-$HOME_DIR/rish}"
RISH_APPLICATION_ID="${RISH_APPLICATION_ID:-com.termux}"

if [ -z "${ADB_SERVER_SOCKET:-}" ]; then
  unset ADB_SERVER_SOCKET
else
  export ADB_SERVER_SOCKET
fi

log() {
  printf '%s %s\n' "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$*"
}

is_connected() {
  adb devices 2>/dev/null | awk 'NR > 1 && $2 == "device" { found = 1 } END { exit found ? 0 : 1 }'
}

print_devices() {
  adb devices -l 2>&1
}

rish_shell() {
  [ -x "$RISH_PATH" ] || return 1
  RISH_APPLICATION_ID="$RISH_APPLICATION_ID" "$RISH_PATH" -c "$1" 2>/dev/null
}

local_adb_targets() {
  [ "$ADB_LOCAL_PORT_DISCOVERY" != "0" ] || return 0

  rish_shell "ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null" | awk \
    -v min="$ADB_LOCAL_PORT_MIN" \
    -v max="$ADB_LOCAL_PORT_MAX" '
      match($0, /[:.]([0-9]+)[[:space:]]/, port) {
        value = port[1] + 0
        if (value >= min && value <= max && value != 5037 && value != 5555) {
          print "127.0.0.1:" value
        }
      }
    '
}

candidate_targets() {
  {
    if [ -n "${ADB_CONNECT_TARGETS:-}" ]; then
      printf '%s\n' $ADB_CONNECT_TARGETS
    fi

    case "${ADB_SERIAL:-}" in
      *:*) printf '%s\n' "$ADB_SERIAL" ;;
    esac

    if [ -n "${ADB_HOST:-}" ] && [ -n "${ADB_PORT:-}" ]; then
      printf '%s:%s\n' "$ADB_HOST" "$ADB_PORT"
    fi

    if [ "$ADB_MDNS_DISCOVERY" != "0" ]; then
      adb mdns services 2>/dev/null | awk '
        /_adb-tls-connect\._tcp/ {
          for (i = 1; i <= NF; i++) {
            if ($i ~ /:[0-9]+$/) print $i
          }
        }
      '
    fi

    local_adb_targets
  } | awk 'NF && /:[0-9]+$/ && !seen[$0]++ { print }'
}

try_target() {
  target="$1"
  [ -n "$target" ] || return 1
  log "trying adb connect $target"
  adb connect "$target" 2>&1 | while IFS= read -r line; do log "$line"; done
  is_connected
}

if [ "$ADB_AUTO_CONNECT" = "0" ]; then
  log "ADB auto-connect disabled"
  exit 0
fi

if ! command -v adb >/dev/null 2>&1; then
  log "adb binary not found"
  exit 1
fi

log "starting adb server"
adb start-server 2>&1 | while IFS= read -r line; do log "$line"; done

if is_connected; then
  log "ADB already has an active device"
  print_devices
  exit 0
fi

attempt=1
while [ "$attempt" -le "$ADB_CONNECT_RETRIES" ]; do
  log "ADB auto-connect attempt $attempt/$ADB_CONNECT_RETRIES"

  targets="$(candidate_targets)"
  if [ -n "$targets" ]; then
    for target in $targets; do
      if try_target "$target"; then
        log "ADB connected through $target"
        print_devices
        exit 0
      fi
    done
  else
    log "no ADB target candidates found"
  fi

  if is_connected; then
    log "ADB connected"
    print_devices
    exit 0
  fi

  if [ "$attempt" -lt "$ADB_CONNECT_RETRIES" ]; then
    sleep "$ADB_CONNECT_INTERVAL"
  fi
  attempt=$((attempt + 1))
done

log "ADB auto-connect finished without an active device"
print_devices
exit 0
