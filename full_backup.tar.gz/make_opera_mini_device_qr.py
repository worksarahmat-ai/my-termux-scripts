#!/data/data/com.termux/files/usr/bin/python3
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

import qrcode


HOME = Path.home()
OUT_DIR = HOME / "omni_identity_profile/vault_data/profiles/opera-mini.android"
OUT_DIR.mkdir(parents=True, exist_ok=True)

payload = {
    "profile_name": "opera-mini.android",
    "package_name": "com.opera.mini.native",
    "purpose": "termux_android_device_link_marker_for_opera_mini",
    "connection_type": "local_identity_qr",
    "device": {
        "label": "termuxterminalemulatorlinuxandroidpocox3nfc",
        "model": "M2007J20CG",
        "baseband_version": "SS.AT.4.4.c6-00071-RENNELL_GEN_PACK-3.30805.9",
        "kernel_version": "4.14.190-perf-g75201eeb4293",
        "termux_home": str(HOME),
        "firefox_profile_dir": str(HOME / ".config/mozilla/firefox/xwdib0et.default-default"),
    },
    "status": {
        "opera_mini_package_observed_from_screenshot": True,
        "opera_mini_package_visible_to_termux_package_manager": False,
        "login_status": "pending_reconnect_or_manual_validation",
        "last_observed_message": "Wallet disconnected from phone number. Please reconnect.",
    },
    "created_at": datetime.now(timezone(timedelta(hours=7))).isoformat(),
}

payload_path = OUT_DIR / "device_link_payload.json"
png_path = OUT_DIR / "opera_mini_device_link_qr.png"
ascii_path = OUT_DIR / "opera_mini_device_link_qr.txt"

payload_text = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
payload_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

qr = qrcode.QRCode(
    version=None,
    error_correction=qrcode.constants.ERROR_CORRECT_M,
    box_size=10,
    border=4,
)
qr.add_data(payload_text)
qr.make(fit=True)

img = qr.make_image(fill_color="black", back_color="white")
img.save(png_path)

with ascii_path.open("w", encoding="utf-8") as f:
    qr.print_ascii(out=f, invert=True)

print(f"payload={payload_path}")
print(f"qr_png={png_path}")
print(f"qr_ascii={ascii_path}")
