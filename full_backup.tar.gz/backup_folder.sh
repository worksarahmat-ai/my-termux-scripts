#!/bin/bash

# Konfigurasi
SOURCE_DIR="/path/to/source"
DEST_DIR="/path/to/backup"
LOG_FILE="/var/log/rsync_backup.log"
RETENTION_DAYS=7

# Buat folder tujuan jika belum ada
mkdir -p "$DEST_DIR"

# Jalankan rsync
rsync -a --delete --partial --log-file="$LOG_FILE" "$SOURCE_DIR/" "$DEST_DIR/"

# Hapus backup lama (opsional, jika menggunakan struktur tanggal)
find "$DEST_DIR" -type d -mtime +"$RETENTION_DAYS" -exec rm -rf {} + 2>/dev/null

exit 0

