


import asyncio
import json
import os
import time
import uuid
import re
from typing import Literal, Optional, Dict, Any
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from google import genai
from google.genai import types

# Inisialisasi Aplikasi FastAPI
app = FastAPI(
    title="Termux Gemini Advanced Backend",
    version="1.0.0",
    description="Backend lokal penghubung Termux (Android) dengan Gemini API & CLI.",
)

from fastapi import FastAPI, HTTPException, BackgroundTasks, Header, Depends
# ...
# Konfigurasi Origin Terpercaya
ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://localhost:8765",
    "http://127.0.0.1:8765"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# Penyimpanan status Job di memori (In-Memory State)
JOBS: Dict[str, Dict[str, Any]] = {}

# Konfigurasi Gemini API
# Pastikan Anda telah set: export GEMINI_API_KEY="AIzaSy..." di Termux
API_KEY = os.environ.get("GEMINI_API_KEY", "")
gemini_client = genai.Client(api_key=API_KEY) if API_KEY else None


# ==========================================
# SCHEMA MODEL (PYDANTIC)
# ==========================================
class ShellRequest(BaseModel):
    command: str = Field(..., min_length=1, description="Perintah bash yang akan dieksekusi")
    cwd: Optional[str] = Field(default=None, description="Direktori kerja")
    timeout_sec: int = Field(default=60, ge=1, le=1800)
    background: bool = Field(default=False)

class GeminiRequest(BaseModel):
    prompt: str = Field(..., min_length=1)
    model: str = Field(default="gemini-2.5-flash-preview-09-2025")
    use_search: bool = Field(default=True, description="Aktifkan Google Search Grounding")
    use_code_execution: bool = Field(default=True, description="Aktifkan Eksekusi Python (Code Execution)")

# ==========================================
# HELPER FUNCTIONS
# ==========================================
async def run_subprocess(cmd: list[str], cwd: Optional[str], timeout_sec: int) -> tuple[str, str, int]:
    """Helper untuk menjalankan perintah shell dengan timeout."""
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_sec)
        return stdout.decode(errors="replace"), stderr.decode(errors="replace"), proc.returncode
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        raise HTTPException(status_code=504, detail=f"Process timeout after {timeout_sec}s")

def analyze_shell_error(stderr: str, exit_code: int) -> dict:
    """Menganalisis stderr untuk mendeteksi error Android spesifik seperti Permission Denied."""
    error_info = {"exit_code": exit_code, "raw_error": stderr, "classification": "general_error", "remediation": ""}
    
    if "Permission denied" in stderr:
        error_info["classification"] = "permission_denied"
        if "storage" in stderr.lower() or "sdcard" in stderr.lower():
            error_info["remediation"] = "Jalankan 'termux-setup-storage' untuk memberikan akses penyimpanan ke Termux."
        else:
            error_info["remediation"] = "Periksa izin file atau gunakan chmod."
    elif "No such file or directory" in stderr:
        error_info["classification"] = "not_found"
    elif "termux-api: command not found" in stderr:
        error_info["classification"] = "missing_dependency"
        error_info["remediation"] = "Jalankan 'apt install termux-api' dan instal aplikasi Termux:API dari F-Droid."
        
    return error_info


# ==========================================
# ENDPOINTS: SYSTEM HEALTH & METADATA
# ==========================================
@app.get("/healthz")
async def healthz():
    return {"status": "online", "api_key_configured": bool(API_KEY), "timestamp": int(time.time())}

@app.get("/v1/device/battery")
async def get_battery():
    """Mengambil informasi baterai via termux-api"""
    stdout, stderr, code = await run_subprocess(["termux-battery-status"], None, 10)
    if code != 0:
        return {"error": "Gagal membaca baterai", "details": analyze_shell_error(stderr, code)}
    try:
        return json.loads(stdout)
    except json.JSONDecodeError:
        return {"error": "Format output termux-api tidak valid", "raw": stdout}

@app.get("/v1/device/governor")
async def get_device_governor():
    """Penstabil: Mengevaluasi status baterai dan temperatur untuk mencegah overheat/drain."""
    battery_data = await get_battery()
    
    status = "SAFE"
    reason = "Kondisi perangkat optimal."
    
    if "percentage" in battery_data:
        if battery_data["percentage"] < 15 and battery_data["status"] != "CHARGING":
            status = "THROTTLED"
            reason = "Baterai sangat rendah (<15%). Batasi komputasi berat."
        
    # Simulasi pembacaan thermal zone (di Android biasanya di /sys/class/thermal/thermal_zone0/temp)
    try:
        if os.path.exists("/sys/class/thermal/thermal_zone0/temp"):
            with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
                temp_raw = int(f.read().strip())
                temp_c = temp_raw / 1000.0 if temp_raw > 1000 else temp_raw
                if temp_c > 45.0:
                    status = "CRITICAL"
                    reason = f"Temperatur tinggi ({temp_c}°C). Hentikan proses latar belakang."
    except Exception:
        pass # Abaikan jika tidak ada akses baca ke sysfs thermal

    return {"governor_status": status, "recommendation": reason, "battery": battery_data}


# ==========================================
# ENDPOINTS: EXECUTION (SHELL & MODEL)
# ==========================================
# Keamanan API
API_SECRET_KEY = os.environ.get("BACKEND_API_KEY", "default-insecure-key-change-me")

async def verify_api_key(x_api_key: str = Header(...)):
    if x_api_key != API_SECRET_KEY:
        raise HTTPException(status_code=403, detail="Akses ditolak: API Key tidak valid.")
    return x_api_key

# ...

from fastapi import Request

# Rate Limiting
REQUEST_LIMITS = {}
MAX_REQUESTS = 10
WINDOW_SECONDS = 60

async def rate_limiter(request: Request):
    client_ip = request.client.host
    now = time.time()
    
    if client_ip not in REQUEST_LIMITS:
        REQUEST_LIMITS[client_ip] = []
    
    # Bersihkan request lama
    REQUEST_LIMITS[client_ip] = [t for t in REQUEST_LIMITS[client_ip] if now - t < WINDOW_SECONDS]
    
    if len(REQUEST_LIMITS[client_ip]) >= MAX_REQUESTS:
        raise HTTPException(status_code=429, detail="Terlalu banyak permintaan. Coba lagi nanti.")
        
    REQUEST_LIMITS[client_ip].append(now)

@app.post("/v1/execute/shell", dependencies=[Depends(verify_api_key), Depends(rate_limiter)])
async def execute_shell(req: ShellRequest):
# ... (lanjutan fungsi)
    """Mengeksekusi perintah shell lokal di Termux."""
    job_id = str(uuid.uuid4())
    JOBS[job_id] = {"lane": "local_shell", "status": "running", "started_at": time.time()}

    if req.background:
        proc = await asyncio.create_subprocess_exec(
            "bash", "-lc", req.command,
            cwd=req.cwd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        JOBS[job_id].update({"status": "background", "pid": proc.pid})
        return {"job_id": job_id, "status": "background_task_started", "pid": proc.pid}

    stdout, stderr, code = await run_subprocess(["bash", "-lc", req.command], req.cwd, req.timeout_sec)
    
    result = {
        "job_id": job_id,
        "lane": "local_shell",
        "stdout": stdout.strip(),
        "exit_code": code,
    }
    
    if code != 0:
        result["error_analysis"] = analyze_shell_error(stderr, code)
    else:
        result["stderr"] = stderr.strip()

    JOBS[job_id].update({"status": "finished", "exit_code": code})
    return result

@app.post("/v1/execute/model")
async def execute_model(req: GeminiRequest):
    """
    Eksekusi Gemini API Tingkat Lanjut:
    Menggunakan Code Execution dan Google Search Grounding.
    """
    if not gemini_client:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY belum dikonfigurasi di environment Termux.")
    
    job_id = str(uuid.uuid4())
    JOBS[job_id] = {"lane": "model_code_search", "status": "running", "started_at": time.time()}
    
    # Menyiapkan Tools sesuai permintaan (Code Execution + Search)
    active_tools = []
    if req.use_search:
        active_tools.append(types.Tool(google_search=types.GoogleSearch()))
    if req.use_code_execution:
        active_tools.append(types.Tool(code_execution=types.ToolCodeExecution()))

    config = types.GenerateContentConfig(
        tools=active_tools if active_tools else None,
        temperature=0.4,
    )

    try:
        # Panggil Gemini API
        response = gemini_client.models.generate_content(
            model=req.model,
            contents=req.prompt,
            config=config
        )
        
        # Ekstrak data (Teks, Kode yang dijalankan, Sumber pencarian)
        executable_code = []
        execution_results = []
        grounding_sources = []
        
        if response.candidates:
            for part in response.candidates[0].content.parts:
                if part.executable_code:
                    executable_code.append(part.executable_code.code)
                if part.code_execution_result:
                    execution_results.append(part.code_execution_result.output)
            
            # Grounding metadata (Search)
            if response.candidates[0].grounding_metadata:
                metadata = response.candidates[0].grounding_metadata
                if metadata.grounding_attributions:
                    for attr in metadata.grounding_attributions:
                        if attr.web:
                            grounding_sources.append({"title": attr.web.title, "uri": attr.web.uri})

        JOBS[job_id].update({"status": "finished", "completed_at": time.time()})
        
        return {
            "job_id": job_id,
            "response_text": response.text,
            "code_executed": executable_code,
            "execution_outputs": execution_results,
            "search_sources": grounding_sources
        }

    except Exception as e:
        JOBS[job_id].update({"status": "failed", "error": str(e)})
        raise HTTPException(status_code=500, detail=str(e))

# ==========================================
# ENDPOINTS: JOB & RUNTIME MONITORING
# ==========================================
@app.get("/v1/jobs/{job_id}")
async def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    # Deteksi Stuck
    if job["status"] == "running":
        elapsed = time.time() - job["started_at"]
        if elapsed > 120:  # Jika berjalan lebih dari 2 menit tanpa selesai
            job["warning"] = "Job mungkin stuck atau memakan waktu sangat lama."
            
    return job

# Entry point jika dijalankan manual
if __name__ == "__main__":
    import uvicorn
    # Menjalankan di localhost port 8765 sesuai rekomendasi arsitektur
    print("Memulai Gemini Termux Backend di http://127.0.0.1:8765 ...")
    uvicorn.run(app, host="127.0.0.1", port=8765)
