from g4f.client import Client
from datetime import datetime
import os
import json
import subprocess

client = Client()

BASE_DIR = os.path.expanduser("~/g4f-agent")
MEMORY_DIR = os.path.join(BASE_DIR, "memory")
MEMORY_FILE = os.path.join(MEMORY_DIR, "chat.jsonl")

os.makedirs(MEMORY_DIR, exist_ok=True)

SYSTEM_PROMPT = """
Kamu adalah AI Agent lokal di Termux Android.
Jawab dalam Bahasa Indonesia.
Bantu user untuk coding, Linux, Termux, matematika, dan debugging.
Untuk kode dan matematika, pikirkan lebih teliti.
Jangan meminta atau menyimpan password, cookie, token, OTP, atau data rahasia.
"""

SAFE_COMMANDS = {
    "pwd",
    "ls",
    "ls -la",
    "date",
    "whoami",
    "uname -a",
    "df -h",
    "free",
    "python --version",
    "pip --version",
    "node --version",
    "npm --version",
}


def save_memory(role, content):
    item = {
        "time": datetime.now().isoformat(),
        "role": role,
        "content": content,
    }
    with open(MEMORY_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(item, ensure_ascii=False) + "\n")


def load_memory(limit=10):
    if not os.path.exists(MEMORY_FILE):
        return []

    with open(MEMORY_FILE, "r", encoding="utf-8") as f:
        lines = f.readlines()[-limit:]

    messages = []
    for line in lines:
        try:
            item = json.loads(line)
            messages.append({
                "role": item["role"],
                "content": item["content"],
            })
        except Exception:
            pass

    return messages


def shell_safe(cmd):
    cmd = cmd.strip()

    if cmd not in SAFE_COMMANDS:
        return f"Command ditolak demi keamanan: {cmd}"

    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=True,
        text=True,
        timeout=20
    )

    return result.stdout or result.stderr


def ask_ai(prompt, deep=False):
    memory = load_memory()

    mode = """
Mode deep aktif: analisis lebih teliti, terutama untuk kode, matematika, dan debugging.
""" if deep else """
Mode normal aktif: jawab jelas dan praktis.
"""

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT + "\n" + mode},
        *memory,
        {"role": "user", "content": prompt},
    ]

    response = client.chat.completions.create(
        model="gpt-4",
        messages=messages,
    )

    return response.choices[0].message.content


def main():
    print("=== G4F Agent Termux ===")
    print("Command:")
    print("  /exit                 keluar")
    print("  /deep pertanyaan      mode berpikir lebih teliti")
    print("  /sh ls -la            shell aman whitelist")
    print()

    while True:
        try:
            user = input("You> ").strip()
        except KeyboardInterrupt:
            print("\nKeluar.")
            break

        if not user:
            continue

        if user == "/exit":
            break

        if user.startswith("/sh "):
            cmd = user.replace("/sh ", "", 1)
            output = shell_safe(cmd)
            print(f"\nSHELL>\n{output}\n")
            save_memory("user", user)
            save_memory("assistant", output)
            continue

        deep = False
        if user.startswith("/deep "):
            deep = True
            user = user.replace("/deep ", "", 1)

        save_memory("user", user)

        try:
            answer = ask_ai(user, deep=deep)
            print(f"\nAgent> {answer}\n")
            save_memory("assistant", answer)
        except Exception as e:
            print(f"\nERROR> {e}\n")


if __name__ == "__main__":
    main()
