from selenium.webdriver.common.by import By


class StopRisk(Exception):
    pass


class FizzoLogic:
    def __init__(self, config, checkpoint, scanner=None):
        self.config = config
        self.checkpoint = checkpoint
        self.scanner = scanner

    def guard(self, text, source="dom"):
        lowered = (text or "").lower()
        hits = [word for word in self.config["guardrails"]["stopWords"] if word.lower() in lowered]
        if hits:
            self.checkpoint.save_state("STOP_RISK", source=source, hits=hits)
            raise StopRisk(f"Guardrail aktif: {', '.join(hits)}")

    def page_kind(self, text):
        lowered = (text or "").lower()
        if "mulai karir menulis" in lowered or "mulai karir" in lowered:
            return "writer_onboarding"
        if "fizzo" in lowered:
            return "fizzo_page"
        return "unknown"

    def run(self, browser):
        mode = self.config["mode"].upper()
        form = self.config["form"]
        browser.screenshot()

        text = browser.page_text()
        if len(text.strip()) < 20 and self.scanner:
            text = self.scanner.scan_text()
            self.guard(text, source="ocr")
        else:
            self.guard(text, source="dom")

        kind = self.page_kind(text)
        self.checkpoint.save_state("PAGE_DETECTED", kind=kind, mode=mode)

        if kind not in ("writer_onboarding", "fizzo_page"):
            self.checkpoint.save_state("WAIT_MANUAL", reason="Halaman Fizzo belum dikenali jelas.")
            return {"status": "WAIT_MANUAL", "kind": kind}

        filled = self.fill_writer_form(browser, form)
        browser.screenshot()

        if mode in ("DRY_RUN", "SAFE_RUN"):
            self.checkpoint.save_state("STOP_BEFORE_SUBMIT", mode=mode, filled=filled)
            return {"status": "STOP_BEFORE_SUBMIT", "filled": filled}

        if mode != "AUTO_RUN":
            self.checkpoint.save_state("STOP_UNKNOWN_MODE", mode=mode, filled=filled)
            return {"status": "STOP_UNKNOWN_MODE", "filled": filled}

        text = browser.page_text()
        self.guard(text, source="dom_before_submit")
        submitted = browser.click_first(SUBMIT_LOCATORS, "submit_start_writing")
        self.checkpoint.save_state("SUBMITTED" if submitted else "SUBMIT_NOT_FOUND", filled=filled)
        return {"status": "SUBMITTED" if submitted else "SUBMIT_NOT_FOUND", "filled": filled}

    def fill_writer_form(self, browser, form):
        result = {
            "penName": browser.fill_first(PEN_NAME_LOCATORS, form.get("penName", ""), "penName"),
            "heardFrom": browser.choose_first(HEARD_FROM_LOCATORS, form.get("heardFrom", ""), "heardFrom"),
            "hasWrittenNovelBefore": browser.choose_first(
                EXPERIENCE_LOCATORS,
                form.get("hasWrittenNovelBefore", ""),
                "hasWrittenNovelBefore",
            ),
            "referralCode": False,
        }
        referral = form.get("referralCode", "")
        if referral:
            result["referralCode"] = browser.fill_first(REFERRAL_LOCATORS, referral, "referralCode")
        else:
            self.checkpoint.log("skip_referral", reason="empty")
        return result


PEN_NAME_LOCATORS = [
    (By.XPATH, "//input[contains(@placeholder,'Nama Pena') or contains(@aria-label,'Nama Pena')]"),
    (By.XPATH, "//input[contains(@placeholder,'Pen') or contains(@aria-label,'Pen')]"),
    (By.XPATH, "(//input[not(@type='hidden')])[1]"),
]

HEARD_FROM_LOCATORS = [
    (By.XPATH, "//*[self::select or self::input or self::button or @role='combobox'][contains(@placeholder,'sumber') or contains(@aria-label,'sumber') or contains(normalize-space(),'sumber')]"),
    (By.XPATH, "//*[self::select or self::button or @role='combobox'][contains(normalize-space(),'tahu')]"),
]

EXPERIENCE_LOCATORS = [
    (By.XPATH, "//*[self::select or self::input or self::button or @role='combobox'][contains(@placeholder,'pengalaman') or contains(@aria-label,'pengalaman') or contains(normalize-space(),'pengalaman')]"),
    (By.XPATH, "//*[self::select or self::button or @role='combobox'][contains(normalize-space(),'menulis novel')]"),
]

REFERRAL_LOCATORS = [
    (By.XPATH, "//input[contains(@placeholder,'referensi') or contains(@aria-label,'referensi')]"),
    (By.XPATH, "//input[contains(@placeholder,'referral') or contains(@aria-label,'referral')]"),
]

SUBMIT_LOCATORS = [
    (By.XPATH, "//button[contains(normalize-space(),'Mulai Menulis')]"),
    (By.XPATH, "//*[self::button or @role='button'][contains(normalize-space(),'Mulai')]"),
]
