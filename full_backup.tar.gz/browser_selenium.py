import os
import pathlib
import shutil
import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait


class Browser:
    def __init__(self, config, checkpoint):
        self.config = config
        self.checkpoint = checkpoint
        self.driver = None

    def start(self):
        profile_name = self.config["profile"]
        display = self.config.get("display", ":1")
        os.environ["DISPLAY"] = display

        options = Options()
        options.add_argument("-P")
        options.add_argument(profile_name)
        options.add_argument("--width=1024")
        options.add_argument("--height=900")
        options.page_load_strategy = "eager"

        geckodriver = shutil.which("geckodriver")
        if not geckodriver:
            raise RuntimeError("geckodriver tidak ditemukan di PATH.")
        service = Service(executable_path=geckodriver)
        self.driver = webdriver.Firefox(service=service, options=options)
        self.driver.set_page_load_timeout(self.config["timeouts"]["page_load_seconds"])
        self.checkpoint.log("browser_started", profile=profile_name, display=display)
        return self.driver

    def open(self, url):
        try:
            self.driver.get(url)
        except Exception as error:
            self.checkpoint.log("browser_open_partial", url=url, error=str(error))
        self.checkpoint.log("browser_open", url=url, title=self.driver.title)

    def quit(self):
        if self.driver:
            self.driver.quit()
            self.checkpoint.log("browser_quit")

    def wait(self):
        return WebDriverWait(self.driver, self.config["timeouts"]["element_seconds"])

    def page_text(self):
        try:
            return self.driver.find_element(By.TAG_NAME, "body").text
        except Exception:
            return ""

    def screenshot(self):
        path = self.checkpoint.artifact_path("selenium", "png")
        self.driver.save_screenshot(str(path))
        self.checkpoint.log("selenium_screenshot", path=str(path), title=self.driver.title)
        return path

    def find_first(self, locators):
        for by, value in locators:
            try:
                element = self.driver.find_element(by, value)
                if element.is_displayed():
                    return element
            except Exception:
                continue
        return None

    def fill_first(self, locators, value, label):
        if value is None:
            return False
        element = self.find_first(locators)
        if not element:
            self.checkpoint.log("fill_missing", label=label)
            return False
        try:
            element.clear()
        except Exception:
            pass
        element.send_keys(value)
        self.checkpoint.log("fill", label=label, length=len(value))
        return True

    def choose_first(self, locators, value, label):
        element = self.find_first(locators)
        if not element:
            self.checkpoint.log("choose_missing", label=label)
            return False
        tag = element.tag_name.lower()
        if tag == "select":
            select = Select(element)
            try:
                select.select_by_visible_text(value)
            except Exception:
                select.select_by_value(value)
        else:
            element.click()
            time.sleep(0.3)
            try:
                option = self.driver.find_element(
                    By.XPATH,
                    f"//*[self::li or self::div or self::span or self::button][contains(normalize-space(), {xpath_literal(value)})]",
                )
                option.click()
            except Exception:
                element.send_keys(value)
        self.checkpoint.log("choose", label=label, value=value)
        return True

    def click_first(self, locators, label):
        element = self.find_first(locators)
        if not element:
            self.checkpoint.log("click_missing", label=label)
            return False
        element.click()
        self.checkpoint.log("click", label=label)
        return True


def xpath_literal(text):
    if "'" not in text:
        return f"'{text}'"
    if '"' not in text:
        return f'"{text}"'
    parts = text.split("'")
    return "concat(" + ', "\"\'\"", '.join(f"'{part}'" for part in parts) + ")"
