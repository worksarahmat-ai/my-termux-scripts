#!/data/data/com.termux/files/usr/bin/python3
import hashlib
import json
import pickle
import subprocess
import time
from pathlib import Path


HOME = Path.home()
PROFILE_DIR = HOME / "omni_identity_profile/vault_data/profiles/opera-mini.android"
OUT_DIR = PROFILE_DIR / "session_capture"
PACKAGE = "com.opera.mini.native"


def run(cmd, check=False, binary=False):
    result = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=check,
        text=not binary,
    )
    return result


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    package_path = OUT_DIR / "pm_path.txt"
    package_dump = OUT_DIR / "dumpsys_package.txt"
    focused_window = OUT_DIR / "focused_window.txt"
    ui_xml = OUT_DIR / "window.xml"
    screenshot = OUT_DIR / "screen.png"
    session_pickle = OUT_DIR / "cookiespkl.pkl"
    session_json = OUT_DIR / "session_proof.json"

    package_path.write_text(run(["adb", "shell", "pm", "path", PACKAGE]).stdout, encoding="utf-8")
    package_dump.write_text(run(["adb", "shell", "dumpsys", "package", PACKAGE]).stdout, encoding="utf-8")
    focused_window.write_text(
        run(["adb", "shell", "dumpsys", "window"]).stdout,
        encoding="utf-8",
    )

    run(["adb", "shell", "uiautomator", "dump", "/sdcard/window.xml"])
    pulled = run(["adb", "pull", "/sdcard/window.xml", str(ui_xml)])

    screen = run(["adb", "exec-out", "screencap", "-p"], binary=True)
    screenshot.write_bytes(screen.stdout)

    package_dump_text = package_dump.read_text(encoding="utf-8", errors="replace")
    ui_text = ui_xml.read_text(encoding="utf-8", errors="replace") if ui_xml.exists() else ""

    session = {
        "profile_name": "opera-mini.android",
        "package_name": PACKAGE,
        "capture_type": "adb_session_proof_not_raw_cookies",
        "captured_at_epoch": time.time(),
        "login_status_inference": {
            "package_installed": "Package [" in package_dump_text or package_path.stat().st_size > 0,
            "ui_dump_available": ui_xml.exists() and ui_xml.stat().st_size > 0,
            "screenshot_available": screenshot.exists() and screenshot.stat().st_size > 0,
            "sync_text_seen": "Sinkronisasi" in ui_text or "M2007J20CG" in ui_text,
        },
        "files": {
            "pm_path": str(package_path),
            "dumpsys_package": str(package_dump),
            "focused_window": str(focused_window),
            "ui_xml": str(ui_xml),
            "screenshot": str(screenshot),
        },
        "hashes": {},
        "note": (
            "Ini bukan cookie/token login asli. Android menyimpan data login Opera Mini "
            "di sandbox aplikasi, sehingga tidak dapat dibaca dari Termux/ADB biasa tanpa root "
            "atau mekanisme backup resmi. File ini adalah bukti sesi/login/sync berbasis ADB."
        ),
    }

    for key, path_str in session["files"].items():
        path = Path(path_str)
        if path.exists():
            session["hashes"][key + "_sha256"] = sha256_file(path)

    with open(session_pickle, "wb") as f:
        pickle.dump(session, f)

    with open(session_json, "w", encoding="utf-8") as f:
        json.dump(session, f, indent=2, ensure_ascii=False)

    print(f"session_pickle={session_pickle}")
    print(f"session_json={session_json}")
    print(f"screenshot={screenshot}")
    print(f"ui_xml={ui_xml}")
    print(f"pull_status={pulled.stdout.strip() or pulled.stderr.strip()}")
    print("login_status_inference=" + json.dumps(session["login_status_inference"], ensure_ascii=False))


if __name__ == "__main__":
    main()
