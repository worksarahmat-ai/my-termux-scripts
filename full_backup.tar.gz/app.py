from __future__ import annotations

import asyncio
import json
import os
import platform
import time
import uuid
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

load_dotenv()

BACKEND_TOKEN = os.getenv("BACKEND_TOKEN", "")
AI_CLI_BIN = os.getenv("AI_CLI_BIN", "gemini")

app = FastAPI(
    title="Termux Gemini Backend",
    version="0.2.0",
    description="Backend lokal Termux dengan shell execution, job tracking, error detection, stuck detection, dan device governor.",
)

JOBS: dict[str, dict] = {}
PROCS: dict[str, asyncio.subprocess.Process] = {}


class ShellRequest(BaseModel):
    command: str = Field(..., min_length=1)
    cwd: Optional[str] = None
    timeout_sec: int = Field(default=120, ge=1, le=3600)
    background: bool = False


def now() -> float:
    return time.time()


def require_auth(authorization: Optional[str]) -> None:
    if not BACKEND_TOKEN:
        return

    expected = f"Bearer {BACKEND_TOKEN}"
    if authorization != expected:
        raise HTTPException(status_code=401, detail="Unauthorized")


async def run_cmd(command: list[str], cwd: Optional[str], timeout_sec: int) -> dict:
    proc = await asyncio.create_subprocess_exec(
        *command,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout_sec)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        raise HTTPException(
            status_code=504,
            detail={
                "type": "timeout",
                "message": "Process timeout / possible stuck job",
                "command": command,
            },
        )

    return {
        "stdout": stdout.decode(errors="replace"),
        "stderr": stderr.decode(errors="replace"),
        "exit_code": proc.returncode,
    }


def classify_error(stderr: str, exit_code: int | None) -> dict:
    text = (stderr or "").lower()

    if exit_code == 0:
        return {"class": "none", "severity": "none", "fix": None}

    if "permission denied" in text or exit_code == 126:
        return {
            "class": "permission_denied",
            "severity": "high",
            "fix": "Cek chmod +x, izin folder, atau jalankan termux-setup-storage jika terkait storage Android.",
        }

    if "command not found" in text or exit_code == 127:
        return {
            "class": "command_not_found",
            "severity": "medium",
            "fix": "Install package yang dibutuhkan dengan pkg install <nama-package>.",
        }

    if (
        "network is unreachable" in text
        or "could not resolve host" in text
        or "temporary failure in name resolution" in text
        or "connection timed out" in text
    ):
        return {
            "class": "network_error",
            "severity": "medium",
            "fix": "Cek koneksi internet, DNS, VPN, firewall, atau mode hemat daya Android.",
        }

    if "no space left on device" in text:
        return {
            "class": "disk_full",
            "severity": "high",
            "fix": "Kosongkan storage Termux/Android, hapus cache pip/pkg, atau pindahkan output besar.",
        }

    if "killed" in text or exit_code == 9 or exit_code == -9:
        return {
            "class": "killed_or_android_phantom_process",
            "severity": "high",
            "fix": "Android mungkin membunuh proses. Kurangi beban, pecah job, aktifkan wakelock seperlunya, atau hindari proses CPU tinggi lama.",
        }

    if "syntaxerror" in text:
        return {
            "class": "python_syntax_error",
            "severity": "medium",
            "fix": "Perbaiki sintaks Python pada script atau command.",
        }

    if "modulenotfounderror" in text or "no module named" in text:
        return {
            "class": "python_module_missing",
            "severity": "medium",
            "fix": "Install modul Python yang hilang dengan pip install <module> di virtualenv aktif.",
        }

    if exit_code not in (0, None):
        return {
            "class": "generic_process_error",
            "severity": "medium",
            "fix": "Periksa stderr, dependency, path, dan command.",
        }

    return {"class": "unknown", "severity": "low", "fix": "Periksa log output."}


def detect_stuck(job: dict, threshold_sec: int = 60) -> dict:
    status = job.get("status")
    last_heartbeat = float(job.get("last_heartbeat_at", job.get("started_at", now())))
    idle_sec = now() - last_heartbeat

    if status not in {"running", "background"}:
        return {
            "stuck": False,
            "reason": "job_not_running",
            "idle_sec": round(idle_sec, 3),
            "threshold_sec": threshold_sec,
        }

    if idle_sec > threshold_sec:
        return {
            "stuck": True,
            "reason": "no_stdout_stderr_or_state_change",
            "idle_sec": round(idle_sec, 3),
            "threshold_sec": threshold_sec,
            "suggestion": "Cek /v1/jobs/{job_id}, cancel bila perlu, atau jalankan ulang dengan timeout lebih pendek.",
        }

    return {
        "stuck": False,
        "reason": "heartbeat_ok",
        "idle_sec": round(idle_sec, 3),
        "threshold_sec": threshold_sec,
    }


def append_tail(job: dict, key: str, text: str, limit: int = 20000) -> None:
    old = job.get(key, "")
    new = (old + text)[-limit:]
    job[key] = new
    job["last_heartbeat_at"] = now()
    job["last_event"] = key


async def read_stream(job_id: str, stream: asyncio.StreamReader, key: str) -> None:
    while True:
        chunk = await stream.readline()
        if not chunk:
            break

        job = JOBS.get(job_id)
        if not job:
            break

        append_tail(job, key, chunk.decode(errors="replace"))


async def watch_background_job(job_id: str, proc: asyncio.subprocess.Process) -> None:
    job = JOBS.get(job_id)
    if not job:
        return

    try:
        await asyncio.gather(
            read_stream(job_id, proc.stdout, "stdout_tail"),
            read_stream(job_id, proc.stderr, "stderr_tail"),
        )
        exit_code = await proc.wait()
    except Exception as exc:
        job.update(
            {
                "status": "watcher_error",
                "finished_at": now(),
                "last_heartbeat_at": now(),
                "error": {
                    "class": "watcher_error",
                    "severity": "high",
                    "fix": str(exc),
                },
            }
        )
        PROCS.pop(job_id, None)
        return

    stderr_tail = job.get("stderr_tail", "")

    job.update(
        {
            "status": "finished" if exit_code == 0 else "failed",
            "finished_at": now(),
            "last_heartbeat_at": now(),
            "exit_code": exit_code,
            "error": classify_error(stderr_tail, exit_code),
        }
    )

    PROCS.pop(job_id, None)


async def read_battery() -> dict:
    result = await run_cmd(["bash", "-lc", "termux-battery-status"], None, 10)

    if result["exit_code"] != 0:
        return {
            "ok": False,
            "error": classify_error(result["stderr"], result["exit_code"]),
            **result,
        }

    try:
        return {"ok": True, "data": json.loads(result["stdout"])}
    except json.JSONDecodeError:
        return {
            "ok": False,
            "error": {
                "class": "invalid_json",
                "severity": "medium",
                "fix": "Cek apakah aplikasi Termux:API dan package termux-api sudah benar.",
            },
            **result,
        }


def governor_from_battery(battery: dict) -> dict:
    if not battery.get("ok"):
        return {
            "mode": "unknown",
            "allow_heavy_jobs": False,
            "max_concurrency": 1,
            "reason": "battery_api_unavailable",
        }

    data = battery.get("data", {})
    temp = data.get("temperature")
    percentage = data.get("percentage") or data.get("level")
    plugged = data.get("plugged")
    status = data.get("status")

    mode = "normal"
    allow_heavy = True
    max_concurrency = 2
    reasons = []

    if isinstance(temp, (int, float)):
        if temp >= 45:
            mode = "thermal_protect"
            allow_heavy = False
            max_concurrency = 1
            reasons.append("temperature_ge_45c")
        elif temp >= 40:
            mode = "throttle_light"
            allow_heavy = True
            max_concurrency = 1
            reasons.append("temperature_ge_40c")

    if isinstance(percentage, int):
        if percentage <= 15:
            mode = "battery_protect"
            allow_heavy = False
            max_concurrency = 1
            reasons.append("battery_le_15")
        elif percentage <= 25 and mode == "normal":
            mode = "battery_saver"
            max_concurrency = 1
            reasons.append("battery_le_25")

    return {
        "mode": mode,
        "allow_heavy_jobs": allow_heavy,
        "max_concurrency": max_concurrency,
        "temperature_c": temp,
        "battery_percent": percentage,
        "plugged": plugged,
        "battery_status": status,
        "reasons": reasons or ["healthy"],
    }


@app.get("/healthz")
async def healthz():
    return {
        "ok": True,
        "version": "0.2.0",
        "time": int(now()),
    }


@app.get("/v1/device/battery")
async def battery(authorization: Optional[str] = Header(default=None)):
    require_auth(authorization)
    return await read_battery()


@app.get("/v1/device/governor")
async def device_governor(authorization: Optional[str] = Header(default=None)):
    require_auth(authorization)
    battery = await read_battery()
    return {
        "ok": True,
        "battery": battery,
        "governor": governor_from_battery(battery),
    }


@app.get("/v1/device/network")
async def network(authorization: Optional[str] = Header(default=None)):
    require_auth(authorization)

    result = await run_cmd(
        ["bash", "-lc", "ping -c 1 -W 3 8.8.8.8 >/dev/null 2>&1 && echo online || echo offline"],
        None,
        8,
    )

    return {
        "ok": True,
        "status": result["stdout"].strip(),
        "raw": result,
    }


@app.get("/v1/device/metadata")
async def metadata(authorization: Optional[str] = Header(default=None)):
    require_auth(authorization)

    uname = await run_cmd(["bash", "-lc", "uname -a"], None, 10)
    termux_info = await run_cmd(["bash", "-lc", "termux-info 2>/dev/null | head -80"], None, 10)

    return {
        "ok": True,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cwd": os.getcwd(),
        "ai_cli_bin": AI_CLI_BIN,
        "uname": uname["stdout"].strip(),
        "termux_info": termux_info["stdout"],
    }


@app.post("/v1/execute/shell")
async def execute_shell(
    req: ShellRequest,
    authorization: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    job_id = str(uuid.uuid4())
    started_at = now()

    JOBS[job_id] = {
        "job_id": job_id,
        "lane": "local_shell",
        "status": "running",
        "mode": "background" if req.background else "foreground",
        "command": req.command,
        "cwd": req.cwd,
        "started_at": started_at,
        "last_heartbeat_at": started_at,
        "last_event": "created",
        "stdout_tail": "",
        "stderr_tail": "",
    }

    if req.background:
        proc = await asyncio.create_subprocess_exec(
            "bash",
            "-lc",
            req.command,
            cwd=req.cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        PROCS[job_id] = proc
        JOBS[job_id].update(
            {
                "pid": proc.pid,
                "status": "background",
                "last_heartbeat_at": now(),
                "last_event": "process_started",
            }
        )

        asyncio.create_task(watch_background_job(job_id, proc))
        return JOBS[job_id]

    result = await run_cmd(["bash", "-lc", req.command], req.cwd, req.timeout_sec)
    error = classify_error(result["stderr"], result["exit_code"])

    JOBS[job_id].update(
        {
            "status": "finished" if result["exit_code"] == 0 else "failed",
            "finished_at": now(),
            "last_heartbeat_at": now(),
            "last_event": "process_finished",
            "exit_code": result["exit_code"],
            "stdout_tail": result["stdout"][-20000:],
            "stderr_tail": result["stderr"][-20000:],
            "error": error,
        }
    )

    return {
        **JOBS[job_id],
        "stdout": result["stdout"],
        "stderr": result["stderr"],
    }


@app.get("/v1/jobs/{job_id}")
async def get_job(
    job_id: str,
    authorization: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    return {
        **job,
        "stuck_report": detect_stuck(job),
    }


@app.post("/v1/jobs/{job_id}/cancel")
async def cancel_job(
    job_id: str,
    authorization: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    proc = PROCS.get(job_id)
    if not proc:
        job["status"] = "cancel_unavailable"
        job["last_heartbeat_at"] = now()
        return {
            "ok": False,
            "message": "No active process found for this job.",
            "job": job,
        }

    proc.kill()
    await proc.wait()

    job.update(
        {
            "status": "cancelled",
            "finished_at": now(),
            "last_heartbeat_at": now(),
            "last_event": "cancelled",
            "exit_code": -9,
            "error": classify_error(job.get("stderr_tail", ""), -9),
        }
    )

    PROCS.pop(job_id, None)

    return {
        "ok": True,
        "job": job,
    }


@app.get("/v1/runtime/stuck/{job_id}")
async def runtime_stuck(
    job_id: str,
    authorization: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    return {
        "ok": True,
        "job_id": job_id,
        "report": detect_stuck(job),
    }


@app.get("/v1/runtime/errors/{job_id}")
async def runtime_errors(
    job_id: str,
    authorization: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    stderr_tail = job.get("stderr_tail", "")
    exit_code = job.get("exit_code")

    return {
        "ok": True,
        "job_id": job_id,
        "status": job.get("status"),
        "exit_code": exit_code,
        "error": job.get("error") or classify_error(stderr_tail, exit_code),
        "stderr_tail": stderr_tail,
        "stdout_tail": job.get("stdout_tail", ""),
    }

class ModelRequest(BaseModel):
    prompt: str = Field(..., min_length=1)
    model: Optional[str] = None
    google_search: bool = True
    code_execution: bool = True
    timeout_sec: int = Field(default=120, ge=1, le=600)


class PromptInspectRequest(BaseModel):
    prompt: str = Field(..., min_length=1)


def inspect_prompt_policy(prompt: str) -> dict:
    text = prompt.lower()
    danger = []
    confirm = []

    deny_patterns = [
        "rm -rf /",
        ":(){ :|:& };:",
        "mkfs.",
        "dd if=",
        "wipe",
        "format disk",
    ]

    confirm_patterns = [
        "rm -rf",
        "chmod 777",
        "curl ",
        "wget ",
        "pip install",
        "pkg install",
        "git clone",
        "ssh ",
        "token",
        "api key",
        "password",
    ]

    for pattern in deny_patterns:
        if pattern in text:
            danger.append(pattern)

    for pattern in confirm_patterns:
        if pattern in text:
            confirm.append(pattern)

    if danger:
        return {
            "decision": "deny",
            "risk": "critical",
            "matched": danger,
            "reason": "Prompt mengandung pola command destruktif.",
        }

    if confirm:
        return {
            "decision": "confirm",
            "risk": "medium",
            "matched": confirm,
            "reason": "Prompt mengandung aksi sensitif. Minta konfirmasi eksplisit dulu.",
        }

    return {
        "decision": "allow",
        "risk": "low",
        "matched": [],
        "reason": "Tidak ada pola berisiko tinggi yang terdeteksi.",
    }


def extract_gemini_parts(response) -> dict:
    out = {
        "text": getattr(response, "text", None),
        "parts": [],
        "grounding": None,
    }

    try:
        candidate = response.candidates[0]
    except Exception:
        return out

    try:
        grounding = getattr(candidate, "grounding_metadata", None)
        if grounding is not None:
            chunks = getattr(grounding, "grounding_chunks", None) or []
            queries = getattr(grounding, "web_search_queries", None) or []

            out["grounding"] = {
                "web_search_queries": list(queries),
                "sources": [
                    {
                        "title": getattr(getattr(chunk, "web", None), "title", None),
                        "uri": getattr(getattr(chunk, "web", None), "uri", None),
                    }
                    for chunk in chunks
                ],
            }
    except Exception:
        out["grounding"] = None

    try:
        for part in candidate.content.parts:
            item = {}

            if getattr(part, "text", None) is not None:
                item["type"] = "text"
                item["text"] = part.text

            if getattr(part, "executable_code", None) is not None:
                item["type"] = "executable_code"
                item["language"] = getattr(part.executable_code, "language", None)
                item["code"] = getattr(part.executable_code, "code", None)

            if getattr(part, "code_execution_result", None) is not None:
                item["type"] = "code_execution_result"
                item["outcome"] = getattr(part.code_execution_result, "outcome", None)
                item["output"] = getattr(part.code_execution_result, "output", None)

            if item:
                out["parts"].append(item)
    except Exception:
        pass

    return out


def run_gemini_sync(req: ModelRequest) -> dict:
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        return {
            "ok": False,
            "error": {
                "class": "gemini_api_key_missing",
                "severity": "high",
                "fix": "Isi GEMINI_API_KEY di file .env lalu restart uvicorn.",
            },
        }

    from google import genai
    from google.genai import types

    client = genai.Client(api_key=api_key)

    tools = []

    if req.google_search:
        tools.append(types.Tool(google_search=types.GoogleSearch()))

    if req.code_execution:
        tools.append(types.Tool(code_execution=types.ToolCodeExecution))

    model = req.model or os.getenv("GEMINI_MODEL", "gemini-2.5-flash-preview-09-2025")

    response = client.models.generate_content(
        model=model,
        contents=req.prompt,
        config=types.GenerateContentConfig(
            tools=tools
        ),
    )

    return {
        "ok": True,
        "model": model,
        "google_search": req.google_search,
        "code_execution": req.code_execution,
        "result": extract_gemini_parts(response),
    }


@app.post("/v1/execute/model")
async def execute_model(
    req: ModelRequest,
    authorization: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    policy = inspect_prompt_policy(req.prompt)
    if policy["decision"] == "deny":
        return {
            "ok": False,
            "blocked": True,
            "policy": policy,
        }

    job_id = str(uuid.uuid4())
    started_at = now()

    JOBS[job_id] = {
        "job_id": job_id,
        "lane": "gemini_model",
        "status": "running",
        "mode": "foreground",
        "started_at": started_at,
        "last_heartbeat_at": started_at,
        "last_event": "gemini_request_started",
        "policy": policy,
    }

    try:
        result = await asyncio.wait_for(
            asyncio.to_thread(run_gemini_sync, req),
            timeout=req.timeout_sec,
        )
    except asyncio.TimeoutError:
        JOBS[job_id].update(
            {
                "status": "failed",
                "finished_at": now(),
                "last_heartbeat_at": now(),
                "last_event": "gemini_timeout",
                "error": {
                    "class": "gemini_timeout",
                    "severity": "medium",
                    "fix": "Coba prompt lebih pendek atau naikkan timeout_sec.",
                },
            }
        )
        return {**JOBS[job_id], "ok": False}

    except Exception as exc:
        JOBS[job_id].update(
            {
                "status": "failed",
                "finished_at": now(),
                "last_heartbeat_at": now(),
                "last_event": "gemini_error",
                "error": {
                    "class": "gemini_api_error",
                    "severity": "high",
                    "fix": str(exc),
                },
            }
        )
        return {**JOBS[job_id], "ok": False}

    JOBS[job_id].update(
        {
            "status": "finished" if result.get("ok") else "failed",
            "finished_at": now(),
            "last_heartbeat_at": now(),
            "last_event": "gemini_request_finished",
            "error": result.get("error") or {"class": "none", "severity": "none", "fix": None},
        }
    )

    return {
        **JOBS[job_id],
        **result,
    }


@app.post("/v1/search/google")
async def search_google(
    req: ModelRequest,
    authorization: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    req.google_search = True
    req.code_execution = False

    return await execute_model(req, authorization)


@app.post("/v1/prompt/inspect")
async def prompt_inspect(
    req: PromptInspectRequest,
    authorization: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    return {
        "ok": True,
        "policy": inspect_prompt_policy(req.prompt),
    }

# =========================
# v0.4 HTML AUTOPILOT ADAPTER
# =========================

import base64
from pathlib import Path
import requests
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

DEFAULT_AUTOPILOT_SCHEMA = {
    "type": "object",
    "properties": {
        "ringkasan": {
            "type": "string",
            "description": "Ringkasan jawaban komprehensif dalam bahasa Indonesia",
        },
        "poin_penting": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Daftar poin utama atau butir informasi penting",
        },
        "kategori": {
            "type": "string",
            "description": "Kategori dari topik yang dibahas",
        },
    },
    "required": ["ringkasan", "poin_penting", "kategori"],
}

try:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )
except RuntimeError:
    # Kalau middleware sudah pernah ditambahkan, abaikan.
    pass


PUBLIC_DIR = Path("public")
PUBLIC_DIR.mkdir(exist_ok=True)


try:
    app.mount("/static", StaticFiles(directory=str(PUBLIC_DIR)), name="static")
except RuntimeError:
    pass


class AutopilotMedia(BaseModel):
    mimeType: str
    data: str
    type: Optional[str] = None
    displayUrl: Optional[str] = None


class AutopilotHistoryItem(BaseModel):
    role: str
    text: Optional[str] = None


class AutopilotChatRequest(BaseModel):
    text: str = ""
    intent: Optional[str] = None
    media: Optional[AutopilotMedia] = None
    schema_: Optional[dict] = Field(default=None, alias="schema")
    history: list[AutopilotHistoryItem] = Field(default_factory=list)
    timeout_sec: int = Field(default=180, ge=1, le=600)


class TTSRequest(BaseModel):
    text: str = Field(..., min_length=1)
    voice: Optional[str] = None
    timeout_sec: int = Field(default=120, ge=1, le=300)


def classify_backend_intent(text: str, media: Optional[AutopilotMedia]) -> str:
    query = (text or "").lower()

    if media and media.type == "video":
        return "VIDEO_ANALYSIS"

    if media and media.type == "image":
        video_words = [
            "animasi",
            "video",
            "animasikan",
            "cinematic",
            "animate",
            "bikin video",
            "jadikan video",
            "gerakkan",
        ]
        if any(w in query for w in video_words):
            return "VIDEO_ANIMATION"
        return "IMAGE_ANALYSIS"

    math_code_words = [
        "hitung",
        "matematika",
        "coding",
        "buat program",
        "algoritma",
        "python",
        "javascript",
        "html",
        "css",
        "rumus",
        "integral",
        "turunan",
        "aljabar",
        "bikin kode",
        "debug",
        "error",
    ]

    search_words = [
        "berita",
        "terbaru",
        "hari ini",
        "sekarang",
        "cuaca",
        "update",
        "grounding",
        "search",
        "pencarian",
        "siapa pemenang",
        "skor",
        "saham",
        "harga",
    ]

    schema_words = [
        "format",
        "json",
        "skema",
        "tabel json",
        "data terstruktur",
        "kategori",
        "ringkasan",
        "list",
        "daftar",
    ]

    if any(w in query for w in search_words):
        return "GOOGLE_SEARCH"

    if any(w in query for w in math_code_words):
        return "DEEP_THINKING"

    if any(w in query for w in schema_words):
        return "STRUCTURED_OUTPUT"

    return "STANDARD_CONVERSATION"


def build_gemini_rest_payload(req: AutopilotChatRequest) -> dict:
    intent = req.intent or classify_backend_intent(req.text, req.media)

    system_text = (
        "Kamu adalah Gemini Advanced Autopilot berbasis backend lokal Termux. "
        "Jawab dalam bahasa Indonesia yang jelas, ringkas, dan teknis bila diperlukan. "
        "Jika ada gambar, lakukan analisis visual mendalam. "
        "Jika ada video, ringkas konten, objek, adegan, dan momen penting. "
        "Jika mode JSON aktif, patuhi schema yang diberikan."
    )

    contents = []

    for item in req.history[-10:]:
        if not item.text:
            continue
        role = "model" if item.role == "model" else "user"
        contents.append(
            {
                "role": role,
                "parts": [{"text": item.text}],
            }
        )

    current_parts = []

    if req.text.strip():
        current_parts.append({"text": req.text.strip()})
    elif not req.media:
        current_parts.append({"text": "Halo"})

    if req.media:
        current_parts.append(
            {
                "inlineData": {
                    "mimeType": req.media.mimeType,
                    "data": req.media.data,
                }
            }
        )

    contents.append(
        {
            "role": "user",
            "parts": current_parts,
        }
    )

    payload = {
        "contents": contents,
        "systemInstruction": {
            "parts": [{"text": system_text}],
        },
    }

    tools = []
    generation_config = {}

    if intent == "GOOGLE_SEARCH":
        tools.append({"google_search": {}})

    if intent == "DEEP_THINKING":
        tools.append({"code_execution": {}})
        generation_config["thinkingConfig"] = {"thinkingBudget": 2048}

    if intent == "STRUCTURED_OUTPUT":
        generation_config["responseMimeType"] = "application/json"
        generation_config["responseSchema"] = req.schema_ or DEFAULT_AUTOPILOT_SCHEMA

    if intent in {"IMAGE_ANALYSIS", "VIDEO_ANALYSIS"}:
        generation_config["thinkingConfig"] = {"thinkingBudget": 1024}

    if tools:
        payload["tools"] = tools

    if generation_config:
        payload["generationConfig"] = generation_config

    return {
        "intent": intent,
        "payload": payload,
    }


def parse_gemini_rest_response(data: dict) -> dict:
    candidate = (data.get("candidates") or [{}])[0]
    content = candidate.get("content") or {}
    parts = content.get("parts") or []

    thought_text = ""
    reply_text = ""
    executable_code = []
    code_results = []

    for part in parts:
        if part.get("thought"):
            thought_text += part.get("text", "")

        elif "text" in part:
            reply_text += part.get("text", "")

        if "executableCode" in part:
            executable_code.append(part["executableCode"])

        if "codeExecutionResult" in part:
            code_results.append(part["codeExecutionResult"])

    if not reply_text and parts:
        reply_text = parts[0].get("text", "")

    grounding = candidate.get("groundingMetadata") or {}
    sources = []

    for chunk in grounding.get("groundingChunks", []) or []:
        web = chunk.get("web") or {}
        if web.get("uri"):
            sources.append(
                {
                    "uri": web.get("uri"),
                    "title": web.get("title") or "Sumber Google",
                }
            )

    for item in grounding.get("groundingAttributions", []) or []:
        web = item.get("web") or {}
        if web.get("uri"):
            sources.append(
                {
                    "uri": web.get("uri"),
                    "title": web.get("title") or "Sumber Google",
                }
            )

    # Deduplicate sources
    seen = set()
    clean_sources = []
    for s in sources:
        uri = s.get("uri")
        if uri and uri not in seen:
            seen.add(uri)
            clean_sources.append(s)

    return {
        "text": reply_text,
        "thought": thought_text or None,
        "sources": clean_sources,
        "executable_code": executable_code,
        "code_results": code_results,
        "raw_finish_reason": candidate.get("finishReason"),
    }


def call_gemini_rest(req: AutopilotChatRequest) -> dict:
    api_key = os.getenv("GEMINI_API_KEY", "").strip()

    if not api_key:
        return {
            "ok": False,
            "error": {
                "class": "gemini_api_key_missing",
                "severity": "high",
                "fix": "Isi GEMINI_API_KEY di .env lalu restart uvicorn.",
            },
        }

    built = build_gemini_rest_payload(req)
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash-preview-09-2025").strip()

    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"{model}:generateContent?key={api_key}"
    )

    response = requests.post(
        url,
        headers={"Content-Type": "application/json"},
        json=built["payload"],
        timeout=req.timeout_sec,
    )

    if response.status_code >= 400:
        return {
            "ok": False,
            "intent": built["intent"],
            "model": model,
            "error": {
                "class": "gemini_http_error",
                "severity": "high",
                "status_code": response.status_code,
                "fix": response.text[:4000],
            },
        }

    data = response.json()
    parsed = parse_gemini_rest_response(data)

    return {
        "ok": True,
        "intent": built["intent"],
        "model": model,
        **parsed,
    }


@app.get("/")
async def frontend_index():
    index_file = PUBLIC_DIR / "index.html"
    if not index_file.exists():
        return {
            "ok": False,
            "message": "Simpan HTML kamu ke public/index.html lalu buka http://127.0.0.1:8765/",
        }

    return FileResponse(str(index_file))


@app.get("/v1/frontend/config")
async def frontend_config():
    return {
        "ok": True,
        "backend": "Termux Gemini Backend",
        "version": "0.4.0",
        "model": os.getenv("GEMINI_MODEL", "gemini-2.5-flash-preview-09-2025"),
        "features": {
            "google_search": True,
            "code_execution": True,
            "image_analysis": True,
            "video_analysis": True,
            "structured_json": True,
            "tts_proxy": True,
            "shell_execution": True,
            "device_governor": True,
        },
    }


@app.post("/v1/autopilot/chat")
async def autopilot_chat(
    req: AutopilotChatRequest,
    authorization: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    policy = inspect_prompt_policy(req.text)
    if policy["decision"] == "deny":
        return {
            "ok": False,
            "blocked": True,
            "policy": policy,
            "text": "Permintaan diblokir karena mengandung pola aksi destruktif.",
            "sources": [],
            "thought": None,
        }

    job_id = str(uuid.uuid4())
    started_at = now()
    intent = req.intent or classify_backend_intent(req.text, req.media)

    JOBS[job_id] = {
        "job_id": job_id,
        "lane": "autopilot_chat",
        "status": "running",
        "intent": intent,
        "started_at": started_at,
        "last_heartbeat_at": started_at,
        "last_event": "autopilot_started",
        "policy": policy,
    }

    try:
        result = await asyncio.wait_for(
            asyncio.to_thread(call_gemini_rest, req),
            timeout=req.timeout_sec + 5,
        )
    except asyncio.TimeoutError:
        JOBS[job_id].update(
            {
                "status": "failed",
                "finished_at": now(),
                "last_heartbeat_at": now(),
                "last_event": "autopilot_timeout",
                "error": {
                    "class": "autopilot_timeout",
                    "severity": "medium",
                    "fix": "Naikkan timeout_sec atau pendekkan prompt/media.",
                },
            }
        )
        return {
            **JOBS[job_id],
            "ok": False,
            "text": "Backend timeout saat menunggu Gemini.",
            "sources": [],
            "thought": None,
        }

    except Exception as exc:
        JOBS[job_id].update(
            {
                "status": "failed",
                "finished_at": now(),
                "last_heartbeat_at": now(),
                "last_event": "autopilot_exception",
                "error": {
                    "class": "autopilot_exception",
                    "severity": "high",
                    "fix": str(exc),
                },
            }
        )
        return {
            **JOBS[job_id],
            "ok": False,
            "text": f"Backend error: {exc}",
            "sources": [],
            "thought": None,
        }

    JOBS[job_id].update(
        {
            "status": "finished" if result.get("ok") else "failed",
            "finished_at": now(),
            "last_heartbeat_at": now(),
            "last_event": "autopilot_finished",
            "error": result.get("error") or {"class": "none", "severity": "none", "fix": None},
        }
    )

    return {
        **JOBS[job_id],
        **result,
    }


@app.post("/v1/tts")
async def tts_proxy(
    req: TTSRequest,
    authorization: Optional[str] = Header(default=None),
):
    require_auth(authorization)

    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        return {
            "ok": False,
            "error": {
                "class": "gemini_api_key_missing",
                "severity": "high",
                "fix": "Isi GEMINI_API_KEY di .env lalu restart uvicorn.",
            },
        }

    model = os.getenv("GEMINI_TTS_MODEL", "gemini-2.5-flash-preview-tts").strip()
    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"{model}:generateContent?key={api_key}"
    )

    payload = {
        "contents": [{"parts": [{"text": req.text}]}],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
        },
    }

    try:
        response = requests.post(
            url,
            headers={"Content-Type": "application/json"},
            json=payload,
            timeout=req.timeout_sec,
        )
    except Exception as exc:
        return {
            "ok": False,
            "error": {
                "class": "tts_request_failed",
                "severity": "medium",
                "fix": str(exc),
            },
        }

    if response.status_code >= 400:
        return {
            "ok": False,
            "error": {
                "class": "tts_http_error",
                "severity": "medium",
                "status_code": response.status_code,
                "fix": response.text[:4000],
            },
        }

    data = response.json()
    part = (
        (data.get("candidates") or [{}])[0]
        .get("content", {})
        .get("parts", [{}])[0]
    )
    inline = part.get("inlineData") or {}

    return {
        "ok": True,
        "mimeType": inline.get("mimeType", "audio/wav"),
        "data": inline.get("data"),
    }
