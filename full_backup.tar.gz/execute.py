  
import http.server
import socketserver
import json
import subprocess
from urllib.parse import urlparse, parse_qs

PORT = 8001  # Gunakan port berbeda untuk API
DEFAULT_TIMEOUT = 66 # Meningkatkan batas waktu eksekusi dari 5 detik menjadi 66 detik.

class CommandExecutor(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        # Hanya menangani permintaan ke /api/execute
        if self.path == '/api/execute':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)

            try:
                data = json.loads(post_data)
                command = data.get('command')

                if not command:
                    self.send_error_response("Perintah tidak ditemukan dalam payload.", 400)
                    return

                # === LOGIKA EKSEKUSI PERINTAH DI SHELL TERMUX ===
                # Menggunakan shell=True karena ini dijalankan di Termux yang aman
                # stderr digabungkan ke stdout (stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                result = subprocess.run(
                    command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=DEFAULT_TIMEOUT, # Menggunakan nilai 66 detik
                    encoding='utf-8'
                )

                # Siapkan Respons JSON
                response = {
                    "command": command,
                    "output": result.stdout,
                    "return_code": result.returncode
                }

                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*') # Untuk CORS
                self.end_headers()
                self.wfile.write(json.dumps(response, ensure_ascii=False).encode('utf-8'))

            except subprocess.TimeoutExpired:
                # Memberikan pesan error yang jelas termasuk nilai timeout baru
                self.send_error_response(f"Perintah '{command}' melebihi batas waktu ({DEFAULT_TIMEOUT} detik).", 500)
            except Exception as e:
                self.send_error_response(f"Kesalahan internal server: {e}", 500)

        else:
            self.send_error_response("Endpoint tidak ditemukan.", 404)

    def do_OPTIONS(self):
        # Menangani permintaan CORS preflight
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def send_error_response(self, message, code):
        self.send_response(code)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        error_response = json.dumps({"error": message, "code": code})
        self.wfile.write(error_response.encode('utf-8'))


# Menjalankan server API
with socketserver.TCPServer(("", PORT), CommandExecutor) as httpd:
    print(f"Server Eksekutor Perintah Termux AKTIF di Port {PORT}")
    httpd.serve_forever()




