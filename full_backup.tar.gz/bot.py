

import sys
import os
import time
from unittest.mock import MagicMock

# --- BAGIAN 1: SELF-HEALING SYSTEM (PERBAIKAN MANDIRI) ---
# Sebelum load library, kita pastikan folder sistem ada
# Ini mengatasi error: FileNotFoundError: [Errno 2] /root/.config/g4f/cookies
try:
    user_home = os.path.expanduser("~")
    config_path = os.path.join(user_home, ".config", "g4f", "cookies")
    os.makedirs(config_path, exist_ok=True)
    # Buat file dummy agar driver tidak bingung
    with open(os.path.join(config_path, "browsers.json"), "a") as f:
        pass
except Exception as e:
    print(f"[Warning] Gagal membuat folder config: {e}")

# --- BAGIAN 2: MOCKING DRIVER BERAT (OPTIMALISASI) ---
# Kita matikan driver browser asli karena berat di Termux & bikin crash
sys.modules["openpyxl"] = MagicMock()
sys.modules["markitdown"] = MagicMock()
sys.modules["scipy"] = MagicMock()
sys.modules["webdriver"] = MagicMock() 
sys.modules["undetected_chromedriver"] = MagicMock()
# sys.modules["g4f.Provider.Copilot"] = MagicMock() # Opsional: Matikan Copilot jika masih error

import g4f

# Konfigurasi Tampilan
sys.stdout.reconfigure(encoding='utf-8')
os.environ["ORT_LOGGING_LEVEL"] = "3" 

def main():
    print("\n" + "="*55)
    print(f"   NEXUS AI ULTIMATE (Fixed & Persistent)")
    print(f"   Core: G4F v{g4f.version} | Path: {config_path}")
    print("   Status: Login System Ready | Mode: Logic & Coding")
    print("="*55)

    # System Prompt untuk Logika Tinggi
    messages = [
        {"role": "system", "content": "Anda adalah Nexus, AI asisten dengan kemampuan logika tingkat lanjut (Chain of Thought). Analisis setiap pertanyaan matematika atau coding secara mendalam, langkah demi langkah. Jika ada error, jelaskan penyebab akarnya."}
    ]

    while True:
        try:
            user_input = input("\n[User]: ")
            
            if user_input.lower() in ["exit", "keluar", "stop"]:
                print(">> Shutting down Nexus System...")
                break
            
            if not user_input.strip(): continue

            messages.append({"role": "user", "content": user_input})
            print(">> Nexus berpikir...", end="\r")

            # --- INTELLIGENT ROUTING (Jalur Cerdas) ---
            response = None
            try:
                # Prioritas 1: Coba GPT-4o (Model Logika Tertinggi)
                response = g4f.ChatCompletion.create(
                    model="gpt-4o",
                    messages=messages,
                    stream=False
                )
            except Exception as e:
                # Jika gagal (biasanya karena auth/limit), fallback ke model lain
                print(f"\n[Info] GPT-4o sibuk/limit ({e}). Mencoba jalur alternatif...")
                try:
                    # Prioritas 2: Blackbox (Sangat bagus untuk Coding & Stabil)
                    response = g4f.ChatCompletion.create(
                        model="gpt-4",
                        provider=g4f.Provider.Blackbox,
                        messages=messages,
                        stream=False
                    )
                except Exception as e2:
                    print(f"[Error] Semua jalur sibuk: {e2}")

            # Bersihkan baris status
            print(" " * 50, end="\r")

            if response and isinstance(response, str) and len(response) > 0:
                print(f"[Nexus]: {response}")
                messages.append({"role": "assistant", "content": response})
            else:
                print("[!] Gagal mendapatkan respon. Silakan coba tanya lagi.")

        except KeyboardInterrupt:
            print("\nForce Close.")
            break
        except Exception as e:
            print(f"\n[Critical System Error]: {e}")
            # Trik: Jika folder error lagi, coba buat ulang
            if "FileNotFound" in str(e):
                 os.makedirs(config_path, exist_ok=True)

if __name__ == "__main__":
    main()


