#!/data/data/com.termux/files/usr/bin/sh
HOME_DIR="/data/data/com.termux/files/home"
CONF_FILE="$HOME_DIR/backend-data/adb-autoconnect.conf"
LOG_FILE="$HOME_DIR/backend-data/backend.log"
ADB_LOG_FILE="$HOME_DIR/backend-data/adb-autoconnect.log"

cd "$HOME_DIR" || exit 1
mkdir -p "$HOME_DIR/backend-data"

run_detached() {
  target_log="$1"
  shift
  if command -v setsid >/dev/null 2>&1; then
    setsid "$@" >> "$target_log" 2>&1 &
  else
    nohup "$@" >> "$target_log" 2>&1 &
  fi
}

if [ -f "$CONF_FILE" ]; then
  . "$CONF_FILE"
fi

if [ -z "${ADB_SERVER_SOCKET:-}" ]; then
  unset ADB_SERVER_SOCKET
else
  export ADB_SERVER_SOCKET
fi

export ADB_HOST="${ADB_HOST:-127.0.0.1}"
export ADB_PORT="${ADB_PORT:-5555}"
if [ -n "${ADB_SERIAL:-}" ]; then
  export ADB_SERIAL
fi
export RISH_PATH="${RISH_PATH:-$HOME_DIR/rish}"
export RISH_APPLICATION_ID="${RISH_APPLICATION_ID:-com.termux}"
export SHIZUKU_START_SCRIPT="${SHIZUKU_START_SCRIPT:-/storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh}"

if command -v termux-wake-lock >/dev/null 2>&1; then
  termux-wake-lock >/dev/null 2>&1
fi

if [ "${ADB_WATCHDOG:-1}" != "0" ]; then
  if ! pgrep -f "$HOME_DIR/bin/adb-watchdog.sh" >/dev/null 2>&1; then
    run_detached "$ADB_LOG_FILE" "$HOME_DIR/bin/adb-watchdog.sh"
  fi
else
  run_detached "$ADB_LOG_FILE" "$HOME_DIR/bin/adb-autoconnect.sh" once
fi

if ! pgrep -f "node .*server.js" >/dev/null 2>&1; then
  run_detached "$LOG_FILE" node server.js
fi
