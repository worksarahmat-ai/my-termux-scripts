#!/usr/bin/env python3
import argparse
import json
import os
import pathlib
import shutil
import sqlite3
import subprocess
import sys
import time

HOME = pathlib.Path.home()
DEFAULT_PROFILE = "google_developer"
DEFAULT_DISPLAY = ":1"
DEFAULT_OUTDIR = HOME / "live_login_reader"
FIREFOX_ROOT = HOME / ".config" / "mozilla" / "firefox"


def have(command):
    return shutil.which(command) is not None


def run(command, env=None, timeout=20, check=False):
    return subprocess.run(
        command,
        env=env,
        timeout=timeout,
        check=check,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def now_stamp():
    return time.strftime("%Y%m%d-%H%M%S")


def display_env(display):
    env = os.environ.copy()
    env["DISPLAY"] = display
    return env


def firefox_profiles():
    profiles_ini = FIREFOX_ROOT / "profiles.ini"
    profiles = {}

    if not profiles_ini.exists():
        return profiles

    current = None
    for raw_line in profiles_ini.read_text(errors="replace").splitlines():
        line = raw_line.strip()
        if line.startswith("[") and line.endswith("]"):
            current = line.strip("[]")
            profiles[current] = {}
        elif current and "=" in line:
            key, value = line.split("=", 1)
            profiles[current][key] = value

    result = {}
    for data in profiles.values():
        name = data.get("Name")
        profile_path = data.get("Path")
        if name and profile_path:
            result[name] = FIREFOX_ROOT / profile_path
    return result


def get_profile_path(profile):
    profiles = firefox_profiles()
    return profiles.get(profile)


def launch_firefox(profile, url, display):
    if not url:
        return None

    env = display_env(display)
    process = subprocess.Popen(
        ["firefox", "-P", profile, url],
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return process.pid


def window_snapshot(display):
    env = display_env(display)
    info = {
        "active_window_id": None,
        "active_window_name": None,
        "windows": [],
    }

    if have("xdotool"):
        active = run(["xdotool", "getactivewindow"], env=env, timeout=5)
        if active.returncode == 0:
            info["active_window_id"] = active.stdout.strip()
            name = run(["xdotool", "getwindowname", info["active_window_id"]], env=env, timeout=5)
            if name.returncode == 0:
                info["active_window_name"] = name.stdout.strip()

    if have("wmctrl"):
        windows = run(["wmctrl", "-l"], env=env, timeout=5)
        if windows.returncode == 0:
            info["windows"] = [line for line in windows.stdout.splitlines() if line.strip()]

    return info


def capture_screenshot(display, outdir):
    outdir.mkdir(parents=True, exist_ok=True)
    png_path = outdir / f"screenshot-{now_stamp()}.png"

    if not have("import"):
        raise RuntimeError("Tool 'import' tidak ditemukan. Install ImageMagick dulu.")

    env = display_env(display)
    result = run(["import", "-window", "root", str(png_path)], env=env, timeout=20)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "Gagal mengambil screenshot.")

    return png_path


def ocr_image(image_path, outdir):
    if not have("tesseract"):
        return {
            "available": False,
            "text_path": None,
            "text_preview": "OCR belum tersedia. Install dengan: pkg install tesseract",
        }

    text_base = outdir / image_path.stem
    result = run(["tesseract", str(image_path), str(text_base)], timeout=60)
    text_path = text_base.with_suffix(".txt")
    if result.returncode != 0:
        return {
            "available": True,
            "text_path": str(text_path),
            "text_preview": result.stderr.strip() or "OCR gagal.",
        }

    text = text_path.read_text(errors="replace") if text_path.exists() else ""
    return {
        "available": True,
        "text_path": str(text_path),
        "text_preview": text[:4000],
    }


def cookie_markers(profile_path):
    db = profile_path / "cookies.sqlite" if profile_path else None
    if not db or not db.exists():
        return {"available": False, "db": str(db) if db else None, "hosts": []}

    patterns = [
        "%developer.android.com%",
        "%.android.com%",
        "%developers.google.com%",
        "%google.com%",
        "%accounts.google.com%",
    ]

    hosts = []
    conn = sqlite3.connect(f"file:{db}?mode=ro&immutable=1", uri=True)
    cur = conn.cursor()
    for pattern in patterns:
        cur.execute(
            """
            select host, count(*), group_concat(distinct name)
            from moz_cookies
            where host like ?
            group by host
            order by host
            """,
            (pattern,),
        )
        for host, count, names in cur.fetchall():
            hosts.append({
                "host": host,
                "count": count,
                "cookie_names": (names or "").split(",")[:20],
            })
    conn.close()

    unique = {}
    for item in hosts:
        unique[item["host"]] = item

    return {
        "available": True,
        "db": str(db),
        "hosts": list(unique.values()),
    }


def one_scan(args):
    outdir = pathlib.Path(args.outdir).expanduser()
    profile_path = get_profile_path(args.profile)

    launched_pid = launch_firefox(args.profile, args.url, args.display)
    if launched_pid:
        time.sleep(args.wait)

    screenshot = capture_screenshot(args.display, outdir)
    ocr = ocr_image(screenshot, outdir) if args.ocr else {
        "available": False,
        "text_path": None,
        "text_preview": "OCR dilewati. Jalankan dengan --ocr untuk mencoba OCR.",
    }

    report = {
        "timestamp": time.time(),
        "display": args.display,
        "profile": args.profile,
        "profile_path": str(profile_path) if profile_path else None,
        "launched_pid": launched_pid,
        "url_requested": args.url,
        "screenshot": str(screenshot),
        "window": window_snapshot(args.display),
        "cookies": cookie_markers(profile_path),
        "ocr": ocr,
    }

    report_path = outdir / f"report-{now_stamp()}.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print("OK")
    print(f"screenshot={screenshot}")
    print(f"report={report_path}")
    if ocr.get("text_path"):
        print(f"ocr_text={ocr['text_path']}")
    print(f"active_window={report['window'].get('active_window_name')}")
    print("cookie_hosts=" + ",".join(item["host"] for item in report["cookies"].get("hosts", [])[:20]))


def main():
    parser = argparse.ArgumentParser(
        description="Live reader untuk sesi login Firefox di Termux X11."
    )
    parser.add_argument("--display", default=DEFAULT_DISPLAY)
    parser.add_argument("--profile", default=DEFAULT_PROFILE)
    parser.add_argument("--url", default=None, help="URL yang ingin dibuka sebelum capture")
    parser.add_argument("--outdir", default=str(DEFAULT_OUTDIR))
    parser.add_argument("--wait", type=float, default=4.0, help="Detik menunggu setelah membuka URL")
    parser.add_argument("--ocr", action="store_true", help="Jalankan OCR jika tesseract tersedia")
    parser.add_argument("--watch", type=float, default=0, help="Loop capture tiap N detik")
    parser.add_argument("--count", type=int, default=0, help="Jumlah capture saat --watch; 0 berarti terus")
    args = parser.parse_args()

    if not have("firefox"):
        print("ERROR: firefox tidak ditemukan.", file=sys.stderr)
        return 1
    if not have("import"):
        print("ERROR: ImageMagick import tidak ditemukan.", file=sys.stderr)
        return 1

    if args.watch > 0:
        index = 0
        while args.count <= 0 or index < args.count:
            one_scan(args)
            index += 1
            if args.count <= 0 or index < args.count:
                time.sleep(args.watch)
    else:
        one_scan(args)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
