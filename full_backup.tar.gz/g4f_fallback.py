#!/data/data/com.termux/files/usr/bin/env python
import json
import sys

from g4f.client import Client


def main():
    payload = json.load(sys.stdin)
    messages = payload.get("messages", [])
    models = payload.get("models") or ["gpt-4", "gpt-4o-mini", "gpt-3.5-turbo"]

    client = Client()
    last_error = None

    for model in models:
        try:
            response = client.chat.completions.create(
                model=model,
                messages=messages,
            )
            content = response.choices[0].message.content
            print(content)
            return
        except Exception as error:
            last_error = error

    raise RuntimeError(f"Semua model fallback gagal: {last_error}")


if __name__ == "__main__":
    main()
