from g4f.client import Client

client = Client()

response = client.chat.completions.create(
    model="gpt-4",
    messages=[
        {"role": "user", "content": "Jawab singkat: apa itu Termux:X11?"}
    ],
)

print(response.choices[0].message.content)
