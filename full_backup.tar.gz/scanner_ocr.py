import pathlib
import shutil
import subprocess


class ScreenScanner:
    def __init__(self, display, checkpoint):
        self.display = display
        self.checkpoint = checkpoint

    def _env(self):
        import os
        env = os.environ.copy()
        env["DISPLAY"] = self.display
        return env

    def screenshot(self):
        if not shutil.which("import"):
            raise RuntimeError("ImageMagick 'import' tidak tersedia.")
        path = self.checkpoint.artifact_path("screen", "png")
        result = subprocess.run(
            ["import", "-window", "root", str(path)],
            env=self._env(),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=20,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or "Gagal mengambil screenshot.")
        self.checkpoint.log("screenshot", path=str(path))
        return path

    def ocr(self, image_path):
        if not shutil.which("tesseract"):
            self.checkpoint.log("ocr_skipped", reason="tesseract_not_found")
            return ""
        image_path = pathlib.Path(image_path)
        text_base = image_path.with_suffix("")
        result = subprocess.run(
            ["tesseract", str(image_path), str(text_base)],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=60,
        )
        text_path = text_base.with_suffix(".txt")
        text = text_path.read_text(errors="replace") if text_path.exists() else ""
        self.checkpoint.log(
            "ocr",
            image=str(image_path),
            text_path=str(text_path),
            ok=result.returncode == 0,
            preview=text[:500],
        )
        return text

    def scan_text(self):
        image = self.screenshot()
        return self.ocr(image)
