import os
import subprocess
import time

from logic_fizzo import StopRisk


class LiveX11Runner:
    def __init__(self, config, checkpoint, scanner):
        self.config = config
        self.checkpoint = checkpoint
        self.scanner = scanner

    def _env(self):
        env = os.environ.copy()
        env["DISPLAY"] = self.config.get("display", ":1")
        return env

    def launch_firefox(self):
        process = subprocess.Popen(
            ["firefox", "-P", self.config["profile"], self.config["url"]],
            env=self._env(),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        self.checkpoint.log("live_firefox_launch", pid=process.pid, profile=self.config["profile"], url=self.config["url"])
        return process.pid

    def guard(self, text):
        lowered = (text or "").lower()
        hits = [word for word in self.config["guardrails"]["stopWords"] if word.lower() in lowered]
        if hits:
            self.checkpoint.save_state("STOP_RISK", source="live_ocr", hits=hits)
            raise StopRisk(f"Guardrail aktif: {', '.join(hits)}")

    def detect_kind(self, text):
        lowered = (text or "").lower()
        if "mulai karir menulis" in lowered:
            return "writer_onboarding"
        if "fizzo" in lowered:
            return "fizzo_page"
        if text.strip():
            return "visible_page"
        return "unknown"

    def run(self):
        self.launch_firefox()
        time.sleep(max(3, int(self.config["timeouts"]["step_pause_seconds"] * 6)))
        text = self.scanner.scan_text()
        self.guard(text)
        kind = self.detect_kind(text)
        self.checkpoint.save_state(
            "LIVE_X11_READ",
            kind=kind,
            mode=self.config["mode"],
            preview=text[:1000],
        )
        self.checkpoint.save_state("STOP_BEFORE_ACTION", reason="LIVE_X11 backend hanya membaca dan checkpoint pada v1.")
        return {
            "status": "STOP_BEFORE_ACTION",
            "backend": "LIVE_X11",
            "kind": kind,
            "preview": text[:500],
        }
