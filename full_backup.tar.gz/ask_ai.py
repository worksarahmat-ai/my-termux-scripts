import argparse
import json
import os
import sys
from pathlib import Path


CONFIG_DIR = Path.home() / ".config" / "ask_ai"
HISTORY_PATH = CONFIG_DIR / "history.json"
MAX_HISTORY = int(os.environ.get("ASK_AI_MAX_HISTORY", "20"))
CONTEXT_WINDOW = int(os.environ.get("ASK_AI_CONTEXT_WINDOW", "8"))

SYSTEM_PROMPT = """Anda adalah chatbot CLI berbahasa Indonesia.
Gunakan konteks percakapan sebelumnya bila relevan.
Untuk pertanyaan kompleks, matematika, debugging, arsitektur, atau kode:
- berpikir lebih lama sebelum menjawab,
- uraikan asumsi penting,
- berikan langkah yang bisa dieksekusi,
- jangan mengarang hasil eksekusi yang belum diuji.
Untuk pertanyaan sederhana, jawab ringkas dan langsung."""


def load_history():
    if not HISTORY_PATH.exists():
        return []
    try:
        return json.loads(HISTORY_PATH.read_text())
    except (json.JSONDecodeError, OSError):
        return []


def save_history(history):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    HISTORY_PATH.write_text(json.dumps(history[-MAX_HISTORY:], indent=2, ensure_ascii=False))
    os.chmod(HISTORY_PATH, 0o600)


def reset_history():
    if HISTORY_PATH.exists():
        HISTORY_PATH.unlink()


COMPLEX_MARKERS = [
        "matematika",
        "math",
        "kode",
        "coding",
        "program",
        "script",
        "debug",
        "error",
        "traceback",
        "exception",
        "api",
        "algoritma",
        "arsitektur",
        "refactor",
        "optimasi",
        "security",
        "database",
        "server",
        "terminal",
        "linux",
        "termux",
        "bukti",
        "proof",
        "analisis",
        "penalaran",
        "strategi",
        "rencana",
        "implementasi",
        "otomatisasi",
        "agent",
        "agen",
        "berpikir lebih lama",
        "deep",
        "complex",
        "kompleks",
        "tingkat lanjut",
    ]

FOLLOWUP_MARKERS = [
    "lanjut",
    "lanjutkan",
    "teruskan",
    "perbaiki",
    "tambahkan",
    "ubah",
    "refine",
    "jelaskan",
    "itu",
    "di atas",
    "sebelumnya",
    "sesuaikan",
]

FAST_INTENT_MARKERS = [
    "jawab singkat",
    "jawab sangat singkat",
    "singkat saja",
    "ringkas",
    "pendek",
    "satu kalimat",
    "cukup jawab",
    "tanpa deep",
    "no deep",
    "no-auto-deep",
    "jangan panjang",
    "langsung jawab",
]

DEEP_INTENT_MARKERS = [
    "berpikir lebih lama",
    "berfikir lebih lama",
    "penalaran mendalam",
    "analisis mendalam",
    "tingkat lanjut",
    "step by step",
    "langkah demi langkah",
    "jelaskan detail",
]


def prompt_has_any(prompt, markers):
    text = prompt.lower()
    return any(marker in text for marker in markers)


def is_fast_intent(prompt):
    return prompt_has_any(prompt, FAST_INTENT_MARKERS)


def is_deep_intent(prompt):
    return prompt_has_any(prompt, DEEP_INTENT_MARKERS)


def complexity_score(prompt, history=None):
    history = history or []
    text = prompt.lower()
    recent_text = " ".join(item.get("content", "") for item in history[-CONTEXT_WINDOW:]).lower()
    combined = f"{text}\n{recent_text}"

    score = 0
    if len(prompt) > 800:
        score += 3
    elif len(prompt) > 300:
        score += 1

    score += sum(1 for marker in COMPLEX_MARKERS if marker in text) * 2
    score += sum(1 for marker in COMPLEX_MARKERS if marker in recent_text)

    is_followup = any(marker in text for marker in FOLLOWUP_MARKERS)
    if is_followup and any(marker in recent_text for marker in COMPLEX_MARKERS):
        score += 3

    if combined.count("?") >= 2:
        score += 1
    if any(token in combined for token in ["```", "def ", "class ", "import ", "function ", "npm ", "python3 "]):
        score += 3

    return score


def should_use_deep(prompt, history=None, force_deep=False, disable_auto=False):
    if force_deep:
        return True
    if disable_auto:
        return False
    if is_fast_intent(prompt) and not is_deep_intent(prompt):
        return False
    if is_deep_intent(prompt):
        return True
    return complexity_score(prompt, history) >= 3


def select_openai_model(prompt, deep=False):
    if os.environ.get("OPENAI_MODEL"):
        return os.environ["OPENAI_MODEL"]
    if deep:
        return os.environ.get("OPENAI_MODEL_DEEP", "gpt-5.4-mini")
    return os.environ.get("OPENAI_MODEL_FAST", "gpt-4.1-mini")


def select_g4f_model(prompt, deep=False):
    if os.environ.get("G4F_MODEL"):
        return os.environ["G4F_MODEL"]
    if deep:
        return os.environ.get("G4F_MODEL_DEEP", "gpt-4")
    return os.environ.get("G4F_MODEL_FAST", "gpt-4")


def response_style(prompt, deep=False):
    if is_fast_intent(prompt) and not deep:
        return (
            "\nMode ringkas aktif otomatis berdasarkan instruksi terbaru. "
            "Jawab sangat singkat dan jangan membawa detail konteks lama kecuali diminta."
        )
    if deep:
        return (
            "\nMode penalaran mendalam aktif otomatis berdasarkan konteks. "
            "Untuk matematika/kode/arsitektur/debugging, kerjakan bertahap, "
            "cek konsistensi jawaban sebelum final, dan pertahankan konteks "
            "keputusan dari percakapan sebelumnya."
        )
    return ""


def build_messages(history, prompt, use_context=True, deep=False):
    style = response_style(prompt, deep)

    messages = [{"role": "system", "content": SYSTEM_PROMPT + style}]
    if use_context:
        messages.extend(history[-MAX_HISTORY:])
    messages.append({"role": "user", "content": prompt})
    return messages


def ask_openai(prompt, history, use_context=True, deep=False):
    from openai import OpenAI

    model = select_openai_model(prompt, deep)
    client = OpenAI()
    messages = build_messages(history, prompt, use_context, deep)

    request = {
        "model": model,
        "input": messages,
    }
    if deep:
        request["reasoning"] = {"effort": os.environ.get("OPENAI_REASONING_EFFORT", "high")}

    try:
        response = client.responses.create(**request)
    except Exception:
        request.pop("reasoning", None)
        response = client.responses.create(**request)

    return model, response.output_text


def ask_g4f(prompt, history, use_context=True, deep=False):
    from g4f.client import Client

    model = select_g4f_model(prompt, deep)
    client = Client()
    messages = build_messages(history, prompt, use_context, deep)
    response = client.chat.completions.create(
        model=model,
        messages=messages,
    )
    return model, response.choices[0].message.content


def ask(prompt, args, history):
    provider = args.provider
    use_context = not args.no_context
    deep = should_use_deep(
        prompt,
        history if use_context else [],
        force_deep=args.deep,
        disable_auto=args.no_auto_deep,
    )

    if provider in ("auto", "openai"):
        try:
            model, answer = ask_openai(prompt, history, use_context, deep)
            return "openai", model, deep, answer
        except Exception as exc:
            if provider == "openai":
                raise
            print(
                f"[OpenAI resmi gagal: {type(exc).__name__}. Fallback ke g4f...]",
                file=sys.stderr,
            )

    model, answer = ask_g4f(prompt, history, use_context, deep)
    return "g4f", model, deep, answer


def parse_args():
    parser = argparse.ArgumentParser(description="Chatbot CLI kontekstual OpenAI/g4f.")
    parser.add_argument("prompt", nargs="*", help="Pertanyaan untuk AI.")
    parser.add_argument("--chat", action="store_true", help="Mode obrolan interaktif.")
    parser.add_argument("--deep", action="store_true", help="Paksa penalaran mendalam.")
    parser.add_argument("--no-auto-deep", action="store_true", help="Matikan deep otomatis.")
    parser.add_argument("--no-context", action="store_true", help="Jangan gunakan riwayat.")
    parser.add_argument("--reset", action="store_true", help="Hapus riwayat konteks.")
    parser.add_argument("--show-context", action="store_true", help="Tampilkan riwayat konteks.")
    parser.add_argument(
        "--provider",
        choices=["auto", "openai", "g4f"],
        default=os.environ.get("ASK_AI_PROVIDER", "auto"),
        help="Pilih provider. Default: auto.",
    )
    return parser.parse_args()


def run_once(prompt, args, history):
    provider, model, deep, answer = ask(prompt, args, history)
    mode = "deep" if deep else "fast"
    print(f"[provider={provider} model={model} mode={mode}]\n{answer}")

    if not args.no_context:
        history.extend([
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": answer},
        ])
        save_history(history)


def run_chat(args, history):
    print("Chat AI aktif. Ketik /exit untuk keluar, /reset untuk hapus konteks.")
    while True:
        try:
            prompt = input("\nTuan> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0

        if not prompt:
            continue
        if prompt in {"/exit", "/quit"}:
            return 0
        if prompt == "/reset":
            history.clear()
            reset_history()
            print("Konteks dihapus.")
            continue

        run_once(prompt, args, history)


def main():
    args = parse_args()

    if args.reset:
        reset_history()
        print("Konteks dihapus.")
        return 0

    history = load_history()

    if args.show_context:
        print(json.dumps(history, indent=2, ensure_ascii=False))
        return 0

    if args.chat:
        return run_chat(args, history)

    prompt = " ".join(args.prompt).strip()
    if not prompt:
        prompt = input("Tanya AI: ").strip()

    if not prompt:
        print("Pertanyaan kosong.")
        return 1

    try:
        run_once(prompt, args, history)
        return 0
    except Exception as exc:
        print(f"[AI gagal: {type(exc).__name__}: {exc}]", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
